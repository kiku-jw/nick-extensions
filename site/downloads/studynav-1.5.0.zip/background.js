"use strict";
(() => {
  // packages/studynav/src/features.ts
  var DEFAULT_FLAGS = {
    masterEnabled: true,
    annotations: true,
    bookmarks: true,
    advSearch: true,
    actionBar: false,
    altText: true,
    copyText: true,
    citations: true,
    continueWatching: true,
    cstblView: false,
    expandWidth: false,
    langCount: true,
    parLink: true,
    qrShare: true,
    officialOpen: true,
    verseAudio: true,
    mediaPlayerUI: true,
    customSub: true,
    imgGet: false,
    mediaCtrl: true,
    mediaTS: true,
    mediaClip: true,
    sndDisp: true,
    transcCreate: true
  };
  function predatesSafeLayoutDefaults(version) {
    const match = /^(\d+)\.(\d+)\.(\d+)(?:\D.*)?$/.exec(version || "");
    if (!match) return false;
    const current = match.slice(1, 4).map(Number);
    const safeDefaultRelease = [1, 2, 4];
    for (let index = 0; index < safeDefaultRelease.length; index += 1) {
      if (current[index] !== safeDefaultRelease[index]) {
        return current[index] < safeDefaultRelease[index];
      }
    }
    return false;
  }
  function migrateFlagsForInstall(stored, details) {
    const next = { ...DEFAULT_FLAGS, ...stored };
    const resetLayout = details.reason === "install" || details.reason === "update" && predatesSafeLayoutDefaults(details.previousVersion);
    if (!resetLayout) return next;
    return {
      ...next,
      actionBar: false,
      cstblView: false,
      expandWidth: false
    };
  }

  // packages/studynav/src/i18n.ts
  var EN_MESSAGES = {
    extension_name: "StudyNav \u2014 Unofficial Study Tools",
    extension_short_name: "StudyNav",
    extension_description: "Unofficial local study helpers for public JW.org pages. No telemetry or uploads; not affiliated with Jehovah\u2019s Witnesses.",
    command_adv_search: "Open the StudyNav command palette",
    popup_header_title: "StudyNav",
    popup_header_subtitle: "Unofficial \xB7 local processing \xB7 supported pages only",
    tools: "Tools",
    tools_title: "Enable or disable all StudyNav tools",
    tools_aria: "Enable all StudyNav tools",
    checking_page: "Checking this page\u2026",
    open_supported_page: "Open a supported JW.org page to use study tools.",
    page_tools: "Page tools",
    study_library: "Study library",
    save_place: "Save place",
    remove_saved_place: "Remove saved place",
    copy_citation: "Copy citation",
    show_qr: "Show QR",
    open_official_link: "Open stable publication link",
    image_search: "Search JW images with Google",
    image_search_placeholder: "What picture do you need?",
    image_search_external: "Opens an external Google search",
    reset_defaults: "Reset recommended defaults",
    defaults_restored: "Recommended defaults restored",
    what_it_gives_you: "What it gives you",
    guide_bible_label: "Bible:",
    guide_bible_text: "select one verse number, then choose Download audio.",
    guide_study_label: "Study:",
    guide_study_text: "select text to highlight it, add a note, or save an exact place.",
    guide_articles_label: "Articles:",
    guide_articles_text: "hover or focus text for Copy, Link, and Mark actions.",
    guide_media_label: "Media:",
    guide_media_text: "use the floating controls for playback, media segments, resume, and available captions.",
    feature_settings: "Feature settings",
    filter_features: "Filter features",
    find_setting: "Find a setting\u2026",
    footer_quick_search: "Quick search: Ctrl/Cmd+Shift+K",
    footer_privacy: "No telemetry \xB7 no uploads",
    group_study: "Study & sharing",
    group_core: "Bible & articles",
    group_layout: "Reading layout",
    group_media: "Video & audio",
    enabled_count: "$1 on",
    status_tools_off_title: "Study tools are off",
    status_tools_off_hint: "Turn on Tools above to restore helpers on supported pages.",
    status_unavailable_title: "No tools on this page",
    status_unavailable_hint: "Open a JW.org Bible chapter, library article, or media page.",
    status_bible_title: "Ready on this Bible chapter",
    status_bible_selected: "Verse $1:$2 is selected. Shift-click another verse for a consecutive range.",
    status_bible_range: "Verses $1:$2\u2013$3 are selected. Copy creates one range link.",
    status_bible_hint: "Click one verse number for audio; Shift-click another verse for a range link.",
    status_media_title: "Ready on this media page",
    status_media_hint: "Use the floating controls for playback, media segments, and captions when present.",
    status_article_title: "Ready on this article",
    status_article_hint: "Hover or focus article text for Copy and Link. Optional image downloads are in Feature settings.",
    status_palette_title: "Quick search is ready",
    status_palette_hint: "Press Ctrl/Cmd+Shift+K to find a publication or DOCID.",
    working: "Working\u2026",
    preparing: "Preparing\u2026",
    done: "Done",
    unavailable_here: "Unavailable here",
    no_active_tab: "No active tab",
    place_saved: "Place saved",
    saved_place_removed: "Saved place removed",
    bookmark_limit: "The local saved-place limit has been reached.",
    remove_saved_place_confirm: "Remove this saved place?",
    feature_annotations_name: "Highlights, notes & tags",
    feature_annotations_blurb: "Keep six-color highlights and searchable notes locally",
    feature_bookmarks_name: "Saved places",
    feature_bookmarks_blurb: "Save exact pages, paragraphs, and verses locally",
    feature_citations_name: "Copy formatted citations",
    feature_citations_blurb: "Copy the selected text or page with an exact JW link",
    feature_qrShare_name: "Show QR for this page",
    feature_qrShare_blurb: "Create a local QR code for the precise official page link",
    feature_officialOpen_name: "Stable publication link",
    feature_officialOpen_blurb: "Open a clean Finder address for saving or sharing",
    feature_verseAudio_name: "Download verse audio",
    feature_verseAudio_blurb: "Select one Bible verse to save only its narration",
    feature_copyText_name: "Copy clean text",
    feature_copyText_blurb: "Copy without verse numbers, reference letters, or StudyNav controls",
    feature_parLink_name: "Copy precise link",
    feature_parLink_blurb: "Copy a direct link to a paragraph, verse, or verse range",
    feature_advSearch_name: "Publication shortcuts",
    feature_advSearch_blurb: "Open a mnemonic or DOCID with the existing JW searches; this is not AI",
    feature_altText_name: "Image descriptions",
    feature_altText_blurb: "Show alt text and captions below article images",
    feature_imgGet_name: "Download article images",
    feature_imgGet_blurb: "Add a compact download button beside article images",
    feature_langCount_name: "Available languages",
    feature_langCount_blurb: "Show the number of languages for an article",
    feature_actionBar_name: "Keep page header visible",
    feature_actionBar_blurb: "Keep the JW.org header in view while scrolling",
    feature_expandWidth_name: "Wider reading column",
    feature_expandWidth_blurb: "Use more of the window for article text",
    feature_cstblView_name: "Clearer tables",
    feature_cstblView_blurb: "Add spacing and row separation to article tables",
    feature_mediaPlayerUI_name: "Remove video shading",
    feature_mediaPlayerUI_blurb: "Keep the picture clear when the player controls appear",
    feature_customSub_name: "Larger subtitles",
    feature_customSub_blurb: "Increase subtitle size and background contrast",
    feature_mediaCtrl_name: "Media keyboard shortcuts",
    feature_mediaCtrl_blurb: "Use Space/K/J/L/F/M while watching media",
    feature_mediaTS_name: "Copy page and time",
    feature_mediaTS_blurb: "Copy the page link together with the current playback time",
    feature_mediaClip_name: "Download an audio or video segment",
    feature_mediaClip_blurb: "Enter start and end times, then save audio as WAV or video as WebM",
    feature_continueWatching_name: "Continue watching",
    feature_continueWatching_blurb: "Keep video progress locally and resume only when asked",
    feature_sndDisp_name: "Open second display",
    feature_sndDisp_blurb: "Open the current media in a popup window",
    feature_transcCreate_name: "Search available captions",
    feature_transcCreate_blurb: "Open a searchable panel only when text is present",
    copied: "Copied",
    copy_failed: "Copy failed",
    study_tools_off: "Study tools are off",
    annotations_off: "Highlights and notes are off",
    bookmarks_off: "Saved places are off",
    citations_off: "Citations are off",
    qr_sharing_off: "QR sharing is off",
    official_links_off: "Publication links are off",
    action_failed: "Action failed",
    citation_unavailable: "Citation unavailable",
    citation_copied: "Citation copied",
    qr_unavailable: "QR unavailable",
    qr_title: "QR for this page",
    close: "Close",
    close_qr_aria: "Close QR",
    qr_image_aria: "QR code for the displayed JW link",
    copy_link: "Copy link",
    link_copied: "Link copied",
    qr_opened: "QR opened",
    not_available_page: "Not available on this page",
    official_link_opened: "Stable publication link opened",
    palette_title: "Publication shortcuts",
    palette_placeholder: "Mnemonic / DOCID (for example w25.03, lff, wp24.01, mwb25.01)",
    palette_hint: "Enter to open \xB7 Esc to close \xB7 Unofficial StudyNav",
    study_tools_aria: "Study tools",
    download_audio: "Download audio",
    download_audio_title: "Download only this verse as audio",
    chapter_audio_not_ready: "Chapter audio is not ready. Open Play Audio once, then try again.",
    verse_audio_prepare_failed: "Verse audio could not be prepared.",
    verse_audio_downloaded: "Downloaded $1:$2 audio",
    verse_audio_download_failed: "Verse audio download failed.",
    mark: "Mark",
    mark_title: "Highlight this paragraph or verse and optionally add a private note",
    copy: "Copy",
    copy_text_title: "Copy without verse numbers, reference letters, or StudyNav controls",
    link: "Link",
    copy_paragraph_link_title: "Copy a link to this paragraph, verse, or selected verse range",
    languages_count: "$1 languages",
    download_image: "Download image",
    image_download_started: "Image download started",
    copy_page_time: "Copy page + time",
    page_time_copied: "Page link and time copied",
    media_clip: "Media segment",
    media_clip_title: "Download an audio or video segment",
    clip_format: "Format",
    clip_format_audio: "Audio (.wav) \xB7 up to 2 minutes",
    clip_format_video: "Video (.webm) \xB7 up to 1 minute",
    clip_start: "Start",
    clip_end: "End",
    clip_download_audio: "Download WAV",
    clip_download_video: "Record WebM",
    clip_cancel: "Cancel",
    clip_invalid_time: "Enter times as M:SS or H:MM:SS. The end must be after the start.",
    clip_too_long: "Choose a segment no longer than 2 minutes.",
    clip_video_too_long: "Choose a video segment no longer than 1 minute.",
    clip_preparing: "Preparing audio segment\u2026",
    clip_recording: "Recording video segment in real time\u2026",
    clip_downloaded: "Media segment downloaded",
    clip_failed: "The requested media segment could not be created.",
    clip_video_failed: "The video segment could not be created.",
    clip_video_recorder_failed: "The browser recorder failed while creating the video segment.",
    clip_video_timeout: "The video did not advance while the segment was being recorded.",
    clip_video_load_failed: "The official video could not be loaded for recording.",
    clip_video_unsupported: "This browser cannot record a video segment from this player.",
    clip_video_too_large: "The recorded video segment is too large to download safely.",
    clip_source_unavailable: "Play the media once so its source is available, then try again.",
    clip_request_rejected: "This media-segment request was rejected.",
    clip_source_download_failed: "The official media file could not be downloaded.",
    clip_source_too_large: "This media file is too large to process safely.",
    clip_outside_media: "The selected times are outside this media file.",
    second_display: "Second display",
    transcript: "Transcript",
    transcript_search: "Search\u2026",
    transcript_download: "Download .txt",
    close_transcript_aria: "Close transcript",
    loading: "Loading\u2026",
    no_matches: "(no matches)",
    no_transcript_detected: "No transcript text was detected on this page. If captions load later, reopen this panel.",
    annotation_limit: "The local annotation limit has been reached.",
    selection_cannot_save: "This selection cannot be saved.",
    note_updated: "Note updated",
    highlight_saved: "Highlight saved locally",
    select_one_paragraph: "Select text within one paragraph or verse.",
    select_character_count: "Select between 1 and $1 characters.",
    highlight_color_aria: "$1 highlight",
    reattach_note_aria: "Reattach note",
    highlight_selection_aria: "Highlight selected text",
    reattach_here: "Reattach here",
    note_missing: "That note no longer exists.",
    reattach_source_first: "Return to the note\u2019s source page before reattaching it.",
    reattach_cancelled: "Reattach cancelled",
    reattach_instruction: "Select the replacement text, then choose Reattach here.",
    cancel: "Cancel",
    add_note: "Add note",
    edit_highlight: "Edit highlight",
    new_highlight: "New highlight",
    close_highlight_editor_aria: "Close highlight editor",
    highlight_color: "Highlight color",
    color_yellow: "Yellow",
    color_green: "Green",
    color_blue: "Blue",
    color_pink: "Pink",
    color_purple: "Purple",
    color_orange: "Orange",
    page_notes: "Notes on this page",
    open_all_notes: "Open all notes",
    note: "Note",
    write_private_note: "Write a private note\u2026",
    tags: "Tags",
    tags_placeholder: "study, family, review",
    save_locally: "Save locally",
    tags_error: "Use at most 20 short, comma-separated tags.",
    paragraph_mark_unreliable: "This paragraph cannot be marked reliably.",
    needs_attention: "Needs attention",
    delete_highlight_confirm: "Delete this local highlight and note?",
    highlight_deleted: "Highlight deleted",
    locate: "Locate",
    open_page: "Open page",
    edit: "Edit",
    delete: "Delete",
    reattach: "Reattach",
    no_notes_filtered: "No notes match these filters.",
    no_notes_yet: "Select text on an article or verse to create your first highlight.",
    notes_count_one: "$1 note",
    notes_count_many: "$1 notes",
    study_export_failed: "Study data could not be exported.",
    study_backup_downloaded: "Study backup downloaded",
    backup_too_large: "Backup is larger than 5 MB.",
    backup_invalid: "That is not a valid StudyNav backup.",
    import_summary: "Import: $1 added, $2 updated, $3 ignored, $4 rejected",
    notes_tab: "Notes",
    saved_places_tab: "Saved places",
    this_page: "This page",
    all_notes: "All notes",
    all_pages: "All pages",
    search_notes: "Search study notes",
    search_notes_placeholder: "Search quote, note, or tag\u2026",
    search_saved_places: "Search saved places",
    filter_notes_tag: "Filter study notes by tag",
    all_tags: "All tags",
    export_json: "Export JSON",
    import_json: "Import JSON",
    study_library_opened: "Study library opened",
    close_study_library_aria: "Close study library",
    saved_places_count_one: "$1 saved place",
    saved_places_count_many: "$1 saved places",
    no_saved_places_filtered: "No saved places match these filters.",
    no_saved_places_yet: "Save a page, paragraph, or verse to return to it quickly.",
    open_saved_place: "Open",
    remove_saved_place_action: "Remove",
    local_study_data_invalid: "Local study data is invalid and was left unchanged.",
    study_data_validation_failed: "Study data update failed validation.",
    study_data_save_failed: "Study data could not be saved.",
    migration_save_failed: "Migrated study data could not be saved.",
    video_progress_save_failed: "Video progress could not be saved.",
    resume_at: "Resume at $1",
    resume_title: "Seek to saved local progress without starting playback",
    ready_at: "Ready at $1. Press play when you want.",
    resume_wait_loading: "The video must finish loading before it can resume.",
    verse_request_rejected: "This verse audio request was rejected.",
    verse_job_busy: "Another media clip is already being prepared.",
    verse_processing_failed: "Verse audio processing failed.",
    verse_page_unverified: "The Bible page could not be verified.",
    verse_request_invalid: "The selected verse audio request is not valid.",
    verse_timing_unavailable: "The official verse timing data is unavailable.",
    verse_timing_redirected: "The official verse timing request was redirected unexpectedly.",
    verse_timing_missing: "No official audio timing was found for this verse.",
    chapter_audio_download_failed: "The official chapter audio could not be downloaded.",
    chapter_audio_redirected: "The official chapter audio was redirected unexpectedly.",
    decoded_audio_invalid: "Decoded chapter audio is invalid.",
    verse_outside_audio: "The selected verse is outside the chapter audio.",
    verse_audio_too_large: "The selected verse audio is too large to download safely.",
    chapter_audio_too_large: "The chapter audio is too large to process safely.",
    chapter_audio_size_mismatch: "The chapter audio size does not match its official metadata."
  };
  function fallbackFormat(message, substitutions) {
    const values = substitutions === void 0 ? [] : Array.isArray(substitutions) ? substitutions : [substitutions];
    return values.reduce((result, value, index) => result.replaceAll(`$${index + 1}`, value), message);
  }
  function t(key, substitutions) {
    try {
      if (typeof chrome !== "undefined" && chrome.i18n?.getMessage) {
        const translated = chrome.i18n.getMessage(key, substitutions);
        if (translated) return translated;
      }
    } catch {
    }
    return fallbackFormat(EN_MESSAGES[key], substitutions);
  }

  // packages/studynav/src/verse-audio.ts
  var MEDIA_API_HOST = "b.jw-cdn.org";
  var MEDIA_API_PATH = "/apis/pub-media/getpubmedialinks";
  var MAX_CHAPTER_AUDIO_BYTES = 64 * 1024 * 1024;
  var MAX_WAV_BYTES = 24 * 1024 * 1024;
  var MAX_MEDIA_CLIP_SECONDS = 120;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function finiteNumber(value) {
    const number = typeof value === "number" ? value : Number(value);
    return Number.isFinite(number) ? number : null;
  }
  function parseBibleVerseId(value) {
    const match = /^v([1-9]\d?)(\d{3})(\d{3})$/.exec(value);
    if (!match) return null;
    const verse = {
      book: Number(match[1]),
      chapter: Number(match[2]),
      verse: Number(match[3])
    };
    if (verse.book < 1 || verse.book > 66 || verse.chapter < 1 || verse.chapter > 150 || verse.verse < 1 || verse.verse > 200) return null;
    return verse;
  }
  function isJwCdnUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (url.hostname === "jw-cdn.org" || url.hostname.endsWith(".jw-cdn.org"));
    } catch {
      return false;
    }
  }
  var BIBLE_CHAPTER_PATH_RES = [
    /^\/[a-z]{2}(?:-[a-z]+)?\/library\/bible\/[^/]+\/books\/[^/]+\/(\d+)\/?$/i,
    /^\/[a-z]{2}(?:-[a-z]+)?\/(?:biblioteka|biblioteca|bibliothek|bibliotheque|bibliotek)\/[^/]+\/[^/]+\/(?:books|knigi|libros|livres|buecher|libri)\/[^/]+\/(\d+)\/?$/i,
    /^\/ru\/библиотека\/библия\/(?:nwt\/(?:содержание|книги)|учебная-библия\/книги)\/[^/]+\/(\d+)\/?$/iu,
    /^\/uk\/бібліотека\/біблія\/(?:nwt|навчальне-видання-біблії)\/книги\/[^/]+\/(\d+)\/?$/iu
  ];
  function parseBibleChapterFromPath(pathname) {
    let decodedPath;
    try {
      decodedPath = decodeURIComponent(pathname).normalize("NFC");
    } catch {
      return null;
    }
    for (const pattern of BIBLE_CHAPTER_PATH_RES) {
      const match = pattern.exec(decodedPath);
      if (match) return Number(match[1]);
    }
    return null;
  }
  function mediaApiShell(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.hostname !== MEDIA_API_HOST || url.pathname.toLowerCase() !== MEDIA_API_PATH || url.username || url.password) return null;
      if (url.searchParams.get("output")?.toLowerCase() !== "json") return null;
      if (url.searchParams.get("fileformat")?.toUpperCase() !== "MP3") return null;
      return url;
    } catch {
      return null;
    }
  }
  function validateMediaApiUrl(value, verse) {
    const url = mediaApiShell(value);
    if (!url) return null;
    if (Number(url.searchParams.get("booknum")) !== verse.book) return null;
    if (Number(url.searchParams.get("track")) !== verse.chapter) return null;
    if (!url.searchParams.get("langwritten") || !url.searchParams.get("txtCMSLang")) return null;
    const pub = url.searchParams.get("pub");
    if (pub !== "nwt") return null;
    return url.href;
  }
  function validateVerseAudioRequest(value, senderUrl) {
    if (!isRecord(value) || value.type !== "DOWNLOAD_VERSE_AUDIO") return null;
    if (typeof value.verseId !== "string" || typeof value.apiUrl !== "string" || typeof value.label !== "string") return null;
    const verse = parseBibleVerseId(value.verseId);
    if (!verse) return null;
    try {
      const page = new URL(senderUrl);
      const isJw = page.hostname === "jw.org" || page.hostname.endsWith(".jw.org");
      const chapter = parseBibleChapterFromPath(page.pathname);
      if (!isJw || !/^https?:$/.test(page.protocol) || chapter === null) return null;
      if (chapter !== verse.chapter) return null;
    } catch {
      return null;
    }
    const apiUrl = validateMediaApiUrl(value.apiUrl, verse);
    if (!apiUrl) return null;
    return {
      verse,
      verseId: value.verseId,
      apiUrl,
      label: value.label.slice(0, 120)
    };
  }
  function validateMediaAudioClipRequest(value, senderUrl) {
    if (!isRecord(value) || value.type !== "DOWNLOAD_MEDIA_AUDIO_CLIP") return null;
    if (typeof value.mediaUrl !== "string" || typeof value.label !== "string") return null;
    const startSeconds = finiteNumber(value.startSeconds);
    const endSeconds = finiteNumber(value.endSeconds);
    if (startSeconds === null || endSeconds === null || startSeconds < 0 || endSeconds <= startSeconds || endSeconds - startSeconds > MAX_MEDIA_CLIP_SECONDS || endSeconds > 36e3 || !isJwCdnUrl(value.mediaUrl)) return null;
    try {
      const sender = new URL(senderUrl);
      const allowedHost = sender.hostname === "jw.org" || sender.hostname.endsWith(".jw.org");
      if (sender.protocol !== "https:" || !allowedHost || sender.username || sender.password) return null;
    } catch {
      return null;
    }
    const label = safeFilenamePart(value.label);
    const startLabel = Math.floor(startSeconds).toString().padStart(4, "0");
    const endLabel = Math.floor(endSeconds).toString().padStart(4, "0");
    return {
      type: "DOWNLOAD_MEDIA_AUDIO_CLIP",
      mediaUrl: value.mediaUrl,
      startSeconds,
      endSeconds,
      label,
      filename: `${label}_${startLabel}-${endLabel}.wav`
    };
  }
  function safeFilenamePart(value) {
    return value.normalize("NFKC").replace(/[\u0000-\u001f\u007f/\\?%*:|"<>]+/g, " ").replace(/\s+/g, " ").trim().replace(/[. ]+$/g, "").slice(0, 80) || "Bible";
  }

  // packages/studynav/src/background.ts
  var OFFSCREEN_URL = "offscreen.html";
  var creatingOffscreen = null;
  var audioJob = null;
  var flagMutationQueue = Promise.resolve();
  async function load() {
    const s = await chrome.storage.sync.get({ flags: DEFAULT_FLAGS });
    return { ...DEFAULT_FLAGS, ...s.flags };
  }
  function paletteEnabled(flags) {
    return flags.masterEnabled !== false && !!flags.advSearch;
  }
  function mutateFlags(change) {
    const task = flagMutationQueue.then(async () => {
      const next = { ...await load(), ...change };
      await chrome.storage.sync.set({ flags: next });
      return next;
    });
    flagMutationQueue = task.then(() => void 0, () => void 0);
    return task;
  }
  async function ensureOffscreenDocument() {
    const documentUrl = chrome.runtime.getURL(OFFSCREEN_URL);
    const contexts = await chrome.runtime.getContexts({
      contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
      documentUrls: [documentUrl]
    });
    if (contexts.length) return;
    if (!creatingOffscreen) {
      creatingOffscreen = chrome.offscreen.createDocument({
        url: OFFSCREEN_URL,
        reasons: [chrome.offscreen.Reason.BLOBS],
        justification: "Decode official JW media and create a local user-selected WAV clip."
      }).finally(() => {
        creatingOffscreen = null;
      });
    }
    await creatingOffscreen;
  }
  async function processMediaAudioClip(message, senderUrl) {
    const request = validateMediaAudioClipRequest(message, senderUrl);
    if (!request) return { ok: false, error: t("clip_request_rejected") };
    if (audioJob) return { ok: false, error: t("verse_job_busy") };
    audioJob = (async () => {
      await ensureOffscreenDocument();
      return chrome.runtime.sendMessage({
        target: "studynav-offscreen",
        type: "PROCESS_MEDIA_AUDIO_CLIP",
        request,
        senderUrl
      });
    })();
    try {
      return await audioJob;
    } finally {
      audioJob = null;
      try {
        await chrome.offscreen.closeDocument();
      } catch {
      }
    }
  }
  async function processVerseAudio(message, senderUrl) {
    const request = validateVerseAudioRequest(message, senderUrl);
    if (!request) return { ok: false, error: t("verse_request_rejected") };
    if (audioJob) return { ok: false, error: t("verse_job_busy") };
    audioJob = (async () => {
      await ensureOffscreenDocument();
      return chrome.runtime.sendMessage({
        target: "studynav-offscreen",
        type: "PROCESS_VERSE_AUDIO",
        request: {
          type: "DOWNLOAD_VERSE_AUDIO",
          verseId: request.verseId,
          apiUrl: request.apiUrl,
          label: request.label
        },
        senderUrl
      });
    })();
    try {
      return await audioJob;
    } finally {
      audioJob = null;
      try {
        await chrome.offscreen.closeDocument();
      } catch {
      }
    }
  }
  chrome.runtime.onInstalled.addListener(async (details) => {
    const cur = await chrome.storage.sync.get("flags");
    await chrome.storage.sync.set({
      flags: migrateFlagsForInstall(cur.flags, details)
    });
  });
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.target === "studynav-offscreen") return false;
    (async () => {
      if (msg?.type === "GET_FLAGS") {
        sendResponse(await load());
        return;
      }
      if (msg?.type === "SET_FLAGS") {
        sendResponse(await mutateFlags(msg.flags));
        return;
      }
      if (msg?.type === "SET_FLAG") {
        sendResponse(await mutateFlags({ [msg.id]: !!msg.value }));
        return;
      }
      if (msg?.type === "DOWNLOAD_VERSE_AUDIO") {
        sendResponse(await processVerseAudio(msg, sender.tab?.url || ""));
        return;
      }
      if (msg?.type === "DOWNLOAD_MEDIA_AUDIO_CLIP") {
        sendResponse(await processMediaAudioClip(msg, sender.tab?.url || ""));
        return;
      }
    })().catch((error) => {
      const text = error instanceof Error ? error.message : t("verse_processing_failed");
      sendResponse({ ok: false, error: text });
    });
    return true;
  });
  chrome.commands?.onCommand?.addListener(async (command) => {
    if (command !== "adv-search") return;
    const flags = await load();
    if (!paletteEnabled(flags)) return;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "OPEN_PALETTE" }).catch(() => {
    });
  });
})();
//# sourceMappingURL=background.js.map
