"use strict";
(() => {
  // packages/studynav/src/features.ts
  var FEATURE_META = [
    { id: "annotations", name: "Highlights, notes & tags", blurb: "Keep six-color highlights and searchable notes locally", group: "study" },
    { id: "bookmarks", name: "Save a place to return to", blurb: "Keep an exact page, paragraph, verse, or verse range in the Study library", group: "study" },
    { id: "citations", name: "Copy a quote with its source", blurb: "Copy selected words with the publication title, reference, and direct JW link", group: "study" },
    { id: "qrShare", name: "Show QR for this page", blurb: "Create a local QR code for the precise official page link", group: "study" },
    { id: "officialOpen", name: "Clean publication link", blurb: "Open the same publication through JW.org without extra address parameters", group: "study" },
    { id: "verseAudio", name: "Download audio for selected verses", blurb: "Save one verse or several consecutive verses as one WAV file", group: "core" },
    { id: "copyText", name: "Copy clean text", blurb: "Copy text without verse numbers, reference letters, or StudyNav controls", group: "core" },
    { id: "parLink", name: "Copy precise link", blurb: "Copy a direct link to a paragraph, verse, or verse range", group: "core" },
    { id: "advSearch", name: "Search by publication code", blurb: "Open the existing JW search for a publication code or document number", group: "core" },
    { id: "altText", name: "Image descriptions", blurb: "Show alt text and captions below article images", group: "core" },
    { id: "imgGet", name: "Download article images", blurb: "Add a compact download button beside article images", group: "core" },
    { id: "langCount", name: "Available languages", blurb: "Show the number of languages for an article", group: "core" },
    { id: "actionBar", name: "Keep page header visible", blurb: "Keep the JW.org header in view while scrolling", group: "layout" },
    { id: "expandWidth", name: "Wider reading column", blurb: "Use more of the window for article text", group: "layout" },
    { id: "cstblView", name: "Clearer tables", blurb: "Add spacing and row separation to article tables", group: "layout" },
    { id: "mediaPlayerUI", name: "Remove video shading", blurb: "Keep the picture clear when the player controls appear", group: "media" },
    { id: "customSub", name: "Larger subtitles", blurb: "Increase subtitle size and background contrast", group: "media" },
    { id: "mediaCtrl", name: "Media keyboard shortcuts", blurb: "Use Space/K/J/L/F/M while watching media", group: "media" },
    { id: "mediaTS", name: "Copy link at current time", blurb: "Copy a page link that opens at the current playback time", group: "media" },
    { id: "mediaClip", name: "Download a media segment", blurb: "Enter start and end times, then save audio as WAV or video as WebM", group: "media" },
    { id: "continueWatching", name: "Continue watching", blurb: "Keep video progress locally and resume only when asked", group: "media" },
    { id: "sndDisp", name: "Open in a separate window", blurb: "Open the current media in its own browser window", group: "media" },
    { id: "transcCreate", name: "Search available captions", blurb: "Open a searchable panel only when text is present", group: "media" }
  ];
  var DEFAULT_FLAGS = {
    masterEnabled: true,
    annotations: true,
    bookmarks: true,
    advSearch: true,
    actionBar: false,
    altText: true,
    copyText: true,
    citations: true,
    continueWatching: true,
    cstblView: false,
    expandWidth: false,
    langCount: true,
    parLink: true,
    qrShare: true,
    officialOpen: true,
    verseAudio: true,
    mediaPlayerUI: true,
    customSub: true,
    imgGet: false,
    mediaCtrl: true,
    mediaTS: true,
    mediaClip: true,
    sndDisp: true,
    transcCreate: true
  };

  // packages/studynav/src/i18n.ts
  var EN_MESSAGES = {
    extension_name: "StudyNav \u2014 Unofficial Study Tools",
    extension_short_name: "StudyNav",
    extension_description: "Unofficial local study helpers for public JW.org pages. No telemetry or uploads; not affiliated with Jehovah\u2019s Witnesses.",
    command_adv_search: "Open the StudyNav command palette",
    popup_header_title: "StudyNav",
    popup_header_subtitle: "Unofficial \xB7 local processing \xB7 supported pages only",
    tools: "Tools",
    tools_title: "Enable or disable all StudyNav tools",
    tools_aria: "Enable all StudyNav tools",
    checking_page: "Checking this page\u2026",
    open_supported_page: "Open a supported JW.org page to use study tools.",
    page_tools: "Page tools",
    study_library: "Study library",
    save_place: "Save place",
    remove_saved_place: "Remove saved place",
    copy_citation: "Copy citation",
    show_qr: "Show QR",
    open_official_link: "Open clean publication link",
    image_search: "Search JW images with Google",
    image_search_placeholder: "What picture do you need?",
    image_search_external: "Opens an external Google search",
    reset_defaults: "Reset recommended defaults",
    defaults_restored: "Recommended defaults restored",
    what_it_gives_you: "What it gives you",
    guide_bible_label: "Bible:",
    guide_bible_text: "select one verse, or choose Select several and then the last verse. Download audio saves the selection as one WAV file.",
    guide_study_label: "Study:",
    guide_study_text: "select text to highlight it, add a note, or save an exact place.",
    guide_articles_label: "Articles:",
    guide_articles_text: "hover or focus text for Copy, Link, and Mark actions.",
    guide_media_label: "Media:",
    guide_media_text: "choose StudyNav on the player for links with time, media segments, a separate window, and captions.",
    feature_settings: "Feature settings",
    filter_features: "Filter features",
    find_setting: "Find a setting\u2026",
    footer_quick_search: "Quick search: Ctrl/Cmd+Shift+K",
    footer_privacy: "No telemetry \xB7 no uploads",
    group_study: "Study & sharing",
    group_core: "Bible & articles",
    group_layout: "Reading layout",
    group_media: "Video & audio",
    enabled_count: "$1 on",
    status_tools_off_title: "Study tools are off",
    status_tools_off_hint: "Turn on Tools above to restore helpers on supported pages.",
    status_unavailable_title: "No tools on this page",
    status_unavailable_hint: "Open a JW.org Bible chapter, library article, or media page.",
    status_bible_title: "Ready on this Bible chapter",
    status_bible_selected: "Verse $1:$2 is selected. Choose Select several to include the verses that follow.",
    status_bible_range: "Verses $1:$2\u2013$3 are selected. Copy, Link, and Download audio use the whole range.",
    status_bible_hint: "Select a verse number for text, a direct link, or audio. Select several consecutive verses when needed.",
    status_media_title: "Ready on this media page",
    status_media_hint: "Choose StudyNav on the player for links with time, media segments, a separate window, and captions.",
    status_article_title: "Ready on this article",
    status_article_hint: "Hover or focus article text for Copy and Link. Optional image downloads are in Feature settings.",
    status_palette_title: "Quick search is ready",
    status_palette_hint: "Press Ctrl/Cmd+Shift+K to find a publication or DOCID.",
    working: "Working\u2026",
    preparing: "Preparing\u2026",
    done: "Done",
    unavailable_here: "Unavailable here",
    no_active_tab: "No active tab",
    place_saved: "Place saved",
    saved_place_removed: "Saved place removed",
    bookmark_limit: "The local saved-place limit has been reached.",
    remove_saved_place_confirm: "Remove this saved place?",
    feature_annotations_name: "Highlights, notes & tags",
    feature_annotations_blurb: "Keep six-color highlights and searchable notes locally",
    feature_bookmarks_name: "Save a place to return to",
    feature_bookmarks_blurb: "Keep an exact page, paragraph, verse, or verse range in the Study library",
    feature_citations_name: "Copy a quote with its source",
    feature_citations_blurb: "Copy selected words with the publication title, reference, and direct JW link",
    feature_qrShare_name: "Show QR for this page",
    feature_qrShare_blurb: "Create a local QR code for the precise official page link",
    feature_officialOpen_name: "Clean publication link",
    feature_officialOpen_blurb: "Open the same publication through JW.org without extra address parameters",
    feature_verseAudio_name: "Download audio for selected verses",
    feature_verseAudio_blurb: "Save one verse or several consecutive verses as one WAV file",
    feature_copyText_name: "Copy clean text",
    feature_copyText_blurb: "Copy without verse numbers, reference letters, or StudyNav controls",
    feature_parLink_name: "Copy precise link",
    feature_parLink_blurb: "Copy a direct link to a paragraph, verse, or verse range",
    feature_advSearch_name: "Search by publication code",
    feature_advSearch_blurb: "Open the existing JW search for a publication code or document number",
    feature_altText_name: "Image descriptions",
    feature_altText_blurb: "Show alt text and captions below article images",
    feature_imgGet_name: "Download article images",
    feature_imgGet_blurb: "Add a compact download button beside article images",
    feature_langCount_name: "Available languages",
    feature_langCount_blurb: "Show the number of languages for an article",
    feature_actionBar_name: "Keep page header visible",
    feature_actionBar_blurb: "Keep the JW.org header in view while scrolling",
    feature_expandWidth_name: "Wider reading column",
    feature_expandWidth_blurb: "Use more of the window for article text",
    feature_cstblView_name: "Clearer tables",
    feature_cstblView_blurb: "Add spacing and row separation to article tables",
    feature_mediaPlayerUI_name: "Remove video shading",
    feature_mediaPlayerUI_blurb: "Keep the picture clear when the player controls appear",
    feature_customSub_name: "Larger subtitles",
    feature_customSub_blurb: "Increase subtitle size and background contrast",
    feature_mediaCtrl_name: "Media keyboard shortcuts",
    feature_mediaCtrl_blurb: "Use Space/K/J/L/F/M while watching media",
    feature_mediaTS_name: "Copy link at current time",
    feature_mediaTS_blurb: "Copy a page link that opens at the current playback time",
    feature_mediaClip_name: "Download a media segment",
    feature_mediaClip_blurb: "Enter start and end times, then save audio as WAV or video as WebM",
    feature_continueWatching_name: "Continue watching",
    feature_continueWatching_blurb: "Keep video progress locally and resume only when asked",
    feature_sndDisp_name: "Open in a separate window",
    feature_sndDisp_blurb: "Open the current media in its own browser window",
    feature_transcCreate_name: "Search available captions",
    feature_transcCreate_blurb: "Open a searchable panel only when text is present",
    copied: "Copied",
    copy_failed: "Copy failed",
    study_tools_off: "Study tools are off",
    annotations_off: "Highlights and notes are off",
    bookmarks_off: "Saved places are off",
    citations_off: "Citations are off",
    qr_sharing_off: "QR sharing is off",
    official_links_off: "Publication links are off",
    action_failed: "Action failed",
    citation_unavailable: "Citation unavailable",
    citation_copied: "Citation copied",
    qr_unavailable: "QR unavailable",
    qr_title: "QR for this page",
    close: "Close",
    close_qr_aria: "Close QR",
    qr_image_aria: "QR code for the displayed JW link",
    copy_link: "Copy link",
    link_copied: "Link copied",
    qr_opened: "QR opened",
    not_available_page: "Not available on this page",
    official_link_opened: "Clean publication link opened",
    palette_title: "Search by publication code",
    palette_placeholder: "Mnemonic / DOCID (for example w25.03, lff, wp24.01, mwb25.01)",
    palette_hint: "Enter to open \xB7 Esc to close \xB7 Unofficial StudyNav",
    study_tools_aria: "Study tools",
    download_audio: "Download audio",
    download_audio_title: "Download only this verse as audio",
    download_range_audio: "Download audio $1\u2013$2",
    download_range_audio_title: "Download verses $1\u2013$2 as one audio file",
    select_several_verses: "Select several",
    select_several_verses_title: "Choose the last verse in a consecutive range",
    cancel_range_selection: "Cancel range",
    cancel_range_selection_title: "Stop choosing a verse range",
    clear_verse_selection: "Clear selection",
    clear_verse_selection_title: "Clear the selected verse range",
    select_range_last_verse: "Now select the last verse.",
    verse_range_selected: "Verses $1\u2013$2 selected.",
    range_selection_cancelled: "Range selection cancelled",
    verse_selection_cleared: "Verse selection cleared",
    chapter_audio_not_ready: "Chapter audio is not ready. Open Play Audio once, then try again.",
    verse_audio_prepare_failed: "Verse audio could not be prepared.",
    verse_audio_downloaded: "Downloaded $1:$2 audio",
    verse_audio_download_failed: "Verse audio download failed.",
    mark: "Mark",
    mark_title: "Highlight this paragraph or verse and optionally add a private note",
    copy: "Copy",
    copy_text_title: "Copy without verse numbers, reference letters, or StudyNav controls",
    link: "Link",
    copy_paragraph_link_title: "Copy a link to this paragraph, verse, or selected verse range",
    languages_count: "$1 languages",
    media_tools: "Media tools",
    download_image: "Download image",
    image_download_started: "Image download started",
    copy_page_time: "Copy link at current time",
    page_time_copied: "Page link and time copied",
    media_clip: "Download a media segment",
    media_clip_title: "Download an audio or video segment",
    clip_format: "Format",
    clip_format_audio: "Audio (.wav) \xB7 up to 2 minutes",
    clip_format_video: "Video (.webm) \xB7 up to 1 minute",
    clip_start: "Start",
    clip_end: "End",
    clip_download_audio: "Download WAV",
    clip_download_video: "Record WebM",
    clip_cancel: "Cancel",
    clip_invalid_time: "Enter times as M:SS or H:MM:SS. The end must be after the start.",
    clip_too_long: "Choose a segment no longer than 2 minutes.",
    clip_video_too_long: "Choose a video segment no longer than 1 minute.",
    clip_preparing: "Preparing audio segment\u2026",
    clip_recording: "Recording video segment in real time\u2026",
    clip_downloaded: "Media segment downloaded",
    clip_failed: "The requested media segment could not be created.",
    clip_video_failed: "The video segment could not be created.",
    clip_video_recorder_failed: "The browser recorder failed while creating the video segment.",
    clip_video_timeout: "The video did not advance while the segment was being recorded.",
    clip_video_load_failed: "The official video could not be loaded for recording.",
    clip_video_unsupported: "This browser cannot record a video segment from this player.",
    clip_video_too_large: "The recorded video segment is too large to download safely.",
    clip_source_unavailable: "Play the media once so its source is available, then try again.",
    clip_request_rejected: "This media-segment request was rejected.",
    clip_source_download_failed: "The official media file could not be downloaded.",
    clip_source_too_large: "This media file is too large to process safely.",
    clip_outside_media: "The selected times are outside this media file.",
    second_display: "Open in a separate window",
    transcript: "Transcript",
    transcript_search: "Search\u2026",
    transcript_download: "Download .txt",
    close_transcript_aria: "Close transcript",
    loading: "Loading\u2026",
    no_matches: "(no matches)",
    no_transcript_detected: "No transcript text was detected on this page. If captions load later, reopen this panel.",
    annotation_limit: "The local annotation limit has been reached.",
    selection_cannot_save: "This selection cannot be saved.",
    note_updated: "Note updated",
    highlight_saved: "Highlight saved locally",
    select_one_paragraph: "Select text within one paragraph or verse.",
    select_character_count: "Select between 1 and $1 characters.",
    highlight_color_aria: "$1 highlight",
    reattach_note_aria: "Reattach note",
    highlight_selection_aria: "Highlight selected text",
    reattach_here: "Reattach here",
    note_missing: "That note no longer exists.",
    reattach_source_first: "Return to the note\u2019s source page before reattaching it.",
    reattach_cancelled: "Reattach cancelled",
    reattach_instruction: "Select the replacement text, then choose Reattach here.",
    cancel: "Cancel",
    add_note: "Add note",
    edit_highlight: "Edit highlight",
    new_highlight: "New highlight",
    close_highlight_editor_aria: "Close highlight editor",
    highlight_color: "Highlight color",
    color_yellow: "Yellow",
    color_green: "Green",
    color_blue: "Blue",
    color_pink: "Pink",
    color_purple: "Purple",
    color_orange: "Orange",
    page_notes: "Notes on this page",
    open_all_notes: "Open all notes",
    note: "Note",
    write_private_note: "Write a private note\u2026",
    tags: "Tags",
    tags_placeholder: "study, family, review",
    save_locally: "Save locally",
    tags_error: "Use at most 20 short, comma-separated tags.",
    paragraph_mark_unreliable: "This paragraph cannot be marked reliably.",
    needs_attention: "Needs attention",
    delete_highlight_confirm: "Delete this local highlight and note?",
    highlight_deleted: "Highlight deleted",
    locate: "Locate",
    open_page: "Open page",
    edit: "Edit",
    delete: "Delete",
    reattach: "Reattach",
    no_notes_filtered: "No notes match these filters.",
    no_notes_yet: "Select text on an article or verse to create your first highlight.",
    notes_count_one: "$1 note",
    notes_count_many: "$1 notes",
    study_export_failed: "Study data could not be exported.",
    study_backup_downloaded: "Study backup downloaded",
    backup_too_large: "Backup is larger than 5 MB.",
    backup_invalid: "That is not a valid StudyNav backup.",
    import_summary: "Import: $1 added, $2 updated, $3 ignored, $4 rejected",
    notes_tab: "Notes",
    saved_places_tab: "Saved places",
    this_page: "This page",
    all_notes: "All notes",
    all_pages: "All pages",
    search_notes: "Search study notes",
    search_notes_placeholder: "Search quote, note, or tag\u2026",
    search_saved_places: "Search saved places",
    filter_notes_tag: "Filter study notes by tag",
    all_tags: "All tags",
    export_json: "Export JSON",
    import_json: "Import JSON",
    study_library_opened: "Study library opened",
    close_study_library_aria: "Close study library",
    saved_places_count_one: "$1 saved place",
    saved_places_count_many: "$1 saved places",
    no_saved_places_filtered: "No saved places match these filters.",
    no_saved_places_yet: "Save a page, paragraph, or verse to return to it quickly.",
    open_saved_place: "Open",
    remove_saved_place_action: "Remove",
    local_study_data_invalid: "Local study data is invalid and was left unchanged.",
    study_data_validation_failed: "Study data update failed validation.",
    study_data_save_failed: "Study data could not be saved.",
    migration_save_failed: "Migrated study data could not be saved.",
    video_progress_save_failed: "Video progress could not be saved.",
    resume_at: "Resume at $1",
    resume_title: "Seek to saved local progress without starting playback",
    ready_at: "Ready at $1. Press play when you want.",
    resume_wait_loading: "The video must finish loading before it can resume.",
    verse_request_rejected: "This verse audio request was rejected.",
    verse_job_busy: "Another media clip is already being prepared.",
    verse_processing_failed: "Verse audio processing failed.",
    verse_page_unverified: "The Bible page could not be verified.",
    verse_request_invalid: "The selected verse audio request is not valid.",
    verse_timing_unavailable: "The official verse timing data is unavailable.",
    verse_timing_redirected: "The official verse timing request was redirected unexpectedly.",
    verse_timing_missing: "No official audio timing was found for this verse.",
    chapter_audio_download_failed: "The official chapter audio could not be downloaded.",
    chapter_audio_redirected: "The official chapter audio was redirected unexpectedly.",
    decoded_audio_invalid: "Decoded chapter audio is invalid.",
    verse_outside_audio: "The selected verse is outside the chapter audio.",
    verse_audio_too_large: "The selected verse audio is too large to download safely.",
    chapter_audio_too_large: "The chapter audio is too large to process safely.",
    chapter_audio_size_mismatch: "The chapter audio size does not match its official metadata."
  };
  function fallbackFormat(message, substitutions) {
    const values = substitutions === void 0 ? [] : Array.isArray(substitutions) ? substitutions : [substitutions];
    return values.reduce((result, value, index) => result.replaceAll(`$${index + 1}`, value), message);
  }
  function t(key, substitutions) {
    try {
      if (typeof chrome !== "undefined" && chrome.i18n?.getMessage) {
        const translated = chrome.i18n.getMessage(key, substitutions);
        if (translated) return translated;
      }
    } catch {
    }
    return fallbackFormat(EN_MESSAGES[key], substitutions);
  }
  function featureNameKey(id) {
    return `feature_${id}_name`;
  }
  function featureBlurbKey(id) {
    return `feature_${id}_blurb`;
  }
  function uiLanguage() {
    try {
      const locale = chrome.i18n?.getUILanguage?.() || "";
      return /^ru(?:-|$)/i.test(locale) ? "ru" : "en";
    } catch {
      return "en";
    }
  }
  function localizeDocument(root = document) {
    if (root === document) {
      document.documentElement.lang = uiLanguage();
      document.title = t("extension_name");
    }
    root.querySelectorAll("[data-i18n]").forEach((element) => {
      element.textContent = t(element.dataset.i18n);
    });
    root.querySelectorAll("[data-i18n-title]").forEach((element) => {
      element.title = t(element.dataset.i18nTitle);
    });
    root.querySelectorAll("[data-i18n-aria-label]").forEach((element) => {
      element.setAttribute("aria-label", t(element.dataset.i18nAriaLabel));
    });
    root.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
      element.placeholder = t(element.dataset.i18nPlaceholder);
    });
  }

  // packages/studynav/src/page-origin.ts
  var STUDYNAV_PAGE_HOSTS = ["jw.org", "www.jw.org", "wol.jw.org"];
  var allowedHosts = new Set(STUDYNAV_PAGE_HOSTS);

  // packages/studynav/src/document-actions.ts
  var IMAGE_SEARCH_BASE = "https://cse.google.com/cse?cx=3c6c549b8ed4c34fe";
  function buildImageSearchUrl(query) {
    const clean = cleanCitationText(query).slice(0, 200);
    if (!clean) return null;
    const url = new URL(IMAGE_SEARCH_BASE);
    url.hash = new URLSearchParams({ "gsc.tab": "0", "gsc.q": clean, "gsc.page": "1" }).toString();
    return url.toString();
  }
  function cleanCitationText(value) {
    return String(value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
  }

  // packages/studynav/src/popup.ts
  var list = document.getElementById("list");
  var filterEl = document.getElementById("filter");
  var masterEl = document.getElementById("master");
  var enabledCountEl = document.getElementById("enabled-count");
  var statusEl = document.getElementById("page-status");
  var statusTitleEl = document.getElementById("status-title");
  var statusHintEl = document.getElementById("status-hint");
  var actionFeedbackEl = document.getElementById("action-feedback");
  var actionButtons = Array.from(document.querySelectorAll(".action-grid button"));
  var currentFlags = { ...DEFAULT_FLAGS };
  var currentPageStatus = null;
  async function load() {
    return chrome.runtime.sendMessage({ type: "GET_FLAGS" });
  }
  function enabledCount(flags) {
    return FEATURE_META.filter((meta) => flags[meta.id]).length;
  }
  function updateEnabledCount() {
    enabledCountEl.textContent = t("enabled_count", String(enabledCount(currentFlags)));
  }
  function row(meta, on) {
    const el = document.createElement("div");
    el.className = "row";
    const name = t(featureNameKey(meta.id));
    const blurb = t(featureBlurbKey(meta.id));
    el.dataset.name = `${name} ${blurb} ${meta.group}`.toLocaleLowerCase();
    const copy = document.createElement("div");
    const nameEl = document.createElement("div");
    nameEl.className = "name";
    nameEl.textContent = name;
    const blurbEl = document.createElement("div");
    blurbEl.className = "blurb";
    blurbEl.textContent = blurb;
    copy.append(nameEl, blurbEl);
    const label = document.createElement("label");
    label.className = "switch";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.dataset.id = meta.id;
    input.setAttribute("aria-label", name);
    input.checked = on;
    label.append(input, document.createElement("span"));
    el.append(copy, label);
    input.addEventListener("change", async (e) => {
      const id = meta.id;
      const value = e.target.checked;
      await chrome.runtime.sendMessage({ type: "SET_FLAG", id, value });
      currentFlags = { ...currentFlags, [id]: value };
      updateEnabledCount();
      updateActionAvailability();
    });
    return el;
  }
  function applyFilter() {
    const q = filterEl.value.trim().toLowerCase();
    list.querySelectorAll(".row").forEach((el) => {
      const hay = el.dataset.name || "";
      el.classList.toggle("hidden", !!q && !hay.includes(q));
    });
  }
  async function readPageStatus() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return null;
      const status = await chrome.tabs.sendMessage(tab.id, { type: "GET_STUDYNAV_STATUS" });
      return status && typeof status === "object" ? status : null;
    } catch {
      return null;
    }
  }
  async function renderPageStatus() {
    const status = await readPageStatus();
    currentPageStatus = status;
    updateActionAvailability();
    if (currentFlags.masterEnabled === false || status?.masterEnabled === false) {
      statusEl.dataset.state = "off";
      statusTitleEl.textContent = t("status_tools_off_title");
      statusHintEl.textContent = t("status_tools_off_hint");
      return;
    }
    if (!status || status.supported !== true || status.active !== true) {
      statusEl.dataset.state = "idle";
      statusTitleEl.textContent = t("status_unavailable_title");
      statusHintEl.textContent = t("status_unavailable_hint");
      return;
    }
    statusEl.dataset.state = "ready";
    if (status.kind === "bible") {
      const selected = status.selectedVerse;
      const selectedRange = status.selectedVerseRange;
      statusTitleEl.textContent = t("status_bible_title");
      statusHintEl.textContent = selectedRange && typeof selectedRange === "object" && "chapter" in selectedRange && "startVerse" in selectedRange && "endVerse" in selectedRange ? t("status_bible_range", [
        String(selectedRange.chapter),
        String(selectedRange.startVerse),
        String(selectedRange.endVerse)
      ]) : selected && typeof selected === "object" && "chapter" in selected && "verse" in selected ? t("status_bible_selected", [String(selected.chapter), String(selected.verse)]) : t("status_bible_hint");
    } else if (status.kind === "media") {
      statusTitleEl.textContent = t("status_media_title");
      statusHintEl.textContent = t("status_media_hint");
    } else if (status.kind === "article") {
      statusTitleEl.textContent = t("status_article_title");
      statusHintEl.textContent = t("status_article_hint");
    } else {
      statusTitleEl.textContent = t("status_palette_title");
      statusHintEl.textContent = t("status_palette_hint");
    }
  }
  function updateActionAvailability() {
    const ready = currentFlags.masterEnabled !== false && currentPageStatus?.supported === true && currentPageStatus?.active === true;
    for (const button of actionButtons) {
      const feature = button.dataset.feature;
      const anyFeatures = (button.dataset.anyFeature || "").split(",").filter(Boolean);
      const enabledByFlag = feature ? !!currentFlags[feature] : anyFeatures.some((id) => !!currentFlags[id]);
      const officialUnavailable = button.id === "open-official" && currentPageStatus?.officialOpenAvailable !== true;
      const bookmarkUnavailable = button.id === "save-place" && currentPageStatus?.bookmarkAvailable !== true;
      button.disabled = !ready || !enabledByFlag || officialUnavailable || bookmarkUnavailable;
    }
    const saveButton = document.getElementById("save-place");
    if (saveButton) saveButton.textContent = t(currentPageStatus?.bookmarkSaved === true ? "remove_saved_place" : "save_place");
  }
  var ACTION_MESSAGES = {
    "open-notes": "OPEN_STUDY_PANEL",
    "save-place": "TOGGLE_STUDY_BOOKMARK",
    "copy-citation": "COPY_STUDY_CITATION",
    "show-qr": "SHOW_STUDY_QR",
    "open-official": "OPEN_OFFICIAL_JW_LINK"
  };
  async function runPageAction(button) {
    const type = ACTION_MESSAGES[button.id];
    if (!type || button.disabled) return;
    button.disabled = true;
    actionFeedbackEl.textContent = t("working");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error(t("no_active_tab"));
      const result = await chrome.tabs.sendMessage(tab.id, { type });
      const message = result && typeof result === "object" && "message" in result && typeof result.message === "string" ? result.message : t("done");
      actionFeedbackEl.textContent = message;
      if (button.id === "save-place") await renderPageStatus();
    } catch {
      actionFeedbackEl.textContent = t("unavailable_here");
    } finally {
      window.setTimeout(() => {
        actionFeedbackEl.textContent = "";
        updateActionAvailability();
      }, 1400);
    }
  }
  (async () => {
    localizeDocument();
    currentFlags = { ...DEFAULT_FLAGS, ...await load() };
    masterEl.checked = currentFlags.masterEnabled !== false;
    masterEl.addEventListener("change", async () => {
      await chrome.runtime.sendMessage({ type: "SET_FLAG", id: "masterEnabled", value: masterEl.checked });
      currentFlags = { ...currentFlags, masterEnabled: masterEl.checked };
      await renderPageStatus();
    });
    list.innerHTML = "";
    const groups = [
      { key: "study", title: "group_study" },
      { key: "core", title: "group_core" },
      { key: "layout", title: "group_layout" },
      { key: "media", title: "group_media" }
    ];
    for (const g of groups) {
      const h = document.createElement("div");
      h.className = "group";
      h.textContent = t(g.title);
      list.appendChild(h);
      for (const meta of FEATURE_META.filter((m) => m.group === g.key)) {
        list.appendChild(row(meta, !!currentFlags[meta.id]));
      }
    }
    filterEl.addEventListener("input", applyFilter);
    actionButtons.forEach((button) => button.addEventListener("click", () => void runPageAction(button)));
    document.getElementById("image-search")?.addEventListener("submit", (event) => {
      event.preventDefault();
      const input = document.getElementById("image-search-query");
      const url = input ? buildImageSearchUrl(input.value) : null;
      if (url) void chrome.tabs.create({ url });
    });
    document.getElementById("reset-defaults")?.addEventListener("click", async () => {
      await chrome.runtime.sendMessage({ type: "SET_FLAGS", flags: DEFAULT_FLAGS });
      currentFlags = { ...DEFAULT_FLAGS };
      masterEl.checked = true;
      list.querySelectorAll("input[data-id]").forEach((input) => {
        input.checked = !!currentFlags[input.dataset.id];
      });
      actionFeedbackEl.textContent = t("defaults_restored");
      updateEnabledCount();
      await renderPageStatus();
      window.setTimeout(() => {
        actionFeedbackEl.textContent = "";
      }, 1600);
    });
    updateEnabledCount();
    await renderPageStatus();
  })();
})();
//# sourceMappingURL=popup.js.map
