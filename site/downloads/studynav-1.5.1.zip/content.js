"use strict";
(() => {
  // packages/studynav/src/features.ts
  var DEFAULT_FLAGS = {
    masterEnabled: true,
    annotations: true,
    bookmarks: true,
    advSearch: true,
    actionBar: false,
    altText: true,
    copyText: true,
    citations: true,
    continueWatching: true,
    cstblView: false,
    expandWidth: false,
    langCount: true,
    parLink: true,
    qrShare: true,
    officialOpen: true,
    verseAudio: true,
    mediaPlayerUI: true,
    customSub: true,
    imgGet: false,
    mediaCtrl: true,
    mediaTS: true,
    mediaClip: true,
    sndDisp: true,
    transcCreate: true
  };

  // packages/studynav/src/apply-coordinator.ts
  function createApplyCoordinator(deps, delayMs = 80) {
    let applying = false;
    let pending = false;
    let timer;
    const flush = () => {
      deps.clearTimer(timer);
      timer = void 0;
      if (applying) {
        pending = true;
        return;
      }
      applying = true;
      deps.disconnectObserver();
      try {
        deps.runApply();
      } finally {
        applying = false;
        deps.reconnectObserver();
        if (pending) {
          pending = false;
          schedule();
        }
      }
    };
    const schedule = () => {
      if (applying) {
        pending = true;
        return;
      }
      deps.clearTimer(timer);
      timer = deps.setTimer(flush, delayMs);
    };
    const cancel = () => {
      deps.clearTimer(timer);
      timer = void 0;
      pending = false;
    };
    return { cancel, flush, schedule };
  }

  // packages/studynav/src/mnemonics.ts
  var WOL_ROUTE_BY_LANG = {
    en: { route: "r1", locale: "lp-e" },
    ru: { route: "r2", locale: "lp-u" },
    uk: { route: "r15", locale: "lp-k" }
  };
  var MONTHS = ["", "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
  function langFromPath(pathname) {
    const m = pathname.match(/^\/([a-z]{2}(?:-[a-z]+)?)(\/|$)/i);
    return (m?.[1] || "en").toLowerCase();
  }
  function wolRouteForLang(lang) {
    return WOL_ROUTE_BY_LANG[lang] ?? null;
  }
  function jwSearch(lang, q) {
    return `https://www.jw.org/${lang}/search/?q=${encodeURIComponent(q)}`;
  }
  function libraryFinder(lang, q) {
    return `https://www.jw.org/${lang}/library/?q=${encodeURIComponent(q)}`;
  }
  function wolSearchUrl(lang, q) {
    const route = wolRouteForLang(lang);
    if (!route) return null;
    return `https://wol.jw.org/${lang}/wol/s/${route.route}/${route.locale}?q=${encodeURIComponent(q)}`;
  }
  function wolDocumentUrl(lang, docId) {
    const route = wolRouteForLang(lang);
    if (!route) return null;
    return `https://wol.jw.org/${lang}/wol/d/${route.route}/${route.locale}/${docId}`;
  }
  function pushIfUrl(out, label, url) {
    if (url) out.push({ label, url });
  }
  function resolveQueryForLang(q, lang) {
    const query = q.trim();
    if (!query) return [];
    const out = [];
    if (/^\d{6,}$/.test(query)) {
      out.push({ label: `DOCID ${query} - jw.org search`, url: jwSearch(lang, query) });
      pushIfUrl(out, `DOCID ${query} - WOL document`, wolDocumentUrl(lang, query));
      out.push({ label: `DOCID ${query} - library finder`, url: libraryFinder(lang, query) });
      return out;
    }
    let m = query.match(/^w\s*(\d{2})\.(\d{1,2})$/i) || query.match(/^w\s*(\d{2})\s+(\d{1,2})$/i);
    if (m) {
      const yy = m[1];
      const mm = m[2].padStart(2, "0");
      const month = MONTHS[Number(mm)] || mm;
      out.push({
        label: `Watchtower Study w${yy}.${mm}`,
        url: `https://www.jw.org/${lang}/library/magazines/?contentLanguageFilter=${lang}&pubFilter=w&yearFilter=20${yy}`
      });
      out.push({
        label: `Search Watchtower Study ${month} 20${yy}`,
        url: jwSearch(lang, `w${yy}.${mm}`)
      });
      pushIfUrl(out, `WOL search w${yy}.${mm}`, wolSearchUrl(lang, `w${yy}.${mm}`));
    }
    m = query.match(/^wp\s*(\d{2})\.(\d{1,2})$/i);
    if (m) {
      const yy = m[1];
      const mm = m[2].padStart(2, "0");
      out.push({ label: `Watchtower (Public) wp${yy}.${mm}`, url: jwSearch(lang, `wp${yy}.${mm}`) });
      out.push({
        label: `Magazines filter wp 20${yy}`,
        url: `https://www.jw.org/${lang}/library/magazines/?pubFilter=wp&yearFilter=20${yy}`
      });
    }
    m = query.match(/^g\s*(\d{2})\.(\d{1,2})$/i);
    if (m) {
      out.push({ label: `Awake! g${m[1]}.${m[2]}`, url: jwSearch(lang, `g${m[1]}.${m[2]}`) });
      out.push({
        label: `Awake! magazines 20${m[1]}`,
        url: `https://www.jw.org/${lang}/library/magazines/?pubFilter=g&yearFilter=20${m[1]}`
      });
    }
    m = query.match(/^mwb\s*(\d{2})\.(\d{1,2})$/i) || query.match(/^mw\s*(\d{2})\.(\d{1,2})$/i);
    if (m) {
      const yy = m[1];
      const mm = m[2].padStart(2, "0");
      out.push({ label: `Meeting Workbook mwb${yy}.${mm}`, url: jwSearch(lang, `mwb${yy}.${mm}`) });
      pushIfUrl(out, `WOL search mwb${yy}.${mm}`, wolSearchUrl(lang, `mwb${yy}.${mm}`));
    }
    const pubs = {
      lff: {
        title: "Enjoy Life Forever!",
        paths: [
          `https://www.jw.org/${lang}/library/books/enjoy-life-forever/`,
          jwSearch(lang, "lff")
        ]
      },
      nwtsty: {
        title: "NWT Study Bible",
        paths: [
          `https://www.jw.org/${lang}/library/bible/study-bible/books/`,
          jwSearch(lang, "nwtsty")
        ]
      },
      nwt: {
        title: "New World Translation",
        paths: [
          `https://www.jw.org/${lang}/library/bible/`,
          jwSearch(lang, "nwt")
        ]
      },
      bh: {
        title: "What Does the Bible Really Teach?",
        paths: [jwSearch(lang, "bh"), libraryFinder(lang, "bh")]
      },
      bt: {
        title: "Bible Teach",
        paths: [jwSearch(lang, "bt")]
      },
      jy: {
        title: "Jesus-The Way",
        paths: [jwSearch(lang, "jy"), libraryFinder(lang, "jy")]
      },
      it: {
        title: "Insight on the Scriptures",
        paths: [wolSearchUrl(lang, "it"), jwSearch(lang, "insight")]
      },
      w: {
        title: "The Watchtower",
        paths: [
          `https://www.jw.org/${lang}/library/magazines/?pubFilter=w`,
          jwSearch(lang, "watchtower")
        ]
      },
      wp: {
        title: "Watchtower (Public)",
        paths: [
          `https://www.jw.org/${lang}/library/magazines/?pubFilter=wp`,
          jwSearch(lang, "wp")
        ]
      },
      g: {
        title: "Awake!",
        paths: [
          `https://www.jw.org/${lang}/library/magazines/?pubFilter=g`,
          jwSearch(lang, "awake")
        ]
      },
      mwb: {
        title: "Meeting Workbook",
        paths: [jwSearch(lang, "mwb"), wolSearchUrl(lang, "mwb")]
      },
      sjj: {
        title: "Sing Out Joyfully",
        paths: [jwSearch(lang, "sjj"), libraryFinder(lang, "sjj")]
      },
      ijwbq: {
        title: "Research Guide / index",
        paths: [jwSearch(lang, "ijwbq"), wolSearchUrl(lang, "ijwbq")]
      }
    };
    const key = query.toLowerCase();
    if (pubs[key]) {
      const pub = pubs[key];
      pub.paths.forEach((url, i) => {
        if (!url) return;
        out.push({ label: `${pub.title} (${key})${i ? ` - alt ${i}` : ""}`, url });
      });
    }
    out.push({ label: `Search "${query}" on jw.org`, url: jwSearch(lang, query) });
    pushIfUrl(out, `Search "${query}" on WOL`, wolSearchUrl(lang, query));
    out.push({ label: `Library finder "${query}"`, url: libraryFinder(lang, query) });
    const seen = /* @__PURE__ */ new Set();
    return out.filter((target) => seen.has(target.url) ? false : (seen.add(target.url), true));
  }
  function resolveQuery(q) {
    return resolveQueryForLang(q, langFromPath(location.pathname));
  }

  // packages/studynav/src/document-actions.ts
  var SUPPORTED_HOSTS = /* @__PURE__ */ new Set(["www.jw.org", "jw.org", "wol.jw.org", "stream.jw.org"]);
  var TRACKING_PARAMS = /* @__PURE__ */ new Set(["srcid", "wtlocale", "prefer"]);
  function finiteToken(value, pattern, maxLength) {
    const token = String(value || "").trim();
    return token && token.length <= maxLength && pattern.test(token) ? token : null;
  }
  function isSupportedJwHttpsUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && SUPPORTED_HOSTS.has(url.hostname.toLowerCase());
    } catch {
      return false;
    }
  }
  function canonicalStudyUrl(currentUrl, canonicalHref) {
    const candidate = canonicalHref && isSupportedJwHttpsUrl(canonicalHref) ? canonicalHref : currentUrl;
    if (!isSupportedJwHttpsUrl(candidate)) return null;
    const url = new URL(candidate);
    url.hash = "";
    for (const key of [...url.searchParams.keys()]) {
      if (TRACKING_PARAMS.has(key.toLowerCase()) || key.toLowerCase().startsWith("utm_")) {
        url.searchParams.delete(key);
      }
    }
    return url.toString();
  }
  function preciseStudyUrl(baseUrl, fragment) {
    if (!isSupportedJwHttpsUrl(baseUrl)) return null;
    const url = new URL(baseUrl);
    const cleanFragment = finiteToken(fragment, /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/, 128);
    if (cleanFragment) url.hash = cleanFragment;
    return url.toString();
  }
  function buildOfficialFinderUrl(metadata) {
    const wtLocale = finiteToken(metadata.wtLocale, /^[A-Za-z][A-Za-z0-9-]{0,7}$/, 8);
    if (!wtLocale) return null;
    const pub = finiteToken(metadata.pub, /^[A-Za-z0-9-]{1,32}$/, 32);
    const bible = finiteToken(metadata.bible, /^\d{7,12}(?:-\d{7,12})?$/, 25);
    const docId = finiteToken(metadata.docId, /^\d{6,16}$/, 16);
    const url = new URL("https://www.jw.org/finder");
    if (pub && bible && isValidBibleToken(bible)) {
      url.searchParams.set("pub", pub);
      url.searchParams.set("bible", bible);
    } else if (docId) {
      url.searchParams.set("docid", docId);
    } else {
      return null;
    }
    url.searchParams.set("wtlocale", wtLocale.toUpperCase());
    url.searchParams.set("srcid", "share");
    return url.toString();
  }
  function isValidBibleToken(value) {
    const [startText, endText] = value.split("-");
    const start = Number(startText);
    const end = endText ? Number(endText) : start;
    if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || end < start) return false;
    const startVerse = start % 1e3;
    const endVerse = end % 1e3;
    const sameChapter = Math.floor(start / 1e3) === Math.floor(end / 1e3);
    if (!endText) return startVerse >= 0 && startVerse <= 200;
    return sameChapter && startVerse >= 1 && startVerse <= 200 && endVerse >= startVerse && endVerse <= 200;
  }
  function formatPageAndTime(url, seconds) {
    if (!isSupportedJwHttpsUrl(url) || !Number.isFinite(seconds) || seconds < 0) return null;
    const whole = Math.floor(seconds);
    const hours = Math.floor(whole / 3600);
    const minutes = Math.floor(whole % 3600 / 60);
    const rest = whole % 60;
    const timestamp = hours ? `${hours}:${String(minutes).padStart(2, "0")}:${String(rest).padStart(2, "0")}` : `${minutes}:${String(rest).padStart(2, "0")}`;
    return `${url}
Time: ${timestamp}`;
  }
  function cleanCitationText(value) {
    return String(value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
  }
  function truncateCitationQuote(value, maxLength = 500) {
    const clean = cleanCitationText(value);
    if (clean.length <= maxLength) return clean;
    return `${clean.slice(0, Math.max(1, maxLength - 1)).trimEnd()}\u2026`;
  }
  function formatOnlineCitation(input) {
    if (!isSupportedJwHttpsUrl(input.url)) return null;
    const title = cleanCitationText(input.title) || "JW.ORG";
    const quote = truncateCitationQuote(input.quote || "");
    const reference = cleanCitationText(input.reference || "");
    if (!quote) return `${title}. JW.ORG: ${input.url}`;
    const source = reference ? `${reference}. ${title}` : title;
    return `\u201C${quote}\u201D \u2014 ${source}. JW.ORG: ${input.url}`;
  }

  // node_modules/.bun/qr@0.6.0/node_modules/qr/index.js
  var chCodes = { newline: 10, reset: 27 };
  function assertNumber(n) {
    if (!Number.isSafeInteger(n))
      throw new Error(`integer expected: ${n}`);
  }
  function validateVersion(ver) {
    if (!Number.isSafeInteger(ver) || ver < 1 || ver > 40)
      throw new Error(`Invalid version=${ver}. Expected number [1..40]`);
  }
  function bin(dec, pad) {
    return dec.toString(2).padStart(pad, "0");
  }
  function mod(a, b) {
    const result = a % b;
    return result >= 0 ? result : b + result;
  }
  function fillArr(length, val) {
    return new Array(length).fill(val);
  }
  function popcnt(n) {
    n = n - (n >>> 1 & 1431655765);
    n = (n & 858993459) + (n >>> 2 & 858993459);
    return (n + (n >>> 4) & 252645135) * 16843009 >>> 24;
  }
  function interleaveBytes(blocks) {
    let maxLen = 0;
    let totalLen = 0;
    for (const block of blocks) {
      maxLen = Math.max(maxLen, block.length);
      totalLen += block.length;
    }
    const result = new Uint8Array(totalLen);
    let idx = 0;
    for (let i = 0; i < maxLen; i++) {
      for (const block of blocks) {
        if (i < block.length)
          result[idx++] = block[i];
      }
    }
    return result;
  }
  function best() {
    let best2;
    let bestScore = Infinity;
    return {
      add(score, value) {
        if (score >= bestScore)
          return;
        best2 = value;
        bestScore = score;
      },
      get: () => best2,
      score: () => bestScore
    };
  }
  function alphabet(alphabet2) {
    return Object.freeze({
      has: (char) => alphabet2.includes(char),
      decode: (input) => {
        if (!Array.isArray(input) || input.length && typeof input[0] !== "string")
          throw new Error("alphabet.decode input should be array of strings");
        return input.map((letter) => {
          if (typeof letter !== "string")
            throw new Error(`alphabet.decode: not string element=${letter}`);
          const index = alphabet2.indexOf(letter);
          if (index === -1)
            throw new Error(`Unknown letter: "${letter}". Allowed: ${alphabet2}`);
          return index;
        });
      },
      encode: (digits) => {
        if (!Array.isArray(digits) || digits.length && typeof digits[0] !== "number")
          throw new Error("alphabet.encode input should be an array of numbers");
        return digits.map((i) => {
          assertNumber(i);
          if (i < 0 || i >= alphabet2.length)
            throw new Error(`Digit index outside alphabet: ${i} (alphabet: ${alphabet2.length})`);
          return alphabet2[i];
        });
      }
    });
  }
  function transpose32(a) {
    if (a.length !== 32)
      throw new Error("expects 32 element matrix");
    const masks = [1431655765, 858993459, 252645135, 16711935, 65535];
    for (let stage = 0; stage < 5; stage++) {
      const m = masks[stage] >>> 0;
      const s = 1 << stage;
      const step = s << 1;
      for (let i = 0; i < 32; i += step) {
        for (let k = 0; k < s; k++) {
          const i0 = i + k;
          const i1 = i0 + s;
          const x = a[i0] >>> 0;
          const y = a[i1] >>> 0;
          const t2 = (x >>> s ^ y) & m;
          a[i0] = (x ^ t2 << s) >>> 0;
          a[i1] = (y ^ t2) >>> 0;
        }
      }
    }
  }
  var bitMask = (x) => 1 << (x & 31) >>> 0;
  var rangeMask = (shift, len) => {
    if (len === 0)
      return 0;
    if (len === 32)
      return 4294967295;
    return (1 << len) - 1 << shift >>> 0;
  };
  var Bitmap = class _Bitmap {
    static size(size, limit) {
      if (typeof size === "number")
        size = { height: size, width: size };
      if (!Number.isSafeInteger(size.height) && size.height !== Infinity)
        throw new Error(`Bitmap: invalid height=${size.height} (${typeof size.height})`);
      if (!Number.isSafeInteger(size.width) && size.width !== Infinity)
        throw new Error(`Bitmap: invalid width=${size.width} (${typeof size.width})`);
      if (limit !== void 0) {
        size = {
          width: Math.min(size.width, limit.width),
          height: Math.min(size.height, limit.height)
        };
      }
      return size;
    }
    static fromString(s) {
      s = s.replace(/^\n+/g, "").replace(/\n+$/g, "");
      const lines = s.split(String.fromCharCode(chCodes.newline));
      const height = lines.length;
      let width;
      const rows = [];
      for (const line of lines) {
        const row = line.split("").map((i) => {
          if (i === "X")
            return true;
          if (i === " ")
            return false;
          if (i === "?")
            return void 0;
          throw new Error(`Bitmap.fromString: unknown symbol=${i}`);
        });
        if (width !== void 0 && row.length !== width)
          throw new Error(`Bitmap.fromString different row sizes: width=${width} cur=${row.length}`);
        width = row.length;
        rows.push(row);
      }
      if (width === void 0)
        width = 0;
      return new _Bitmap({ height, width }, rows);
    }
    // Two bitsets:
    // defined=0 -> undefined
    // defined=1,value=0 -> false
    // defined=1,value=1 -> true
    defined;
    value;
    tailMask;
    words;
    fullWords;
    height;
    width;
    constructor(size, data) {
      const { height, width } = _Bitmap.size(size);
      if (!Number.isSafeInteger(height) || height <= 0)
        throw new Error(`Bitmap: invalid height=${height}, expected positive safe integer dimension`);
      if (!Number.isSafeInteger(width) || width <= 0)
        throw new Error(`Bitmap: invalid width=${width}, expected positive safe integer dimension`);
      this.height = height;
      this.width = width;
      this.tailMask = rangeMask(0, width & 31 || 32);
      this.words = Math.ceil(width / 32) | 0;
      this.fullWords = Math.floor(width / 32) | 0;
      this.value = new Uint32Array(this.words * height);
      this.defined = new Uint32Array(this.value.length);
      if (data) {
        if (data.length !== height)
          throw new Error(`Bitmap: data height mismatch: exp=${height} got=${data.length}`);
        for (let y = 0; y < height; y++) {
          const row = data[y];
          if (!row || row.length !== width)
            throw new Error(`Bitmap: data width mismatch at y=${y}: exp=${width} got=${row?.length}`);
          for (let x = 0; x < width; x++)
            this.set(x, y, row[x]);
        }
      }
    }
    point(p) {
      return this.get(p.x, p.y);
    }
    // Raw bounds check for scan loops; unlike `xy()`, this does not wrap or normalize coordinates.
    isInside(p) {
      return 0 <= p.x && p.x < this.width && 0 <= p.y && p.y < this.height;
    }
    size(offset) {
      if (!offset)
        return { height: this.height, width: this.width };
      const { x, y } = this.xy(offset);
      return { height: this.height - y, width: this.width - x };
    }
    xy(c) {
      if (typeof c === "number")
        c = { x: c, y: c };
      if (!Number.isSafeInteger(c.x))
        throw new Error(`Bitmap: invalid x=${c.x}`);
      if (!Number.isSafeInteger(c.y))
        throw new Error(`Bitmap: invalid y=${c.y}`);
      c.x = mod(c.x, this.width);
      c.y = mod(c.y, this.height);
      return c;
    }
    /**
     * Return pixel bit index
     */
    wordIndex(x, y) {
      return y * this.words + (x >>> 5);
    }
    bitIndex(x, y) {
      return { word: this.wordIndex(x, y), bit: x & 31 };
    }
    isDefined(x, y) {
      const wi = this.wordIndex(x, y);
      const m = bitMask(x);
      return (this.defined[wi] & m) !== 0;
    }
    get(x, y) {
      const wi = this.wordIndex(x, y);
      const m = bitMask(x);
      return (this.value[wi] & m) !== 0;
    }
    maskWord(wi, mask, v) {
      const { defined, value } = this;
      defined[wi] |= mask;
      value[wi] = value[wi] & ~mask | -v & mask;
    }
    set(x, y, v) {
      if (v === void 0)
        return;
      this.maskWord(this.wordIndex(x, y), bitMask(x), v);
    }
    // word-span fill for constant values (fast path)
    fillRectConst(x0, y0, w, h, v) {
      if (w <= 0 || h <= 0)
        return;
      if (v === void 0)
        return;
      const { value, defined, words } = this;
      const startWord = x0 >>> 5;
      const endWord = x0 + w - 1 >>> 5;
      const startBit = x0 & 31;
      const endBit = x0 + w - 1 & 31;
      for (let ry = 0; ry < h; ry++) {
        const rowBase = (y0 + ry) * words;
        if (startWord === endWord) {
          const mask = rangeMask(startBit, endBit - startBit + 1);
          this.maskWord(rowBase + startWord, mask, v);
          continue;
        }
        this.maskWord(rowBase + startWord, rangeMask(startBit, 32 - startBit), v);
        for (let i = startWord + 1; i < endWord; i++) {
          defined[rowBase + i] = 4294967295;
          value[rowBase + i] = v ? 4294967295 : 0;
        }
        this.maskWord(rowBase + endWord, rangeMask(0, endBit + 1), v);
      }
    }
    rectWords(x, y, width, height, cb) {
      for (let yPos = 0; yPos < height; yPos++) {
        const Py = y + yPos;
        for (let xPos = 0; xPos < width; ) {
          const bitX = x + xPos;
          const { bit, word } = this.bitIndex(bitX, Py);
          const bitsPerWord = Math.min(32 - bit, width - xPos);
          cb(word, bitX, xPos, yPos, bitsPerWord);
          xPos += bitsPerWord;
        }
      }
    }
    // Basically every operation can be represented as rect
    rect(c, size, fn) {
      const { x, y } = this.xy(c);
      const { height, width } = _Bitmap.size(size, this.size({ x, y }));
      if (typeof fn !== "function") {
        this.fillRectConst(x, y, width, height, fn);
        return this;
      }
      const { defined, value } = this;
      this.rectWords(x, y, width, height, (wi, bitX, xPos, yPos, n) => {
        let defWord = 0;
        let valWord = value[wi];
        for (let b = 0; b < n; b++) {
          const mask = bitMask(bitX + b);
          const res = fn({ x: xPos + b, y: yPos }, (valWord & mask) !== 0);
          if (res === void 0)
            continue;
          defWord |= mask;
          valWord = valWord & ~mask | -res & mask;
        }
        defined[wi] |= defWord;
        value[wi] = valWord;
      });
      return this;
    }
    // returns rectangular part of bitmap
    rectRead(c, size, fn) {
      const { x, y } = this.xy(c);
      const { height, width } = _Bitmap.size(size, this.size({ x, y }));
      const { value } = this;
      this.rectWords(x, y, width, height, (wi, bitX, xPos, yPos, n) => {
        const valWord = value[wi];
        for (let b = 0; b < n; b++) {
          const mask = bitMask(bitX + b);
          fn({ x: xPos + b, y: yPos }, (valWord & mask) !== 0);
        }
      });
      return this;
    }
    // Horizontal & vertical lines
    hLine(c, len, value) {
      return this.rect(c, { width: len, height: 1 }, value);
    }
    vLine(c, len, value) {
      return this.rect(c, { width: 1, height: len }, value);
    }
    // add border
    border(border = 2, value) {
      if (!Number.isSafeInteger(border) || border <= 0)
        throw new Error(`Bitmap.border: invalid size=${border}`);
      const height = this.height + 2 * border;
      const width = this.width + 2 * border;
      const out = new _Bitmap({ height, width });
      out.rect(0, Infinity, value);
      out.embed({ x: border, y: border }, this);
      return out;
    }
    // Embed another bitmap on coordinates
    embed(c, src) {
      const { x, y } = this.xy(c);
      const { height, width } = _Bitmap.size(src.size(), this.size({ x, y }));
      if (width <= 0 || height <= 0)
        return this;
      const { value, defined } = this;
      const { words: srcStride, value: srcValue } = src;
      for (let yPos = 0; yPos < height; yPos++) {
        const srcRow = yPos * srcStride;
        for (let xPos = 0; xPos < width; ) {
          const dstX = x + xPos;
          const { word: dstWord, bit: dstBit } = this.bitIndex(dstX, y + yPos);
          const { word: srcWord, bit: srcBit } = src.bitIndex(xPos, yPos);
          const len = Math.min(32 - dstBit, width - xPos);
          const w0 = srcValue[srcWord];
          const w1 = srcBit && srcWord + 1 < srcRow + srcStride ? srcValue[srcWord + 1] : 0;
          const sVal = srcBit ? (w0 >>> srcBit | w1 << 32 - srcBit) >>> 0 : w0;
          const dstMask = rangeMask(dstBit, len);
          const valBits = (sVal & rangeMask(0, len)) << dstBit >>> 0;
          defined[dstWord] |= dstMask;
          value[dstWord] = value[dstWord] & ~dstMask | valBits;
          xPos += len;
        }
      }
      return this;
    }
    // returns rectangular part of bitmap
    rectSlice(c, size = this.size()) {
      const { x, y } = this.xy(c);
      const { height, width } = _Bitmap.size(size, this.size({ x, y }));
      const rect = new _Bitmap({ height, width });
      this.rectRead({ x, y }, { height, width }, (p, cur) => {
        if (this.isDefined(x + p.x, y + p.y)) {
          rect.set(p.x, p.y, cur);
        }
      });
      return rect;
    }
    // Change shape, replace rows with columns (data[y][x] -> data[x][y])
    transpose() {
      const { height, width, value, defined, words } = this;
      const dst = new _Bitmap({ height: width, width: height });
      const { words: dstStride, value: dstValue, defined: dstDefined, tailMask: dstTail } = dst;
      const tmpV = new Uint32Array(32);
      const tmpD = new Uint32Array(32);
      for (let by = 0; by < height; by += 32) {
        for (let bx = 0; bx < words; bx++) {
          const rows = Math.min(32, height - by);
          for (let r = 0; r < rows; r++) {
            const wi = this.wordIndex(32 * bx, by + r);
            tmpV[r] = value[wi];
            tmpD[r] = defined[wi];
          }
          tmpV.fill(0, rows);
          tmpD.fill(0, rows);
          transpose32(tmpV);
          transpose32(tmpD);
          for (let i = 0; i < 32; i++) {
            const dstY = bx * 32 + i;
            if (dstY >= width)
              break;
            const dstPos = dst.wordIndex(by, dstY);
            const curMask = by >>> 5 === dstStride - 1 ? dstTail : 4294967295;
            dstValue[dstPos] = tmpV[i] & curMask;
            dstDefined[dstPos] = tmpD[i] & curMask;
          }
        }
      }
      return dst;
    }
    // black <-> white (inplace)
    negate() {
      const n = this.defined.length;
      for (let i = 0; i < n; i++) {
        this.value[i] = ~this.value[i];
        this.defined[i] = 4294967295;
      }
      return this;
    }
    // Each pixel size is multiplied by factor
    scale(factor) {
      if (!Number.isSafeInteger(factor) || factor > 1024)
        throw new Error(`invalid scale factor: ${factor}`);
      const { height, width } = this;
      const res = new _Bitmap({ height: factor * height, width: factor * width });
      return res.rect({ x: 0, y: 0 }, Infinity, ({ x, y }) => this.get(x / factor | 0, y / factor | 0));
    }
    clone() {
      const res = new _Bitmap(this.size());
      res.defined.set(this.defined);
      res.value.set(this.value);
      return res;
    }
    // Ensure that there is no undefined values left
    assertDrawn() {
      const { height, width, defined, tailMask, fullWords, words } = this;
      if (!height || !width)
        return;
      for (let y = 0; y < height; y++) {
        const rowBase = y * words;
        for (let wi = 0; wi < fullWords; wi++) {
          if (defined[rowBase + wi] !== 4294967295)
            throw new Error(`Invalid color type=undefined`);
        }
        if (words !== fullWords && (defined[rowBase + fullWords] & tailMask) !== tailMask)
          throw new Error(`Invalid color type=undefined`);
      }
    }
    countPatternInRow(y, patternLen, ...patterns) {
      if (!Number.isSafeInteger(patternLen) || patternLen <= 0 || patternLen >= 32)
        throw new Error("wrong patternLen");
      const mask = (1 << patternLen) - 1;
      const { height, width, value, words } = this;
      if (!Number.isSafeInteger(y) || y < 0 || y >= height)
        return 0;
      let count = 0;
      const rowBase = this.wordIndex(0, y);
      for (let i = 0, window2 = 0; i < words; i++) {
        const w = value[rowBase + i];
        const bitEnd = i === words - 1 ? width & 31 || 32 : 32;
        for (let b = 0; b < bitEnd; b++) {
          window2 = (window2 << 1 | w >>> b & 1) & mask;
          if (i * 32 + b + 1 < patternLen)
            continue;
          for (const p of patterns) {
            if (window2 !== p)
              continue;
            count++;
            break;
          }
        }
      }
      return count;
    }
    getRuns(y, fn) {
      const { height, width, value, words } = this;
      if (width === 0)
        return;
      if (!Number.isSafeInteger(y) || y < 0 || y >= height)
        return;
      let runLen = 0;
      let runValue;
      const rowBase = this.wordIndex(0, y);
      for (let i = 0; i < words; i++) {
        const word = value[rowBase + i];
        const bitEnd = i === words - 1 ? width & 31 || 32 : 32;
        for (let b = 0; b < bitEnd; b++) {
          const bit = (word & 1 << b) !== 0;
          if (bit === runValue) {
            runLen++;
            continue;
          }
          if (runValue !== void 0)
            fn(runLen, runValue);
          runValue = bit;
          runLen = 1;
        }
      }
      if (runValue !== void 0)
        fn(runLen, runValue);
    }
    popcnt() {
      const { height, width, words, fullWords, tailMask } = this;
      if (!height || !width)
        return 0;
      let count = 0;
      for (let y = 0; y < height; y++) {
        const rowBase = y * words;
        for (let wi = 0; wi < fullWords; wi++)
          count += popcnt(this.value[rowBase + wi]);
        if (words !== fullWords)
          count += popcnt(this.value[rowBase + fullWords] & tailMask);
      }
      return count;
    }
    countBoxes2x2(y) {
      const { height, width, words } = this;
      if (width < 2 || !Number.isSafeInteger(y) || y < 0 || y + 1 >= height)
        return 0;
      const base0 = this.wordIndex(0, y);
      const base1 = this.wordIndex(0, y + 1);
      const tailBits = width & 31;
      const validLast = tailBits === 0 ? 2147483647 : rangeMask(0, width - 1 & 31);
      let boxes = 0;
      for (let wi = 0; wi < words; wi++) {
        const a0 = this.value[base0 + wi];
        const a1 = this.value[base1 + wi];
        const eqV = ~(a0 ^ a1) >>> 0;
        const n0 = wi + 1 < words ? this.value[base0 + wi + 1] >>> 0 : 0;
        const eqH0 = ~(a0 ^ (a0 >>> 1 | (n0 & 1) << 31) >>> 0) >>> 0;
        const n1 = wi + 1 < words ? this.value[base1 + wi + 1] >>> 0 : 0;
        const eqH1 = ~(a1 ^ (a1 >>> 1 | (n1 & 1) << 31) >>> 0) >>> 0;
        let m = (eqV & eqH0 & eqH1) >>> 0;
        if (wi === words - 1)
          m &= validLast;
        boxes += popcnt(m);
      }
      return boxes;
    }
    // Export
    toString() {
      const nl = String.fromCharCode(chCodes.newline);
      let out = "";
      for (let y = 0; y < this.height; y++) {
        let line = "";
        for (let x = 0; x < this.width; x++) {
          const v = this.get(x, y);
          line += !this.isDefined(x, y) ? "?" : v ? "X" : " ";
        }
        out += line + (y + 1 === this.height ? "" : nl);
      }
      return out;
    }
    toRaw() {
      const out = Array.from({ length: this.height }, () => new Array(this.width));
      for (let y = 0; y < this.height; y++) {
        const row = out[y];
        for (let x = 0; x < this.width; x++)
          row[x] = this.get(x, y);
      }
      return out;
    }
    toASCII() {
      const { height, width } = this;
      let out = "";
      for (let y = 0; y < height; y += 2) {
        for (let x = 0; x < width; x++) {
          const first = this.get(x, y);
          const second = y + 1 >= height ? true : this.get(x, y + 1);
          if (!first && !second)
            out += "\u2588";
          else if (!first && second)
            out += "\u2580";
          else if (first && !second)
            out += "\u2584";
          else if (first && second)
            out += " ";
        }
        out += String.fromCharCode(chCodes.newline);
      }
      return out;
    }
    toTerm() {
      const cc = String.fromCharCode(chCodes.reset);
      const reset = cc + "[0m";
      const whiteBG = cc + "[1;47m  " + reset;
      const darkBG = cc + `[40m  ` + reset;
      const nl = String.fromCharCode(chCodes.newline);
      let out = "";
      for (let y = 0; y < this.height; y++) {
        for (let x = 0; x < this.width; x++) {
          const v = this.get(x, y);
          out += v ? darkBG : whiteBG;
        }
        out += nl;
      }
      return out;
    }
    toSVG(optimize = true) {
      let out = `<svg viewBox="0 0 ${this.width} ${this.height}" xmlns="http://www.w3.org/2000/svg">`;
      let pathData = "";
      let prevPoint;
      this.rectRead(0, Infinity, (point, val) => {
        if (!val)
          return;
        const { x, y } = point;
        if (!optimize) {
          out += `<rect x="${x}" y="${y}" width="1" height="1" />`;
          return;
        }
        let m = `M${x} ${y}`;
        if (prevPoint) {
          const relM = `m${x - prevPoint.x} ${y - prevPoint.y}`;
          if (relM.length <= m.length)
            m = relM;
        }
        const bH = x < 10 ? `H${x}` : "h-1";
        pathData += `${m}h1v1${bH}Z`;
        prevPoint = point;
      });
      if (optimize)
        out += `<path d="${pathData}"/>`;
      out += `</svg>`;
      return out;
    }
    toGIF() {
      const u16le = (i) => [i & 255, i >>> 8 & 255];
      const dims = [...u16le(this.width), ...u16le(this.height)];
      const data = [];
      this.rectRead(0, Infinity, (_, cur) => data.push(+(cur === true)));
      const N = 126;
      const bytes = [
        71,
        73,
        70,
        56,
        55,
        97,
        ...dims,
        246,
        0,
        0,
        255,
        255,
        255,
        ...fillArr(3 * 127, 0),
        44,
        0,
        0,
        0,
        0,
        ...dims,
        0,
        7
      ];
      const fullChunks = Math.floor(data.length / N);
      for (let i = 0; i < fullChunks; i++)
        bytes.push(N + 1, 128, ...data.slice(N * i, N * (i + 1)).map((i2) => +i2));
      bytes.push(data.length % N + 1, 128, ...data.slice(fullChunks * N).map((i) => +i));
      bytes.push(1, 129, 0, 59);
      return new Uint8Array(bytes);
    }
    toImage(isRGB = false) {
      const { height, width } = this.size();
      const data = new Uint8Array(height * width * (isRGB ? 3 : 4));
      let i = 0;
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const value = this.get(x, y) ? 0 : 255;
          data[i++] = value;
          data[i++] = value;
          data[i++] = value;
          if (!isRGB)
            data[i++] = 255;
        }
      }
      return { height, width, data };
    }
  };
  var ECMode = /* @__PURE__ */ Object.freeze(["low", "medium", "quartile", "high"]);
  var Encoding = /* @__PURE__ */ Object.freeze(["numeric", "alphanumeric", "byte", "kanji", "eci"]);
  var BYTES = [
    // 1,  2,  3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  14,  15,  16,  17,  18,  19,   20,
    26,
    44,
    70,
    100,
    134,
    172,
    196,
    242,
    292,
    346,
    404,
    466,
    532,
    581,
    655,
    733,
    815,
    901,
    991,
    1085,
    //  21,   22,   23,   24,   25,   26,   27,   28,   29,   30,   31,   32,   33,   34,   35,   36,   37,   38,   39,   40
    1156,
    1258,
    1364,
    1474,
    1588,
    1706,
    1828,
    1921,
    2051,
    2185,
    2323,
    2465,
    2611,
    2761,
    2876,
    3034,
    3196,
    3362,
    3532,
    3706
  ];
  var WORDS_PER_BLOCK = {
    // Version 1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40
    low: [7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    medium: [10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
    quartile: [13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    high: [17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]
  };
  var ECC_BLOCKS = {
    // Version   1, 2, 3, 4, 5, 6, 7, 8, 9,10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40
    low: [1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
    medium: [1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
    quartile: [1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
    high: [1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81]
  };
  var info = /* @__PURE__ */ Object.freeze({
    size: /* @__PURE__ */ Object.freeze({
      encode: (ver) => 21 + 4 * (ver - 1),
      // ver1 = 21, ver40 = 177 modules per side
      decode: (size) => (size - 17) / 4
    }),
    // ISO/IEC 18004:2024 Table 3: map version ranges 1-9, 10-26, and 27-40 to count-width indexes.
    sizeType: (ver) => Math.floor((ver + 7) / 17),
    // ISO/IEC 18004:2024 Annex E Table E.1: row/column coordinate list of alignment-pattern centres.
    // Based on https://codereview.stackexchange.com/questions/74925/algorithm-to-generate-this-alignment-pattern-locations-table-for-qr-codes
    alignmentPatterns(ver) {
      if (ver === 1)
        return [];
      const first = 6;
      const last = info.size.encode(ver) - first - 1;
      const distance = last - first;
      const count = Math.ceil(distance / 28);
      let interval = Math.floor(distance / count);
      if (interval % 2)
        interval += 1;
      else if (distance % count * 2 >= count)
        interval += 2;
      const res = [first];
      for (let m = 1; m < count; m++)
        res.push(last - (count - m) * interval);
      res.push(last);
      return res;
    },
    // ISO/IEC 18004:2024 §7.9.1 Table 12: error-correction-level indicators for the top two format-information data bits.
    ECCode: /* @__PURE__ */ Object.freeze({
      low: 1,
      medium: 0,
      quartile: 3,
      high: 2
    }),
    // ISO/IEC 18004:2024 §7.9.1 final paragraph: XOR the 15-bit format information with mask pattern 101010000010010.
    formatMask: 21522,
    // ISO/IEC 18004:2024 §7.9.1 / Annex C.2: append the 10-bit BCH remainder for the 5 data bits, then apply the fixed QR format mask.
    formatBits(ecc, maskIdx) {
      const data = info.ECCode[ecc] << 3 | maskIdx;
      let d = data;
      for (let i = 0; i < 10; i++)
        d = d << 1 ^ (d >> 9) * 1335;
      return (data << 10 | d) ^ info.formatMask;
    },
    // ISO/IEC 18004:2024 §7.10 / Annex D.2: append the 12-bit Golay remainder to the 6-bit version word; version information is not masked.
    versionBits(ver) {
      let d = ver;
      for (let i = 0; i < 12; i++)
        d = d << 1 ^ (d >> 11) * 7973;
      return ver << 12 | d;
    },
    // ISO/IEC 18004:2024 §7.3.3 / §7.3.4 / §7.4.5 Table 5: character-set membership and value codecs for numeric and alphanumeric QR modes.
    alphabet: /* @__PURE__ */ Object.freeze({
      // ISO/IEC 18004:2024 §7.3.3 / §7.4.4: numeric-mode digits map directly to values 0..9 before 3-digit grouping.
      numeric: alphabet("0123456789"),
      // ISO/IEC 18004:2024 §7.3.4 / §7.4.5 Table 5: 45-character alphanumeric-mode value order used for 11-bit pair packing. Keep the legacy `alphanumerc` key name in sync with existing callers.
      alphanumerc: alphabet("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:")
    }),
    // as Record<EncodingType, ReturnType<typeof alphabet>>,
    // ISO/IEC 18004:2024 Table 3 gives QR character-count widths for data modes; ECI headers instead carry only the mode indicator plus the designator from §7.4.3.
    lengthBits(ver, type) {
      const table = {
        numeric: [10, 12, 14],
        alphanumeric: [9, 11, 13],
        byte: [8, 16, 16],
        kanji: [8, 10, 12],
        eci: [0, 0, 0]
      };
      return table[type][info.sizeType(ver)];
    },
    // ISO/IEC 18004:2024 §7.4.2 Table 2: 4-bit QR mode indicators for the segment types this library models.
    modeBits: /* @__PURE__ */ Object.freeze({
      numeric: "0001",
      alphanumeric: "0010",
      byte: "0100",
      kanji: "1000",
      eci: "0111"
    }),
    // ISO/IEC 18004:2024 Table 1 / §7.5.1 Table 9: derive total data bits and short/long RS block layout from total codewords, ECC words per block, and block counts.
    capacity(ver, ecc) {
      const bytes = BYTES[ver - 1];
      const words = WORDS_PER_BLOCK[ecc][ver - 1];
      const numBlocks = ECC_BLOCKS[ecc][ver - 1];
      const blockLen = Math.floor(bytes / numBlocks) - words;
      const shortBlocks = numBlocks - bytes % numBlocks;
      return {
        words,
        numBlocks,
        shortBlocks,
        blockLen,
        capacity: (bytes - words * numBlocks) * 8,
        total: (words + blockLen) * numBlocks + numBlocks - shortBlocks
      };
    }
  });
  var PATTERNS = /* @__PURE__ */ Object.freeze([
    (x, y) => (x + y) % 2 == 0,
    (_x, y) => y % 2 == 0,
    (x, _y) => x % 3 == 0,
    (x, y) => (x + y) % 3 == 0,
    (x, y) => (Math.floor(y / 2) + Math.floor(x / 3)) % 2 == 0,
    (x, y) => x * y % 2 + x * y % 3 == 0,
    (x, y) => (x * y % 2 + x * y % 3) % 2 == 0,
    (x, y) => ((x + y) % 2 + x * y % 3) % 2 == 0
  ]);
  var GF = {
    tables: ((p_poly) => {
      const exp = fillArr(256, 0);
      const log = fillArr(256, 0);
      for (let i = 0, x = 1; i < 256; i++) {
        exp[i] = x;
        log[x] = i;
        x <<= 1;
        if (x & 256)
          x ^= p_poly;
      }
      return { exp, log };
    })(285),
    // Raw α^i lookup from the precomputed field table; callers are expected
    // to reduce / validate exponents before indexing it.
    exp: (x) => GF.tables.exp[x],
    // log(0) is undefined in GF(2^8); `% 255` also folds the wrapped table
    // entry for α^255 = 1 back to exponent 0.
    log(x) {
      if (x === 0)
        throw new Error(`GF.log: invalid arg=${x}`);
      return GF.tables.log[x] % 255;
    },
    // Zero has no logarithm in GF(2^8), so it must short-circuit here; all
    // other products are α^(log(x) + log(y) mod 255) in the reviewed field.
    mul(x, y) {
      if (x === 0 || y === 0)
        return 0;
      return GF.tables.exp[(GF.tables.log[x] + GF.tables.log[y]) % 255];
    },
    // In characteristic 2 fields, addition and subtraction are the same
    // bitwise XOR operation used by the QR Reed-Solomon arithmetic.
    add: (x, y) => x ^ y,
    // Raw nonzero field power helper. Current QR use is GF.pow(2, i) for the
    // Annex A generator factors; x = 0 or negative exponents are not validated.
    pow: (x, e) => GF.tables.exp[GF.tables.log[x] * e % 255],
    // Multiplicative inverse for nonzero field elements. Current callers only
    // use it on values already known to be nonzero; 0 has no inverse in GF(2^8).
    inv(x) {
      if (x === 0)
        throw new Error(`GF.inverse: invalid arg=${x}`);
      return GF.tables.exp[255 - GF.tables.log[x]];
    },
    // Canonicalize coefficient arrays by trimming leading zero coefficients
    // while preserving `[0]` as the zero polynomial; already-normalized inputs
    // are returned by reference.
    polynomial(poly) {
      if (poly.length == 0)
        throw new Error("GF.polymomial: invalid length");
      if (poly[0] !== 0)
        return poly;
      let i = 0;
      for (; i < poly.length - 1 && poly[i] == 0; i++)
        ;
      return poly.slice(i);
    },
    // Represent c*x^degree in the descending-power coefficient layout used
    // by the QR Reed-Solomon helpers; coefficient 0 canonicalizes to `[0]`.
    monomial(degree, coefficient) {
      if (degree < 0)
        throw new Error(`GF.monomial: invalid degree=${degree}`);
      if (coefficient == 0)
        return [0];
      let coefficients = fillArr(degree + 1, 0);
      coefficients[0] = coefficient;
      return GF.polynomial(coefficients);
    },
    // Canonical polynomials keep the highest-order coefficient first and use
    // `[0]` for zero, so degree is just `length - 1`.
    degree: (a) => a.length - 1,
    // Read the coefficient for x^degree from the descending-power array layout.
    // Canonical arrays make this a direct index; out-of-range degrees return `undefined`.
    coefficient: (a, degree) => a[GF.degree(a) - degree],
    // Multiply descending-power coefficient arrays by convolution over GF(2^8).
    // Zero short-circuits here before the log-based field multiply is consulted.
    mulPoly(a, b) {
      if (a[0] === 0 || b[0] === 0)
        return [0];
      const res = fillArr(a.length + b.length - 1, 0);
      for (let i = 0; i < a.length; i++) {
        for (let j = 0; j < b.length; j++) {
          res[i + j] = GF.add(res[i + j], GF.mul(a[i], b[j]));
        }
      }
      return GF.polynomial(res);
    },
    // Scale every coefficient by the same field element in descending-power order.
    // Scalar 0 canonicalizes to `[0]`, and scalar 1 reuses the original array.
    mulPolyScalar(a, scalar) {
      if (scalar == 0)
        return [0];
      if (scalar == 1)
        return a;
      const res = fillArr(a.length, 0);
      for (let i = 0; i < a.length; i++)
        res[i] = GF.mul(a[i], scalar);
      return GF.polynomial(res);
    },
    // Multiply a polynomial by c*x^degree in descending-power coefficient form.
    // This scales existing coefficients, then appends trailing zero coefficients.
    mulPolyMonomial(a, degree, coefficient) {
      if (degree < 0)
        throw new Error("GF.mulPolyMonomial: invalid degree");
      if (coefficient == 0)
        return [0];
      const res = fillArr(a.length + degree, 0);
      for (let i = 0; i < a.length; i++)
        res[i] = GF.mul(a[i], coefficient);
      return GF.polynomial(res);
    },
    // Add descending-power coefficient arrays with GF(2^8) XOR on the aligned
    // suffix; `[0]` short-circuits by returning the other array unchanged.
    addPoly(a, b) {
      if (a[0] === 0)
        return b;
      if (b[0] === 0)
        return a;
      let smaller = a;
      let larger = b;
      if (smaller.length > larger.length)
        [smaller, larger] = [larger, smaller];
      let sumDiff = fillArr(larger.length, 0);
      let lengthDiff = larger.length - smaller.length;
      let s = larger.slice(0, lengthDiff);
      for (let i = 0; i < s.length; i++)
        sumDiff[i] = s[i];
      for (let i = lengthDiff; i < larger.length; i++)
        sumDiff[i] = GF.add(smaller[i - lengthDiff], larger[i]);
      return GF.polynomial(sumDiff);
    },
    // Synthetic division for monic divisors in descending-power coefficient form.
    // Callers are expected to append `divisor.length - 1` zero coefficients first.
    remainderPoly(data, divisor) {
      const out = Array.from(data);
      for (let i = 0; i < data.length - divisor.length + 1; i++) {
        const elm = out[i];
        if (elm === 0)
          continue;
        for (let j = 1; j < divisor.length; j++) {
          if (divisor[j] !== 0)
            out[i + j] = GF.add(out[i + j], GF.mul(divisor[j], elm));
        }
      }
      return out.slice(data.length - divisor.length + 1, out.length);
    },
    // Build Annex A's monic generator polynomial g_n(x) = Π(x - 2^i).
    // degree=0 returns `[1]`; callers are expected to validate degree bounds.
    divisorPoly(degree) {
      let g = [1];
      for (let i = 0; i < degree; i++)
        g = GF.mulPoly(g, [1, GF.pow(2, i)]);
      return g;
    },
    // Evaluate a descending-power coefficient array at `a` with Horner's rule.
    // The `a == 0` fast-path returns the x^0 coefficient directly.
    evalPoly(poly, a) {
      if (a == 0)
        return GF.coefficient(poly, 0);
      let res = poly[0];
      for (let i = 1; i < poly.length; i++)
        res = GF.add(GF.mul(a, res), poly[i]);
      return res;
    },
    // TODO: cleanup
    // Extended Euclidean RS step: derive the locator/evaluator pair from x^R
    // and the syndrome polynomial, then normalize sigma(0) to 1.
    euclidian(a, b, R) {
      if (GF.degree(a) < GF.degree(b))
        [a, b] = [b, a];
      let rLast = a;
      let r = b;
      let tLast = [0];
      let t2 = [1];
      while (2 * GF.degree(r) >= R) {
        let rLastLast = rLast;
        let tLastLast = tLast;
        rLast = r;
        tLast = t2;
        if (rLast[0] === 0)
          throw new Error("rLast[0] === 0");
        r = rLastLast;
        let q = [0];
        const dltInverse = GF.inv(rLast[0]);
        while (GF.degree(r) >= GF.degree(rLast) && r[0] !== 0) {
          const degreeDiff = GF.degree(r) - GF.degree(rLast);
          const scale = GF.mul(r[0], dltInverse);
          q = GF.addPoly(q, GF.monomial(degreeDiff, scale));
          r = GF.addPoly(r, GF.mulPolyMonomial(rLast, degreeDiff, scale));
        }
        q = GF.mulPoly(q, tLast);
        t2 = GF.addPoly(q, tLastLast);
        if (GF.degree(r) >= GF.degree(rLast))
          throw new Error(`Division failed r: ${r}, rLast: ${rLast}`);
      }
      const sigmaTildeAtZero = GF.coefficient(t2, 0);
      if (sigmaTildeAtZero == 0)
        throw new Error("sigmaTilde(0) was zero");
      const inverse = GF.inv(sigmaTildeAtZero);
      return [GF.mulPolyScalar(t2, inverse), GF.mulPolyScalar(r, inverse)];
    }
  };
  function RS(eccWords) {
    return {
      encode(from) {
        const d = GF.divisorPoly(eccWords);
        const pol = Array.from(from);
        pol.push(...d.slice(0, -1).fill(0));
        return Uint8Array.from(GF.remainderPoly(pol, d));
      },
      decode(to) {
        const res = to.slice();
        const poly = GF.polynomial(Array.from(to));
        let syndrome = fillArr(eccWords, 0);
        let hasError = false;
        for (let i = 0; i < eccWords; i++) {
          const evl = GF.evalPoly(poly, GF.exp(i));
          syndrome[syndrome.length - 1 - i] = evl;
          if (evl !== 0)
            hasError = true;
        }
        if (!hasError)
          return res;
        syndrome = GF.polynomial(syndrome);
        const monomial = GF.monomial(eccWords, 1);
        const [errorLocator, errorEvaluator] = GF.euclidian(monomial, syndrome, eccWords);
        const locations = fillArr(GF.degree(errorLocator), 0);
        let e = 0;
        for (let i = 1; i < 256 && e < locations.length; i++) {
          if (GF.evalPoly(errorLocator, i) === 0)
            locations[e++] = GF.inv(i);
        }
        if (e !== locations.length)
          throw new Error("RS.decode: invalid errors number");
        for (let i = 0; i < locations.length; i++) {
          const pos = res.length - 1 - GF.log(locations[i]);
          if (pos < 0)
            throw new Error("RS.decode: invalid error location");
          const xiInverse = GF.inv(locations[i]);
          let denominator = 1;
          for (let j = 0; j < locations.length; j++) {
            if (i === j)
              continue;
            denominator = GF.mul(denominator, GF.add(1, GF.mul(locations[j], xiInverse)));
          }
          res[pos] = GF.add(res[pos], GF.mul(GF.evalPoly(errorEvaluator, xiInverse), GF.inv(denominator)));
        }
        return res;
      }
    };
  }
  function interleave(ver, ecc) {
    const { words, shortBlocks, numBlocks, blockLen, total } = info.capacity(ver, ecc);
    const rs = RS(words);
    return {
      encode(bytes) {
        const blocks = [];
        const eccBlocks = [];
        for (let i = 0; i < numBlocks; i++) {
          const isShort = i < shortBlocks;
          const len = blockLen + (isShort ? 0 : 1);
          blocks.push(bytes.subarray(0, len));
          eccBlocks.push(rs.encode(bytes.subarray(0, len)));
          bytes = bytes.subarray(len);
        }
        const resBlocks = interleaveBytes(blocks);
        const resECC = interleaveBytes(eccBlocks);
        const res = new Uint8Array(resBlocks.length + resECC.length);
        res.set(resBlocks);
        res.set(resECC, resBlocks.length);
        return res;
      },
      decode(data) {
        if (data.length !== total)
          throw new Error(`interleave.decode: len(data)=${data.length}, total=${total}`);
        const blocks = [];
        for (let i = 0; i < numBlocks; i++) {
          const isShort = i < shortBlocks;
          blocks.push(new Uint8Array(words + blockLen + (isShort ? 0 : 1)));
        }
        let pos = 0;
        for (let i = 0; i < blockLen; i++) {
          for (let j = 0; j < numBlocks; j++)
            blocks[j][i] = data[pos++];
        }
        for (let j = shortBlocks; j < numBlocks; j++)
          blocks[j][blockLen] = data[pos++];
        for (let i = blockLen; i < blockLen + words; i++) {
          for (let j = 0; j < numBlocks; j++) {
            const isShort = j < shortBlocks;
            blocks[j][i + (isShort ? 0 : 1)] = data[pos++];
          }
        }
        const res = [];
        for (const block of blocks)
          res.push(...Array.from(rs.decode(block)).slice(0, -words));
        return Uint8Array.from(res);
      }
    };
  }
  function drawTemplate(ver, ecc, maskIdx, test = false) {
    const size = info.size.encode(ver);
    let b = new Bitmap(size + 2);
    const finder = new Bitmap(3).rect(0, 3, true).border(1, false).border(1, true).border(1, false);
    b = b.embed(0, finder).embed({ x: -finder.width, y: 0 }, finder).embed({ x: 0, y: -finder.height }, finder);
    b = b.rectSlice(1, size);
    const align = new Bitmap(1).rect(0, 1, true).border(1, false).border(1, true);
    const alignPos = info.alignmentPatterns(ver);
    for (const y of alignPos) {
      for (const x of alignPos) {
        if (b.isDefined(x, y))
          continue;
        b.embed({ x: x - 2, y: y - 2 }, align);
      }
    }
    b = b.hLine({ x: 0, y: 6 }, Infinity, ({ x }) => b.isDefined(x, 6) ? void 0 : x % 2 == 0).vLine({ x: 6, y: 0 }, Infinity, ({ y }) => b.isDefined(6, y) ? void 0 : y % 2 == 0);
    {
      const bits = info.formatBits(ecc, maskIdx);
      const getBit = (i) => !test && (bits >> i & 1) == 1;
      for (let i = 0; i < 6; i++)
        b.set(8, i, getBit(i));
      for (let i = 6; i < 8; i++)
        b.set(8, i + 1, getBit(i));
      for (let i = 8; i < 15; i++)
        b.set(8, size - 15 + i, getBit(i));
      for (let i = 0; i < 8; i++)
        b.set(size - i - 1, 8, getBit(i));
      for (let i = 8; i < 9; i++)
        b.set(15 - i - 1 + 1, 8, getBit(i));
      for (let i = 9; i < 15; i++)
        b.set(15 - i - 1, 8, getBit(i));
      b.set(8, size - 8, !test);
    }
    if (ver >= 7) {
      const bits = info.versionBits(ver);
      for (let i = 0; i < 18; i += 1) {
        const bit = !test && (bits >> i & 1) == 1;
        const x = Math.floor(i / 3);
        const y = i % 3 + size - 8 - 3;
        b.set(y, x, bit);
        b.set(x, y, bit);
      }
    }
    return b;
  }
  function zigzag(tpl, maskIdx, fn) {
    const bm = tpl;
    const size = bm.height;
    const pattern = PATTERNS[maskIdx];
    let dir = -1;
    let y = size - 1;
    for (let xOffset = size - 1; xOffset > 0; xOffset -= 2) {
      if (xOffset == 6)
        xOffset = 5;
      for (; ; y += dir) {
        for (let j = 0; j < 2; j += 1) {
          const x = xOffset - j;
          if (bm.isDefined(x, y))
            continue;
          fn(x, y, pattern(x, y));
        }
        if (y + dir < 0 || y + dir >= size)
          break;
      }
      dir = -dir;
    }
  }
  function detectType(str) {
    let type = "numeric";
    for (let x of str) {
      if (info.alphabet.numeric.has(x))
        continue;
      type = "alphanumeric";
      if (!info.alphabet.alphanumerc.has(x))
        return "byte";
    }
    return type;
  }
  function utf8ToBytes(str) {
    if (typeof str !== "string")
      throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function encode(ver, ecc, data, type, encoder = utf8ToBytes) {
    let encoded = "";
    let dataLen = data.length;
    if (type === "numeric") {
      const t2 = info.alphabet.numeric.decode(data.split(""));
      const n = t2.length;
      for (let i = 0; i < n - 2; i += 3)
        encoded += bin(t2[i] * 100 + t2[i + 1] * 10 + t2[i + 2], 10);
      if (n % 3 === 1) {
        encoded += bin(t2[n - 1], 4);
      } else if (n % 3 === 2) {
        encoded += bin(t2[n - 2] * 10 + t2[n - 1], 7);
      }
    } else if (type === "alphanumeric") {
      const t2 = info.alphabet.alphanumerc.decode(data.split(""));
      const n = t2.length;
      for (let i = 0; i < n - 1; i += 2)
        encoded += bin(t2[i] * 45 + t2[i + 1], 11);
      if (n % 2 == 1)
        encoded += bin(t2[n - 1], 6);
    } else if (type === "byte") {
      const utf8 = encoder(data);
      dataLen = utf8.length;
      encoded = Array.from(utf8).map((i) => bin(i, 8)).join("");
    } else {
      throw new Error("encode: unsupported type");
    }
    const { capacity } = info.capacity(ver, ecc);
    const len = bin(dataLen, info.lengthBits(ver, type));
    let bits = info.modeBits[type] + len + encoded;
    if (bits.length > capacity)
      throw new Error("Capacity overflow");
    bits += "0".repeat(Math.min(4, Math.max(0, capacity - bits.length)));
    if (bits.length % 8)
      bits += "0".repeat(8 - bits.length % 8);
    const padding = "1110110000010001";
    for (let idx = 0; bits.length !== capacity; idx++)
      bits += padding[idx % padding.length];
    const bytes = Uint8Array.from(bits.match(/(.{8})/g).map((i) => Number(`0b${i}`)));
    return interleave(ver, ecc).encode(bytes);
  }
  function drawQR(ver, ecc, data, maskIdx, test = false) {
    const b = drawTemplate(ver, ecc, maskIdx, test);
    let i = 0;
    const need = 8 * data.length;
    zigzag(b, maskIdx, (x, y, mask) => {
      let value = false;
      if (i < need) {
        value = (data[i >>> 3] >> (7 - i & 7) & 1) !== 0;
        i++;
      }
      b.set(x, y, value !== mask);
    });
    if (i !== need)
      throw new Error("QR: bytes left after draw");
    return b;
  }
  var mkPattern = (pattern) => {
    const s = pattern.map((i) => i ? "1" : "0").join("");
    return { len: s.length, n: Number(`0b${s}`) };
  };
  var finderPattern = [true, false, true, true, true, false, true];
  var lightPattern = [false, false, false, false];
  var P1 = /* @__PURE__ */ (() => mkPattern([...finderPattern, ...lightPattern]))();
  var P2 = /* @__PURE__ */ (() => mkPattern([...lightPattern, ...finderPattern]))();
  function penalty(bm) {
    const b = bm;
    const { width, height } = b;
    const transposed = b.transpose();
    let adjacent = 0;
    for (let y = 0; y < height; y++) {
      b.getRuns(y, (len) => {
        if (len >= 5)
          adjacent += 3 + (len - 5);
      });
    }
    for (let y = 0; y < width; y++) {
      transposed.getRuns(y, (len) => {
        if (len >= 5)
          adjacent += 3 + (len - 5);
      });
    }
    let box = 0;
    for (let y = 0; y < height - 1; y++)
      box += 3 * b.countBoxes2x2(y);
    let finder = 0;
    for (let y = 0; y < height; y++)
      finder += 40 * b.countPatternInRow(y, P1.len, P1.n, P2.n);
    for (let y = 0; y < width; y++)
      finder += 40 * transposed.countPatternInRow(y, P1.len, P1.n, P2.n);
    const total = height * width;
    const darkPixels = b.popcnt();
    const darkSteps = Math.ceil(Math.max(0, Math.abs(darkPixels * 100 - total * 50) - total * 5) / (total * 5));
    const dark = 10 * darkSteps;
    return adjacent + box + finder + dark;
  }
  function drawQRBest(ver, ecc, data, maskIdx) {
    if (maskIdx === void 0) {
      const bestMask = best();
      for (let mask = 0; mask < PATTERNS.length; mask++)
        bestMask.add(penalty(drawQR(ver, ecc, data, mask, true)), mask);
      maskIdx = bestMask.get();
    }
    if (maskIdx === void 0)
      throw new Error("Cannot find mask");
    return drawQR(ver, ecc, data, maskIdx);
  }
  function validateECC(ec) {
    if (!ECMode.includes(ec))
      throw new Error(`Invalid error correction mode=${ec}. Expected: ${ECMode}`);
  }
  function validateEncoding(enc) {
    if (!Encoding.includes(enc))
      throw new Error(`Encoding: invalid mode=${enc}. Expected: ${Encoding}`);
    if (enc === "kanji" || enc === "eci")
      throw new Error(`Encoding: ${enc} is not supported (yet?).`);
  }
  function validateMask(mask) {
    if (![0, 1, 2, 3, 4, 5, 6, 7].includes(mask) || !PATTERNS[mask])
      throw new Error(`Invalid mask=${mask}. Expected number [0..7]`);
  }
  function encodeQR(text, output = "raw", opts = {}) {
    const _opts = opts;
    const ecc = _opts.ecc !== void 0 ? _opts.ecc : "medium";
    validateECC(ecc);
    const encoding = _opts.encoding !== void 0 ? _opts.encoding : detectType(text);
    validateEncoding(encoding);
    if (_opts.mask !== void 0)
      validateMask(_opts.mask);
    let ver = _opts.version;
    let data, err = new Error("Unknown error");
    if (ver !== void 0) {
      validateVersion(ver);
      data = encode(ver, ecc, text, encoding, _opts.textEncoder);
    } else {
      for (let i = 1; i <= 40; i++) {
        try {
          data = encode(i, ecc, text, encoding, _opts.textEncoder);
          ver = i;
          break;
        } catch (e) {
          err = e;
        }
      }
    }
    if (!ver || !data)
      throw err;
    let res = drawQRBest(ver, ecc, data, _opts.mask);
    res.assertDrawn();
    const border = _opts.border === void 0 ? 2 : _opts.border;
    if (!Number.isSafeInteger(border) || border <= 0)
      throw new Error(`invalid border=${border}`);
    res = res.border(border, false);
    if (_opts.scale !== void 0)
      res = res.scale(_opts.scale);
    if (output === "raw")
      return res.toRaw();
    else if (output === "ascii")
      return res.toASCII();
    else if (output === "svg")
      return res.toSVG(_opts.optimize);
    else if (output === "gif")
      return res.toGIF();
    else if (output === "term")
      return res.toTerm();
    else
      throw new Error(`Unknown output: ${output}`);
  }
  var qr_default = encodeQR;

  // packages/studynav/src/qr-code.ts
  function qrSvgForStudyUrl(url) {
    if (!isSupportedJwHttpsUrl(url)) return null;
    return qr_default(url, "svg", {
      border: 4,
      ecc: "medium",
      optimize: true,
      scale: 5
    });
  }

  // packages/studynav/src/i18n.ts
  var EN_MESSAGES = {
    extension_name: "StudyNav \u2014 Unofficial Study Tools",
    extension_short_name: "StudyNav",
    extension_description: "Unofficial local study helpers for public JW.org pages. No telemetry or uploads; not affiliated with Jehovah\u2019s Witnesses.",
    command_adv_search: "Open the StudyNav command palette",
    popup_header_title: "StudyNav",
    popup_header_subtitle: "Unofficial \xB7 local processing \xB7 supported pages only",
    tools: "Tools",
    tools_title: "Enable or disable all StudyNav tools",
    tools_aria: "Enable all StudyNav tools",
    checking_page: "Checking this page\u2026",
    open_supported_page: "Open a supported JW.org page to use study tools.",
    page_tools: "Page tools",
    study_library: "Study library",
    save_place: "Save place",
    remove_saved_place: "Remove saved place",
    copy_citation: "Copy citation",
    show_qr: "Show QR",
    open_official_link: "Open clean publication link",
    image_search: "Search JW images with Google",
    image_search_placeholder: "What picture do you need?",
    image_search_external: "Opens an external Google search",
    reset_defaults: "Reset recommended defaults",
    defaults_restored: "Recommended defaults restored",
    what_it_gives_you: "What it gives you",
    guide_bible_label: "Bible:",
    guide_bible_text: "select one verse, or choose Select several and then the last verse. Download audio saves the selection as one WAV file.",
    guide_study_label: "Study:",
    guide_study_text: "select text to highlight it, add a note, or save an exact place.",
    guide_articles_label: "Articles:",
    guide_articles_text: "hover or focus text for Copy, Link, and Mark actions.",
    guide_media_label: "Media:",
    guide_media_text: "use the floating controls for playback, media segments, resume, and available captions.",
    feature_settings: "Feature settings",
    filter_features: "Filter features",
    find_setting: "Find a setting\u2026",
    footer_quick_search: "Quick search: Ctrl/Cmd+Shift+K",
    footer_privacy: "No telemetry \xB7 no uploads",
    group_study: "Study & sharing",
    group_core: "Bible & articles",
    group_layout: "Reading layout",
    group_media: "Video & audio",
    enabled_count: "$1 on",
    status_tools_off_title: "Study tools are off",
    status_tools_off_hint: "Turn on Tools above to restore helpers on supported pages.",
    status_unavailable_title: "No tools on this page",
    status_unavailable_hint: "Open a JW.org Bible chapter, library article, or media page.",
    status_bible_title: "Ready on this Bible chapter",
    status_bible_selected: "Verse $1:$2 is selected. Choose Select several to include the verses that follow.",
    status_bible_range: "Verses $1:$2\u2013$3 are selected. Copy, Link, and Download audio use the whole range.",
    status_bible_hint: "Select a verse number for text, a direct link, or audio. Select several consecutive verses when needed.",
    status_media_title: "Ready on this media page",
    status_media_hint: "Use the floating controls for playback, media segments, and captions when present.",
    status_article_title: "Ready on this article",
    status_article_hint: "Hover or focus article text for Copy and Link. Optional image downloads are in Feature settings.",
    status_palette_title: "Quick search is ready",
    status_palette_hint: "Press Ctrl/Cmd+Shift+K to find a publication or DOCID.",
    working: "Working\u2026",
    preparing: "Preparing\u2026",
    done: "Done",
    unavailable_here: "Unavailable here",
    no_active_tab: "No active tab",
    place_saved: "Place saved",
    saved_place_removed: "Saved place removed",
    bookmark_limit: "The local saved-place limit has been reached.",
    remove_saved_place_confirm: "Remove this saved place?",
    feature_annotations_name: "Highlights, notes & tags",
    feature_annotations_blurb: "Keep six-color highlights and searchable notes locally",
    feature_bookmarks_name: "Save a place to return to",
    feature_bookmarks_blurb: "Keep an exact page, paragraph, verse, or verse range in the Study library",
    feature_citations_name: "Copy a quote with its source",
    feature_citations_blurb: "Copy selected words with the publication title, reference, and direct JW link",
    feature_qrShare_name: "Show QR for this page",
    feature_qrShare_blurb: "Create a local QR code for the precise official page link",
    feature_officialOpen_name: "Clean publication link",
    feature_officialOpen_blurb: "Open the same publication through JW.org without extra address parameters",
    feature_verseAudio_name: "Download audio for selected verses",
    feature_verseAudio_blurb: "Save one verse or several consecutive verses as one WAV file",
    feature_copyText_name: "Copy clean text",
    feature_copyText_blurb: "Copy without verse numbers, reference letters, or StudyNav controls",
    feature_parLink_name: "Copy precise link",
    feature_parLink_blurb: "Copy a direct link to a paragraph, verse, or verse range",
    feature_advSearch_name: "Search by publication code",
    feature_advSearch_blurb: "Open the existing JW search for a publication code or document number",
    feature_altText_name: "Image descriptions",
    feature_altText_blurb: "Show alt text and captions below article images",
    feature_imgGet_name: "Download article images",
    feature_imgGet_blurb: "Add a compact download button beside article images",
    feature_langCount_name: "Available languages",
    feature_langCount_blurb: "Show the number of languages for an article",
    feature_actionBar_name: "Keep page header visible",
    feature_actionBar_blurb: "Keep the JW.org header in view while scrolling",
    feature_expandWidth_name: "Wider reading column",
    feature_expandWidth_blurb: "Use more of the window for article text",
    feature_cstblView_name: "Clearer tables",
    feature_cstblView_blurb: "Add spacing and row separation to article tables",
    feature_mediaPlayerUI_name: "Remove video shading",
    feature_mediaPlayerUI_blurb: "Keep the picture clear when the player controls appear",
    feature_customSub_name: "Larger subtitles",
    feature_customSub_blurb: "Increase subtitle size and background contrast",
    feature_mediaCtrl_name: "Media keyboard shortcuts",
    feature_mediaCtrl_blurb: "Use Space/K/J/L/F/M while watching media",
    feature_mediaTS_name: "Copy page and time",
    feature_mediaTS_blurb: "Copy the page link together with the current playback time",
    feature_mediaClip_name: "Download an audio or video segment",
    feature_mediaClip_blurb: "Enter start and end times, then save audio as WAV or video as WebM",
    feature_continueWatching_name: "Continue watching",
    feature_continueWatching_blurb: "Keep video progress locally and resume only when asked",
    feature_sndDisp_name: "Open second display",
    feature_sndDisp_blurb: "Open the current media in a popup window",
    feature_transcCreate_name: "Search available captions",
    feature_transcCreate_blurb: "Open a searchable panel only when text is present",
    copied: "Copied",
    copy_failed: "Copy failed",
    study_tools_off: "Study tools are off",
    annotations_off: "Highlights and notes are off",
    bookmarks_off: "Saved places are off",
    citations_off: "Citations are off",
    qr_sharing_off: "QR sharing is off",
    official_links_off: "Publication links are off",
    action_failed: "Action failed",
    citation_unavailable: "Citation unavailable",
    citation_copied: "Citation copied",
    qr_unavailable: "QR unavailable",
    qr_title: "QR for this page",
    close: "Close",
    close_qr_aria: "Close QR",
    qr_image_aria: "QR code for the displayed JW link",
    copy_link: "Copy link",
    link_copied: "Link copied",
    qr_opened: "QR opened",
    not_available_page: "Not available on this page",
    official_link_opened: "Clean publication link opened",
    palette_title: "Search by publication code",
    palette_placeholder: "Mnemonic / DOCID (for example w25.03, lff, wp24.01, mwb25.01)",
    palette_hint: "Enter to open \xB7 Esc to close \xB7 Unofficial StudyNav",
    study_tools_aria: "Study tools",
    download_audio: "Download audio",
    download_audio_title: "Download only this verse as audio",
    download_range_audio: "Download audio $1\u2013$2",
    download_range_audio_title: "Download verses $1\u2013$2 as one audio file",
    select_several_verses: "Select several",
    select_several_verses_title: "Choose the last verse in a consecutive range",
    cancel_range_selection: "Cancel range",
    cancel_range_selection_title: "Stop choosing a verse range",
    clear_verse_selection: "Clear selection",
    clear_verse_selection_title: "Clear the selected verse range",
    select_range_last_verse: "Now select the last verse.",
    verse_range_selected: "Verses $1\u2013$2 selected.",
    range_selection_cancelled: "Range selection cancelled",
    verse_selection_cleared: "Verse selection cleared",
    chapter_audio_not_ready: "Chapter audio is not ready. Open Play Audio once, then try again.",
    verse_audio_prepare_failed: "Verse audio could not be prepared.",
    verse_audio_downloaded: "Downloaded $1:$2 audio",
    verse_audio_download_failed: "Verse audio download failed.",
    mark: "Mark",
    mark_title: "Highlight this paragraph or verse and optionally add a private note",
    copy: "Copy",
    copy_text_title: "Copy without verse numbers, reference letters, or StudyNav controls",
    link: "Link",
    copy_paragraph_link_title: "Copy a link to this paragraph, verse, or selected verse range",
    languages_count: "$1 languages",
    download_image: "Download image",
    image_download_started: "Image download started",
    copy_page_time: "Copy page + time",
    page_time_copied: "Page link and time copied",
    media_clip: "Media segment",
    media_clip_title: "Download an audio or video segment",
    clip_format: "Format",
    clip_format_audio: "Audio (.wav) \xB7 up to 2 minutes",
    clip_format_video: "Video (.webm) \xB7 up to 1 minute",
    clip_start: "Start",
    clip_end: "End",
    clip_download_audio: "Download WAV",
    clip_download_video: "Record WebM",
    clip_cancel: "Cancel",
    clip_invalid_time: "Enter times as M:SS or H:MM:SS. The end must be after the start.",
    clip_too_long: "Choose a segment no longer than 2 minutes.",
    clip_video_too_long: "Choose a video segment no longer than 1 minute.",
    clip_preparing: "Preparing audio segment\u2026",
    clip_recording: "Recording video segment in real time\u2026",
    clip_downloaded: "Media segment downloaded",
    clip_failed: "The requested media segment could not be created.",
    clip_video_failed: "The video segment could not be created.",
    clip_video_recorder_failed: "The browser recorder failed while creating the video segment.",
    clip_video_timeout: "The video did not advance while the segment was being recorded.",
    clip_video_load_failed: "The official video could not be loaded for recording.",
    clip_video_unsupported: "This browser cannot record a video segment from this player.",
    clip_video_too_large: "The recorded video segment is too large to download safely.",
    clip_source_unavailable: "Play the media once so its source is available, then try again.",
    clip_request_rejected: "This media-segment request was rejected.",
    clip_source_download_failed: "The official media file could not be downloaded.",
    clip_source_too_large: "This media file is too large to process safely.",
    clip_outside_media: "The selected times are outside this media file.",
    second_display: "Second display",
    transcript: "Transcript",
    transcript_search: "Search\u2026",
    transcript_download: "Download .txt",
    close_transcript_aria: "Close transcript",
    loading: "Loading\u2026",
    no_matches: "(no matches)",
    no_transcript_detected: "No transcript text was detected on this page. If captions load later, reopen this panel.",
    annotation_limit: "The local annotation limit has been reached.",
    selection_cannot_save: "This selection cannot be saved.",
    note_updated: "Note updated",
    highlight_saved: "Highlight saved locally",
    select_one_paragraph: "Select text within one paragraph or verse.",
    select_character_count: "Select between 1 and $1 characters.",
    highlight_color_aria: "$1 highlight",
    reattach_note_aria: "Reattach note",
    highlight_selection_aria: "Highlight selected text",
    reattach_here: "Reattach here",
    note_missing: "That note no longer exists.",
    reattach_source_first: "Return to the note\u2019s source page before reattaching it.",
    reattach_cancelled: "Reattach cancelled",
    reattach_instruction: "Select the replacement text, then choose Reattach here.",
    cancel: "Cancel",
    add_note: "Add note",
    edit_highlight: "Edit highlight",
    new_highlight: "New highlight",
    close_highlight_editor_aria: "Close highlight editor",
    highlight_color: "Highlight color",
    color_yellow: "Yellow",
    color_green: "Green",
    color_blue: "Blue",
    color_pink: "Pink",
    color_purple: "Purple",
    color_orange: "Orange",
    page_notes: "Notes on this page",
    open_all_notes: "Open all notes",
    note: "Note",
    write_private_note: "Write a private note\u2026",
    tags: "Tags",
    tags_placeholder: "study, family, review",
    save_locally: "Save locally",
    tags_error: "Use at most 20 short, comma-separated tags.",
    paragraph_mark_unreliable: "This paragraph cannot be marked reliably.",
    needs_attention: "Needs attention",
    delete_highlight_confirm: "Delete this local highlight and note?",
    highlight_deleted: "Highlight deleted",
    locate: "Locate",
    open_page: "Open page",
    edit: "Edit",
    delete: "Delete",
    reattach: "Reattach",
    no_notes_filtered: "No notes match these filters.",
    no_notes_yet: "Select text on an article or verse to create your first highlight.",
    notes_count_one: "$1 note",
    notes_count_many: "$1 notes",
    study_export_failed: "Study data could not be exported.",
    study_backup_downloaded: "Study backup downloaded",
    backup_too_large: "Backup is larger than 5 MB.",
    backup_invalid: "That is not a valid StudyNav backup.",
    import_summary: "Import: $1 added, $2 updated, $3 ignored, $4 rejected",
    notes_tab: "Notes",
    saved_places_tab: "Saved places",
    this_page: "This page",
    all_notes: "All notes",
    all_pages: "All pages",
    search_notes: "Search study notes",
    search_notes_placeholder: "Search quote, note, or tag\u2026",
    search_saved_places: "Search saved places",
    filter_notes_tag: "Filter study notes by tag",
    all_tags: "All tags",
    export_json: "Export JSON",
    import_json: "Import JSON",
    study_library_opened: "Study library opened",
    close_study_library_aria: "Close study library",
    saved_places_count_one: "$1 saved place",
    saved_places_count_many: "$1 saved places",
    no_saved_places_filtered: "No saved places match these filters.",
    no_saved_places_yet: "Save a page, paragraph, or verse to return to it quickly.",
    open_saved_place: "Open",
    remove_saved_place_action: "Remove",
    local_study_data_invalid: "Local study data is invalid and was left unchanged.",
    study_data_validation_failed: "Study data update failed validation.",
    study_data_save_failed: "Study data could not be saved.",
    migration_save_failed: "Migrated study data could not be saved.",
    video_progress_save_failed: "Video progress could not be saved.",
    resume_at: "Resume at $1",
    resume_title: "Seek to saved local progress without starting playback",
    ready_at: "Ready at $1. Press play when you want.",
    resume_wait_loading: "The video must finish loading before it can resume.",
    verse_request_rejected: "This verse audio request was rejected.",
    verse_job_busy: "Another media clip is already being prepared.",
    verse_processing_failed: "Verse audio processing failed.",
    verse_page_unverified: "The Bible page could not be verified.",
    verse_request_invalid: "The selected verse audio request is not valid.",
    verse_timing_unavailable: "The official verse timing data is unavailable.",
    verse_timing_redirected: "The official verse timing request was redirected unexpectedly.",
    verse_timing_missing: "No official audio timing was found for this verse.",
    chapter_audio_download_failed: "The official chapter audio could not be downloaded.",
    chapter_audio_redirected: "The official chapter audio was redirected unexpectedly.",
    decoded_audio_invalid: "Decoded chapter audio is invalid.",
    verse_outside_audio: "The selected verse is outside the chapter audio.",
    verse_audio_too_large: "The selected verse audio is too large to download safely.",
    chapter_audio_too_large: "The chapter audio is too large to process safely.",
    chapter_audio_size_mismatch: "The chapter audio size does not match its official metadata."
  };
  function fallbackFormat(message, substitutions) {
    const values = substitutions === void 0 ? [] : Array.isArray(substitutions) ? substitutions : [substitutions];
    return values.reduce((result, value, index) => result.replaceAll(`$${index + 1}`, value), message);
  }
  function t(key, substitutions) {
    try {
      if (typeof chrome !== "undefined" && chrome.i18n?.getMessage) {
        const translated = chrome.i18n.getMessage(key, substitutions);
        if (translated) return translated;
      }
    } catch {
    }
    return fallbackFormat(EN_MESSAGES[key], substitutions);
  }

  // packages/studynav/src/study-data.ts
  var STUDY_DATA_LEGACY_STORAGE_KEY = "studynavStudyDataV1";
  var STUDY_DATA_V2_STORAGE_KEY = "studynavStudyDataV2";
  var STUDY_DATA_STORAGE_KEY = STUDY_DATA_V2_STORAGE_KEY;
  var STUDY_DATA_SCHEMA_V1 = 1;
  var STUDY_DATA_SCHEMA_VERSION = 2;
  var HIGHLIGHT_COLORS = ["yellow", "green", "blue", "pink", "purple", "orange"];
  var MAX_BACKUP_JSON_BYTES = 5 * 1024 * 1024;
  var MAX_ANNOTATIONS = 5e3;
  var MAX_TEXT_LENGTH = 1e4;
  var MAX_CONTEXT_LENGTH = 32;
  var MAX_NOTE_LENGTH = 2e4;
  var MAX_TAGS = 20;
  var MAX_TAG_LENGTH = 48;
  var MAX_URL_LENGTH = 2048;
  var MAX_TITLE_LENGTH = 512;
  var MAX_IDENTIFIER_LENGTH = 256;
  var MAX_MEDIA_PROGRESS = 500;
  var MAX_BOOKMARKS = 500;
  var MAX_REFERENCE_LENGTH = 512;
  var MAX_MEDIA_SOURCE_LENGTH = 2048;
  var MAX_TIMESTAMP = Number.MAX_SAFE_INTEGER;
  var MEDIA_PROGRESS_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1e3;
  var EMPTY_IMPORT_STATS = {
    accepted: 0,
    updated: 0,
    ignored: 0,
    rejected: 0
  };
  var ANNOTATION_KEYS = [
    "id",
    "pageUrl",
    "title",
    "root",
    "selector",
    "color",
    "note",
    "tags",
    "createdAt",
    "updatedAt"
  ];
  var ANNOTATION_REQUIRED_KEYS = [
    "id",
    "pageUrl",
    "title",
    "root",
    "selector",
    "color",
    "createdAt",
    "updatedAt"
  ];
  var MEDIA_PROGRESS_KEYS = [
    "id",
    "pageUrl",
    "mediaSource",
    "title",
    "currentTime",
    "duration",
    "updatedAt"
  ];
  var BOOKMARK_KEYS = [
    "id",
    "pageUrl",
    "targetUrl",
    "title",
    "reference",
    "createdAt",
    "updatedAt"
  ];
  var ROOT_KEYS = ["id", "dataPid", "dataVerse"];
  var SELECTOR_KEYS = ["exact", "prefix", "suffix", "start", "end"];
  var V1_ENVELOPE_KEYS = ["schemaVersion", "annotations", "mediaProgress"];
  var V2_ENVELOPE_KEYS = ["schemaVersion", "annotations", "mediaProgress", "bookmarks"];
  function hasOwn(value, key) {
    return Object.prototype.hasOwnProperty.call(value, key);
  }
  function isPlainRecord(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
    try {
      const prototype = Object.getPrototypeOf(value);
      return prototype === Object.prototype || prototype === null;
    } catch {
      return false;
    }
  }
  function hasExactKeys(value, keys) {
    const ownKeys = Object.keys(value);
    if (ownKeys.length !== keys.length) return false;
    const allowed = new Set(keys);
    return ownKeys.every((key) => allowed.has(key));
  }
  function hasOnlyAllowedKeys(value, keys) {
    const allowed = new Set(keys);
    return Object.keys(value).every((key) => allowed.has(key));
  }
  function hasRequiredKeys(value, keys) {
    return keys.every((key) => hasOwn(value, key));
  }
  function codePointLength(value) {
    return Array.from(value).length;
  }
  function hasControlCharacters(value) {
    return /[\u0000-\u001f\u007f]/u.test(value);
  }
  function finiteSafeInteger(value, minimum = 0, maximum = MAX_TIMESTAMP) {
    return typeof value === "number" && Number.isSafeInteger(value) && value >= minimum && value <= maximum;
  }
  function finiteNumber(value, minimum = -Infinity, maximum = Infinity) {
    return typeof value === "number" && Number.isFinite(value) && value >= minimum && value <= maximum;
  }
  function boundedString(value, minimum, maximum, options = {}) {
    if (typeof value !== "string") return false;
    if (codePointLength(value) < minimum || codePointLength(value) > maximum) return false;
    if (!options.allowControls && hasControlCharacters(value)) return false;
    return true;
  }
  function normalizeWhitespace(value) {
    return value.normalize("NFKC").replace(/[\s\u00a0]+/gu, " ").trim();
  }
  function normalizeIdentifier(value, maximum = MAX_IDENTIFIER_LENGTH) {
    if (!boundedString(value, 1, maximum)) return null;
    const normalized = value.normalize("NFKC").trim();
    if (!normalized || codePointLength(normalized) > maximum || hasControlCharacters(normalized)) return null;
    return normalized;
  }
  function isSupportedHost(hostname) {
    const host = hostname.toLowerCase();
    return host === "jw.org" || host.endsWith(".jw.org") || host === "wol.jw.org" || host === "stream.jw.org";
  }
  function normalizeSupportedUrl(value, preserveHash) {
    if (!boundedString(value, 1, MAX_URL_LENGTH)) return null;
    const source = value.trim();
    if (!source || hasControlCharacters(source)) return null;
    try {
      const url = new URL(source);
      if (url.protocol !== "https:" || url.username || url.password || !isSupportedHost(url.hostname)) return null;
      const encodedParts = [url.pathname, url.search, url.hash];
      if (encodedParts.some((part) => {
        try {
          return hasControlCharacters(decodeURIComponent(part));
        } catch {
          return true;
        }
      })) return null;
      url.hostname = url.hostname.toLowerCase();
      if (!preserveHash) url.hash = "";
      else if (hasControlCharacters(url.hash)) return null;
      url.pathname = (url.pathname || "/").normalize("NFC");
      url.searchParams.sort();
      const normalized = url.href;
      return boundedString(normalized, 1, MAX_URL_LENGTH) && !hasControlCharacters(normalized) ? normalized : null;
    } catch {
      return null;
    }
  }
  function normalizeStudyPageUrl(value) {
    return normalizeSupportedUrl(value, false);
  }
  function normalizeStudyTargetUrl(value) {
    return normalizeSupportedUrl(value, true);
  }
  function createEmptyStudyData() {
    return {
      schemaVersion: STUDY_DATA_SCHEMA_VERSION,
      annotations: [],
      mediaProgress: [],
      bookmarks: []
    };
  }
  function normalizeTags(value) {
    let source;
    if (typeof value === "string") {
      source = value.split(",");
    } else if (Array.isArray(value) && value.every((item) => typeof item === "string")) {
      source = value.flatMap((item) => item.split(","));
    } else {
      return null;
    }
    const tags = [];
    const seen = /* @__PURE__ */ new Set();
    for (const raw of source) {
      if (!boundedString(raw, 0, MAX_TAG_LENGTH, { allowControls: false })) return null;
      const tag = raw.normalize("NFKC").replace(/[\s\u00a0]+/gu, " ").trim().toLowerCase();
      if (!tag) continue;
      if (codePointLength(tag) > MAX_TAG_LENGTH || hasControlCharacters(tag)) return null;
      if (seen.has(tag)) continue;
      if (tags.length >= MAX_TAGS) return null;
      seen.add(tag);
      tags.push(tag);
    }
    return tags;
  }
  function validateRootReference(value) {
    if (!isPlainRecord(value) || !hasOnlyAllowedKeys(value, ROOT_KEYS)) return null;
    const identifiers = {};
    for (const key of ROOT_KEYS) {
      if (!hasOwn(value, key)) continue;
      const raw = value[key];
      if (raw === void 0 || raw === null) return null;
      const identifier = normalizeIdentifier(raw);
      if (identifier === null) return null;
      identifiers[key] = identifier;
    }
    const present = ROOT_KEYS.filter((key) => identifiers[key] !== void 0);
    if (present.length !== 1) return null;
    return identifiers;
  }
  function rootReferenceKey(value) {
    if (value.id) return `id:${value.id}`;
    if (value.dataPid) return `data-pid:${value.dataPid}`;
    if (value.dataVerse) return `data-verse:${value.dataVerse}`;
    return "";
  }
  function validateTextSelector(value) {
    if (!isPlainRecord(value) || !hasExactKeys(value, SELECTOR_KEYS)) return null;
    if (!boundedString(value.exact, 1, MAX_TEXT_LENGTH, { allowControls: true })) return null;
    if (!boundedString(value.prefix, 0, MAX_CONTEXT_LENGTH, { allowControls: true })) return null;
    if (!boundedString(value.suffix, 0, MAX_CONTEXT_LENGTH, { allowControls: true })) return null;
    if (!finiteSafeInteger(value.start, 0, Number.MAX_SAFE_INTEGER)) return null;
    if (!finiteSafeInteger(value.end, 1, Number.MAX_SAFE_INTEGER)) return null;
    if (value.end <= value.start || value.end - value.start !== value.exact.length) return null;
    return {
      exact: value.exact,
      prefix: value.prefix,
      suffix: value.suffix,
      start: value.start,
      end: value.end
    };
  }
  function takeLastCodePoints(value, count) {
    return Array.from(value).slice(-count).join("");
  }
  function takeFirstCodePoints(value, count) {
    return Array.from(value).slice(0, count).join("");
  }
  function createTextSelector(text, start, end) {
    if (typeof text !== "string") return null;
    if (!finiteSafeInteger(start, 0, Number.MAX_SAFE_INTEGER) || !finiteSafeInteger(end, 1, Number.MAX_SAFE_INTEGER)) return null;
    if (start >= end || end > text.length) return null;
    const exact = text.slice(start, end);
    if (!boundedString(exact, 1, MAX_TEXT_LENGTH, { allowControls: true })) return null;
    const selector = {
      exact,
      prefix: takeLastCodePoints(text.slice(0, start), MAX_CONTEXT_LENGTH),
      suffix: takeFirstCodePoints(text.slice(end), MAX_CONTEXT_LENGTH),
      start,
      end
    };
    return validateTextSelector(selector);
  }
  function findExactMatches(text, selector) {
    const matches = [];
    let offset = 0;
    while (offset <= text.length - selector.exact.length) {
      const start = text.indexOf(selector.exact, offset);
      if (start < 0) break;
      const end = start + selector.exact.length;
      const prefix = text.slice(Math.max(0, start - selector.prefix.length), start);
      const suffix = text.slice(end, end + selector.suffix.length);
      if (prefix === selector.prefix && suffix === selector.suffix) matches.push({ start, end });
      offset = start + 1;
    }
    return matches;
  }
  function rootForSnapshot(value) {
    if (!isPlainRecord(value)) return null;
    const root = validateRootReference(value.root);
    if (!root || typeof value.text !== "string") return null;
    return { root, text: value.text };
  }
  function resolveTextSelector(selectorValue, savedRootValue, savedText, eligibleRoots) {
    if (!Array.isArray(eligibleRoots)) return null;
    const selector = validateTextSelector(selectorValue);
    const savedRoot = validateRootReference(savedRootValue);
    if (!selector || !savedRoot) return null;
    if (typeof savedText === "string" && selector.end <= savedText.length && savedText.slice(selector.start, selector.end) === selector.exact) {
      return {
        root: savedRoot,
        start: selector.start,
        end: selector.end,
        exact: selector.exact,
        method: "position",
        recovered: false
      };
    }
    if (typeof savedText === "string") {
      const savedMatches = findExactMatches(savedText, selector);
      if (savedMatches.length === 1) {
        return {
          root: savedRoot,
          ...savedMatches[0],
          exact: selector.exact,
          method: "saved-root-quote",
          recovered: true
        };
      }
      if (savedMatches.length > 1) return null;
    }
    const savedKey = rootReferenceKey(savedRoot);
    const matches = [];
    const seenSnapshots = /* @__PURE__ */ new Set();
    for (const candidateValue of eligibleRoots) {
      const candidate = rootForSnapshot(candidateValue);
      if (!candidate) continue;
      const key = rootReferenceKey(candidate.root);
      if (!key || seenSnapshots.has(key)) continue;
      seenSnapshots.add(key);
      if (key === savedKey) continue;
      for (const match of findExactMatches(candidate.text, selector)) {
        matches.push({
          root: candidate.root,
          ...match,
          exact: selector.exact,
          method: "other-root-quote",
          recovered: true,
          key
        });
      }
    }
    if (matches.length !== 1) return null;
    const { key: _key, ...resolution } = matches[0];
    return resolution;
  }
  function validateAnnotation(value) {
    if (!isPlainRecord(value) || !hasOnlyAllowedKeys(value, ANNOTATION_KEYS) || !hasRequiredKeys(value, ANNOTATION_REQUIRED_KEYS)) return null;
    const id = normalizeIdentifier(value.id);
    const pageUrl = normalizeStudyPageUrl(value.pageUrl);
    const title = boundedString(value.title, 0, MAX_TITLE_LENGTH) ? normalizeWhitespace(value.title) : null;
    const root = validateRootReference(value.root);
    const selector = validateTextSelector(value.selector);
    const color = typeof value.color === "string" && HIGHLIGHT_COLORS.includes(value.color) ? value.color : null;
    const noteValue = hasOwn(value, "note") ? value.note : "";
    const tagsValue = hasOwn(value, "tags") ? value.tags : [];
    const note = boundedString(noteValue, 0, MAX_NOTE_LENGTH, { allowControls: true }) ? noteValue : null;
    const tags = normalizeTags(tagsValue);
    if (id === null || pageUrl === null || title === null || root === null || selector === null || color === null || note === null || tags === null || !finiteSafeInteger(value.createdAt) || !finiteSafeInteger(value.updatedAt) || value.updatedAt < value.createdAt) return null;
    return {
      id,
      pageUrl,
      title,
      root,
      selector,
      color,
      note,
      tags,
      createdAt: value.createdAt,
      updatedAt: value.updatedAt
    };
  }
  function mediaProgressKey(pageUrl, mediaSource2) {
    return `${pageUrl}\0${mediaSource2}`;
  }
  function createMediaProgressId(pageUrl, mediaSource2) {
    const normalizedPageUrl = normalizeStudyPageUrl(pageUrl);
    if (normalizedPageUrl === null || !boundedString(mediaSource2, 1, MAX_MEDIA_SOURCE_LENGTH)) return null;
    const normalizedSource = mediaSource2.trim();
    if (!normalizedSource || hasControlCharacters(normalizedSource)) return null;
    return mediaProgressKey(normalizedPageUrl, normalizedSource);
  }
  function createMediaProgressRecord(pageUrl, mediaSource2, title, currentTime, duration, updatedAt) {
    const normalizedPageUrl = normalizeStudyPageUrl(pageUrl);
    const normalizedSource = typeof mediaSource2 === "string" ? mediaSource2.trim() : "";
    const id = normalizedPageUrl === null ? null : createMediaProgressId(normalizedPageUrl, normalizedSource);
    if (id === null) return null;
    return validateMediaProgress({
      id,
      pageUrl: normalizedPageUrl,
      mediaSource: normalizedSource,
      title,
      currentTime,
      duration,
      updatedAt
    });
  }
  function validateMediaProgress(value) {
    if (!isPlainRecord(value) || !hasExactKeys(value, MEDIA_PROGRESS_KEYS)) return null;
    const pageUrl = normalizeStudyPageUrl(value.pageUrl);
    const mediaSource2 = boundedString(value.mediaSource, 1, MAX_MEDIA_SOURCE_LENGTH) ? value.mediaSource.trim() : null;
    const title = boundedString(value.title, 0, MAX_TITLE_LENGTH) ? normalizeWhitespace(value.title) : null;
    if (pageUrl === null || mediaSource2 === null || !mediaSource2 || hasControlCharacters(mediaSource2) || title === null || !finiteNumber(value.currentTime, 5) || !finiteNumber(value.duration, Number.MIN_VALUE) || value.currentTime > value.duration - 5 || !finiteSafeInteger(value.updatedAt)) return null;
    const id = createMediaProgressId(pageUrl, mediaSource2);
    if (id === null || value.id !== id) return null;
    return {
      id,
      pageUrl,
      mediaSource: mediaSource2,
      title,
      currentTime: value.currentTime,
      duration: value.duration,
      updatedAt: value.updatedAt
    };
  }
  function normalizeBookmarkId(value) {
    return normalizeIdentifier(value, MAX_IDENTIFIER_LENGTH);
  }
  function validateBookmarkRecord(value) {
    if (!isPlainRecord(value) || !hasExactKeys(value, BOOKMARK_KEYS)) return null;
    const id = normalizeBookmarkId(value.id);
    const pageUrl = normalizeStudyPageUrl(value.pageUrl);
    const targetUrl = normalizeStudyTargetUrl(value.targetUrl);
    const targetPageUrl = targetUrl === null ? null : normalizeStudyPageUrl(targetUrl);
    const title = boundedString(value.title, 0, MAX_TITLE_LENGTH) ? normalizeWhitespace(value.title) : null;
    const reference = boundedString(value.reference, 0, MAX_REFERENCE_LENGTH) ? normalizeWhitespace(value.reference) : null;
    if (id === null || pageUrl === null || targetUrl === null || targetPageUrl === null || targetPageUrl !== pageUrl || title === null || reference === null || !finiteSafeInteger(value.createdAt) || !finiteSafeInteger(value.updatedAt) || value.updatedAt < value.createdAt) return null;
    return {
      id,
      pageUrl,
      targetUrl,
      title,
      reference,
      createdAt: value.createdAt,
      updatedAt: value.updatedAt
    };
  }
  function createBookmarkId(targetUrl) {
    const target = normalizeStudyTargetUrl(targetUrl);
    if (target === null) return null;
    let first = 2166136261;
    let second = 2654435769;
    for (let index = 0; index < target.length; index += 1) {
      const code = target.charCodeAt(index);
      first = Math.imul(first ^ code, 16777619);
      second = Math.imul(second ^ code + index, 16777619);
    }
    const firstHex = (first >>> 0).toString(16).padStart(8, "0");
    const secondHex = (second >>> 0).toString(16).padStart(8, "0");
    return `bookmark:${firstHex}${secondHex}`;
  }
  function createBookmarkRecord(...args) {
    if (args.length === 1) return validateBookmarkRecord(args[0]);
    if (args.length < 6) return null;
    const first = args[0];
    const second = args[1];
    const firstLooksLikeUrl = typeof first === "string" && /^https?:\/\//iu.test(first.trim());
    const secondLooksLikeUrl = typeof second === "string" && /^https?:\/\//iu.test(second.trim());
    if (firstLooksLikeUrl && secondLooksLikeUrl) {
      const [pageUrl2, targetUrl2, title2, reference2, createdAt2, updatedAt2, suppliedId] = args;
      return validateBookmarkRecord({
        id: suppliedId === void 0 ? createBookmarkId(targetUrl2) : suppliedId,
        pageUrl: pageUrl2,
        targetUrl: targetUrl2,
        title: title2,
        reference: reference2,
        createdAt: createdAt2,
        updatedAt: updatedAt2
      });
    }
    const [id, pageUrl, targetUrl, title, reference, createdAt, updatedAt = createdAt] = args;
    return validateBookmarkRecord({ id, pageUrl, targetUrl, title, reference, createdAt, updatedAt });
  }
  function sortAnnotations(records) {
    return [...records].sort((left, right) => {
      if (right.updatedAt !== left.updatedAt) return right.updatedAt - left.updatedAt;
      return left.id < right.id ? -1 : left.id > right.id ? 1 : 0;
    });
  }
  function sortMediaProgress(records) {
    return [...records].sort((left, right) => {
      if (right.updatedAt !== left.updatedAt) return right.updatedAt - left.updatedAt;
      return left.id < right.id ? -1 : left.id > right.id ? 1 : 0;
    });
  }
  function pruneMediaProgress(values, now) {
    if (now !== void 0 && !finiteSafeInteger(now)) return [];
    const byId = /* @__PURE__ */ new Map();
    for (const value of values) {
      const record = validateMediaProgress(value);
      if (!record || now !== void 0 && (now - record.updatedAt > MEDIA_PROGRESS_MAX_AGE_MS || record.updatedAt > now)) continue;
      const existing = byId.get(record.id);
      if (!existing || record.updatedAt > existing.updatedAt) byId.set(record.id, record);
    }
    return sortMediaProgress([...byId.values()]).slice(0, MAX_MEDIA_PROGRESS);
  }
  function upsertMediaProgress(current, incoming, now) {
    const records = pruneMediaProgress(current, now);
    const candidate = validateMediaProgress(incoming);
    if (!candidate || now !== void 0 && (!finiteSafeInteger(now) || candidate.updatedAt > now || now - candidate.updatedAt > MEDIA_PROGRESS_MAX_AGE_MS)) return records;
    const existing = records.find((record) => record.id === candidate.id);
    if (existing && existing.updatedAt >= candidate.updatedAt) return records;
    const next = records.filter((record) => record.id !== candidate.id);
    next.push(candidate);
    return sortMediaProgress(next).slice(0, MAX_MEDIA_PROGRESS);
  }
  function validateEnvelopeShape(value) {
    if (!isPlainRecord(value)) return null;
    if (value.schemaVersion === STUDY_DATA_SCHEMA_V1 && hasExactKeys(value, V1_ENVELOPE_KEYS) && Array.isArray(value.annotations) && Array.isArray(value.mediaProgress)) {
      return {
        schemaVersion: STUDY_DATA_SCHEMA_V1,
        annotations: value.annotations,
        mediaProgress: value.mediaProgress
      };
    }
    if (value.schemaVersion === STUDY_DATA_SCHEMA_VERSION && hasExactKeys(value, V2_ENVELOPE_KEYS) && Array.isArray(value.annotations) && Array.isArray(value.mediaProgress) && Array.isArray(value.bookmarks)) {
      return {
        schemaVersion: STUDY_DATA_SCHEMA_VERSION,
        annotations: value.annotations,
        mediaProgress: value.mediaProgress,
        bookmarks: value.bookmarks
      };
    }
    return null;
  }
  function validateAnnotationArray(values) {
    if (values.length > MAX_ANNOTATIONS) return null;
    const annotations = [];
    const annotationIds = /* @__PURE__ */ new Set();
    for (const item of values) {
      const record = validateAnnotation(item);
      if (!record || annotationIds.has(record.id)) return null;
      annotationIds.add(record.id);
      annotations.push(record);
    }
    return sortAnnotations(annotations);
  }
  function validateMediaProgressArray(values) {
    if (values.length > MAX_MEDIA_PROGRESS) return null;
    const mediaProgress = [];
    const mediaIds = /* @__PURE__ */ new Set();
    for (const item of values) {
      const record = validateMediaProgress(item);
      if (!record || mediaIds.has(record.id)) return null;
      mediaIds.add(record.id);
      mediaProgress.push(record);
    }
    return sortMediaProgress(mediaProgress);
  }
  function sortBookmarks(records) {
    return [...records].sort((left, right) => {
      if (right.updatedAt !== left.updatedAt) return right.updatedAt - left.updatedAt;
      return left.id < right.id ? -1 : left.id > right.id ? 1 : 0;
    });
  }
  function validateBookmarkArray(values) {
    if (values.length > MAX_BOOKMARKS) return null;
    const bookmarks = [];
    const bookmarkIds = /* @__PURE__ */ new Set();
    const targetUrls = /* @__PURE__ */ new Set();
    for (const item of values) {
      const record = validateBookmarkRecord(item);
      if (!record || bookmarkIds.has(record.id) || targetUrls.has(record.targetUrl)) return null;
      bookmarkIds.add(record.id);
      targetUrls.add(record.targetUrl);
      bookmarks.push(record);
    }
    return sortBookmarks(bookmarks);
  }
  function validateStudyDataV1(value) {
    const envelope = validateEnvelopeShape(value);
    if (!envelope || envelope.schemaVersion !== STUDY_DATA_SCHEMA_V1) return null;
    const annotations = validateAnnotationArray(envelope.annotations);
    const mediaProgress = validateMediaProgressArray(envelope.mediaProgress);
    if (!annotations || !mediaProgress) return null;
    return { schemaVersion: STUDY_DATA_SCHEMA_V1, annotations, mediaProgress };
  }
  function validateStudyData(value) {
    const envelope = validateEnvelopeShape(value);
    if (!envelope || envelope.schemaVersion !== STUDY_DATA_SCHEMA_VERSION) return null;
    const annotations = validateAnnotationArray(envelope.annotations);
    const mediaProgress = validateMediaProgressArray(envelope.mediaProgress);
    const bookmarks = validateBookmarkArray(envelope.bookmarks);
    if (!annotations || !mediaProgress || !bookmarks) return null;
    return {
      schemaVersion: STUDY_DATA_SCHEMA_VERSION,
      annotations,
      mediaProgress,
      bookmarks
    };
  }
  function migrateStudyDataV1(value) {
    const legacy = validateStudyDataV1(value);
    if (!legacy) return null;
    return {
      schemaVersion: STUDY_DATA_SCHEMA_VERSION,
      annotations: legacy.annotations,
      mediaProgress: legacy.mediaProgress,
      bookmarks: []
    };
  }
  function utf8ByteLength(value) {
    return new TextEncoder().encode(value).byteLength;
  }
  function parseStudyDataBackup(value) {
    if (typeof value !== "string") return { data: null, error: "invalid-input" };
    if (utf8ByteLength(value) > MAX_BACKUP_JSON_BYTES) return { data: null, error: "too-large" };
    let parsed;
    try {
      parsed = JSON.parse(value);
    } catch {
      return { data: null, error: "invalid-json" };
    }
    const data = validateEnvelopeShape(parsed);
    return data ? { data, error: null } : { data: null, error: "invalid-envelope" };
  }
  function readIncomingRecords(value) {
    const envelope = validateEnvelopeShape(value);
    if (!envelope) return { annotations: [], mediaProgress: [], bookmarks: [], envelopeValid: false };
    return {
      annotations: envelope.annotations.map((item) => validateAnnotation(item)),
      mediaProgress: envelope.mediaProgress.map((item) => validateMediaProgress(item)),
      bookmarks: envelope.schemaVersion === STUDY_DATA_SCHEMA_VERSION ? envelope.bookmarks.map((item) => validateBookmarkRecord(item)) : [],
      envelopeValid: true
    };
  }
  function normalizeBookmarkRecords(values) {
    const byId = /* @__PURE__ */ new Map();
    const byTarget = /* @__PURE__ */ new Map();
    const remove = (record) => {
      byId.delete(record.id);
      if (byTarget.get(record.targetUrl)?.id === record.id) byTarget.delete(record.targetUrl);
    };
    for (const value of values) {
      const candidate = validateBookmarkRecord(value);
      if (!candidate) continue;
      const existingById = byId.get(candidate.id);
      const existingByTarget = byTarget.get(candidate.targetUrl);
      const existing = existingById || existingByTarget;
      if (existing) {
        const newestExistingAt = Math.max(existingById?.updatedAt || 0, existingByTarget?.updatedAt || 0);
        if (candidate.updatedAt <= newestExistingAt) continue;
        if (existingById) remove(existingById);
        if (existingByTarget && existingByTarget.id !== existingById?.id) remove(existingByTarget);
      }
      byId.set(candidate.id, candidate);
      byTarget.set(candidate.targetUrl, candidate);
    }
    return sortBookmarks([...byId.values()]).slice(0, MAX_BOOKMARKS);
  }
  function normalizedCurrentData(value, now) {
    const envelope = validateEnvelopeShape(value);
    if (!envelope) return createEmptyStudyData();
    const annotations = [];
    const annotationIds = /* @__PURE__ */ new Set();
    for (const item of envelope.annotations) {
      const record = validateAnnotation(item);
      if (!record || annotationIds.has(record.id)) continue;
      annotationIds.add(record.id);
      annotations.push(record);
      if (annotations.length >= MAX_ANNOTATIONS) break;
    }
    const mediaProgress = pruneMediaProgress(envelope.mediaProgress, now);
    const bookmarkValues = envelope.schemaVersion === STUDY_DATA_SCHEMA_VERSION ? envelope.bookmarks : [];
    return {
      schemaVersion: STUDY_DATA_SCHEMA_VERSION,
      annotations: sortAnnotations(annotations),
      mediaProgress,
      bookmarks: normalizeBookmarkRecords(bookmarkValues)
    };
  }
  function mergeAnnotationRecords(current, incoming, stats) {
    const byId = new Map(current.map((record) => [record.id, record]));
    for (const candidate of incoming) {
      if (candidate === null) {
        stats.rejected += 1;
        continue;
      }
      const existing = byId.get(candidate.id);
      if (existing) {
        if (candidate.updatedAt > existing.updatedAt) {
          byId.set(candidate.id, candidate);
          stats.updated += 1;
        } else {
          stats.ignored += 1;
        }
        continue;
      }
      if (byId.size >= MAX_ANNOTATIONS) {
        stats.ignored += 1;
        continue;
      }
      byId.set(candidate.id, candidate);
      stats.accepted += 1;
    }
    return sortAnnotations([...byId.values()]);
  }
  function mergeMediaRecords(current, incoming, stats, now) {
    const byId = new Map(current.map((record) => [record.id, record]));
    for (const candidate of incoming) {
      if (candidate === null) {
        stats.rejected += 1;
        continue;
      }
      if (now !== void 0 && (candidate.updatedAt > now || now - candidate.updatedAt > MEDIA_PROGRESS_MAX_AGE_MS)) {
        stats.ignored += 1;
        continue;
      }
      const existing = byId.get(candidate.id);
      if (existing && existing.updatedAt >= candidate.updatedAt) {
        stats.ignored += 1;
        continue;
      }
      if (existing) stats.updated += 1;
      else stats.accepted += 1;
      byId.set(candidate.id, candidate);
    }
    const sorted = sortMediaProgress([...byId.values()]);
    const retained = sorted.slice(0, MAX_MEDIA_PROGRESS);
    stats.ignored += Math.max(0, sorted.length - retained.length);
    return retained;
  }
  function mergeBookmarkRecords(current, incoming, stats) {
    const byId = new Map(current.map((record) => [record.id, record]));
    const byTarget = new Map(current.map((record) => [record.targetUrl, record]));
    const remove = (record) => {
      byId.delete(record.id);
      if (byTarget.get(record.targetUrl)?.id === record.id) byTarget.delete(record.targetUrl);
    };
    for (const candidate of incoming) {
      if (candidate === null) {
        stats.rejected += 1;
        continue;
      }
      const existingById = byId.get(candidate.id);
      const existingByTarget = byTarget.get(candidate.targetUrl);
      const existing = existingById || existingByTarget;
      if (existing) {
        const newestExistingAt = Math.max(existingById?.updatedAt || 0, existingByTarget?.updatedAt || 0);
        if (candidate.updatedAt <= newestExistingAt) {
          stats.ignored += 1;
          continue;
        }
        if (existingById) remove(existingById);
        if (existingByTarget && existingByTarget.id !== existingById?.id) remove(existingByTarget);
        byId.set(candidate.id, candidate);
        byTarget.set(candidate.targetUrl, candidate);
        stats.updated += 1;
        continue;
      }
      if (byId.size >= MAX_BOOKMARKS) {
        stats.ignored += 1;
        continue;
      }
      byId.set(candidate.id, candidate);
      byTarget.set(candidate.targetUrl, candidate);
      stats.accepted += 1;
    }
    return sortBookmarks([...byId.values()]).slice(0, MAX_BOOKMARKS);
  }
  function mergeStudyData(currentValue, incomingValue, now) {
    const current = normalizedCurrentData(currentValue, now);
    const stats = { ...EMPTY_IMPORT_STATS };
    const incoming = readIncomingRecords(incomingValue);
    if (!incoming.envelopeValid) {
      stats.rejected = 1;
      return { data: current, stats };
    }
    const annotations = mergeAnnotationRecords(current.annotations, incoming.annotations, stats);
    const mediaProgress = mergeMediaRecords(current.mediaProgress, incoming.mediaProgress, stats, now);
    const bookmarks = mergeBookmarkRecords(current.bookmarks, incoming.bookmarks, stats);
    return {
      data: {
        schemaVersion: STUDY_DATA_SCHEMA_VERSION,
        annotations,
        mediaProgress,
        bookmarks
      },
      stats
    };
  }
  function serializeStudyData(value) {
    const data = validateStudyData(value) || migrateStudyDataV1(value);
    if (!data) return null;
    const json = JSON.stringify(data);
    return utf8ByteLength(json) <= MAX_BACKUP_JSON_BYTES ? json : null;
  }

  // packages/studynav/src/study-storage.ts
  var mutationTail = Promise.resolve();
  var StudyDataStorageError = class extends Error {
    constructor(message, options) {
      super(message, options);
      this.name = "StudyDataStorageError";
    }
  };
  async function loadStudyData() {
    const stored = await chrome.storage.local.get([
      STUDY_DATA_STORAGE_KEY,
      STUDY_DATA_LEGACY_STORAGE_KEY
    ]);
    const rawV2 = stored[STUDY_DATA_STORAGE_KEY];
    if (rawV2 !== void 0) {
      const data = validateStudyData(rawV2);
      if (!data) throw new StudyDataStorageError(t("local_study_data_invalid"));
      return data;
    }
    const rawV1 = stored[STUDY_DATA_LEGACY_STORAGE_KEY];
    if (rawV1 === void 0) return createEmptyStudyData();
    const migrated = migrateStudyDataV1(rawV1);
    if (!migrated) throw new StudyDataStorageError(t("local_study_data_invalid"));
    try {
      await chrome.storage.local.set({ [STUDY_DATA_STORAGE_KEY]: migrated });
    } catch (error) {
      throw new StudyDataStorageError(t("migration_save_failed"), { cause: error });
    }
    return migrated;
  }
  function mutateStudyData(mutate) {
    const operation = mutationTail.then(async () => {
      const current = await loadStudyData();
      const candidate = await mutate(current);
      const next = validateStudyData(candidate);
      if (!next) throw new StudyDataStorageError(t("study_data_validation_failed"));
      try {
        await chrome.storage.local.set({ [STUDY_DATA_STORAGE_KEY]: next });
      } catch (error) {
        throw new StudyDataStorageError(t("study_data_save_failed"), { cause: error });
      }
      return next;
    });
    mutationTail = operation.then(() => void 0, () => void 0);
    return operation;
  }
  function studyDataChanged(changes, areaName) {
    return areaName === "local" && (Object.prototype.hasOwnProperty.call(changes, STUDY_DATA_STORAGE_KEY) || Object.prototype.hasOwnProperty.call(changes, STUDY_DATA_LEGACY_STORAGE_KEY));
  }

  // packages/shared/src/index.ts
  async function copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.left = "-9999px";
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand("copy");
        ta.remove();
        return ok;
      } catch {
        return false;
      }
    }
  }

  // packages/studynav/src/util.ts
  function qs(sel, root = document) {
    return root.querySelector(sel);
  }
  function qsa(sel, root = document) {
    return Array.from(root.querySelectorAll(sel));
  }
  function toast(msg) {
    let el = document.getElementById("studynav-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "studynav-toast";
      el.className = "studynav-toast";
      el.setAttribute("data-studynav-owned", "1");
      document.documentElement.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(el._t);
    el._t = window.setTimeout(() => el.classList.remove("show"), 1600);
  }
  async function copy(text, ok = t("copied")) {
    const fine = await copyToClipboard(text);
    toast(fine ? ok : t("copy_failed"));
    return fine;
  }
  var JW_LIBRARY_PATH_RE = /^\/[a-z]{2}(?:-[a-z]+)?\/(?:library|biblioteka|biblioteca|bibliothek|bibliotheque|bibliotek|finder)(?:\/|$)/i;
  var JW_CYRILLIC_LIBRARY_PATH_RE = /^\/(?:ru\/библиотека|uk\/бібліотека)(?:\/|$)/iu;
  var JW_SEARCH_PATH_RE = /^\/[a-z]{2}(?:-[a-z]+)?\/search(?:\/|$)/i;
  var JW_NON_ARTICLE_PATH_RE = /^\/[a-z]{2}(?:-[a-z]+)?\/(?:search|choose-language|login)(?:\/|$)/i;
  var WOL_PATH_RE = /^\/[a-z]{2}(?:-[a-z]+)?\/wol(?:\/|$)/i;
  function isJwLibraryPath(pathname) {
    if (JW_LIBRARY_PATH_RE.test(pathname)) return true;
    try {
      return JW_CYRILLIC_LIBRARY_PATH_RE.test(decodeURIComponent(pathname).normalize("NFC"));
    } catch {
      return false;
    }
  }
  var ARTICLE_ROOT_SELECTORS = [
    "#article",
    "#content",
    "article",
    ".bodyTxt",
    ".syn-body",
    ".document",
    ".docClass-text",
    ".scalableui",
    ".jwac"
  ];
  var MEDIA_SURFACE_SELECTORS = [
    "video",
    "audio",
    ".video-js",
    ".jwplayer",
    '[class*="mediaPlayer"]',
    '[class*="MediaPlayer"]'
  ];
  function uniqueElements(items) {
    const seen = /* @__PURE__ */ new Set();
    for (const item of items) seen.add(item);
    return [...seen];
  }
  function queryWithinRoots(selectors, roots) {
    if (!roots.length) return [];
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const root of roots) {
      for (const selector of selectors) {
        for (const el of qsa(selector, root)) {
          if (seen.has(el)) continue;
          seen.add(el);
          out.push(el);
        }
      }
    }
    return out;
  }
  var PARAGRAPH_TAGS = /* @__PURE__ */ new Set(["P"]);
  var VERSE_TAGS = /* @__PURE__ */ new Set(["P", "DIV", "SPAN", "LI"]);
  function classTokens(input) {
    return new Set(String(input || "").split(/\s+/).map((part) => part.trim()).filter(Boolean));
  }
  function articleRootPriority(shape) {
    const tagName = String(shape.tagName || "").toUpperCase();
    const id = String(shape.id || "");
    const tokens = classTokens(shape.className);
    const dataPidDescendants = Number(shape.dataPidDescendants || 0);
    if (tokens.has("PageNotFound")) return 0;
    if (id === "article") return 100;
    if (tagName === "ARTICLE") return 95;
    if (tokens.has("bodyTxt") || tokens.has("syn-body") || tokens.has("document") || tokens.has("docClass-text") || tokens.has("scalableui")) {
      return 90;
    }
    if (id === "content" && dataPidDescendants > 0) return 70;
    if (tokens.has("jwac") && dataPidDescendants > 0) return 60;
    return 0;
  }
  function articleRoots(root = document) {
    const ranked = queryWithinRoots(ARTICLE_ROOT_SELECTORS, [root]).map((el) => ({
      el,
      priority: articleRootPriority({
        tagName: el.tagName,
        id: el.id,
        className: el.className,
        dataPidDescendants: el.querySelectorAll("[data-pid]").length
      })
    })).filter((entry) => entry.priority > 0);
    const topPriority = Math.max(0, ...ranked.map((entry) => entry.priority));
    return ranked.filter((entry) => entry.priority === topPriority).map((entry) => entry.el);
  }
  function mediaSurfaceNodes(root = document) {
    return uniqueElements(queryWithinRoots(MEDIA_SURFACE_SELECTORS, [root]));
  }
  function detectSupport(probe) {
    if (probe.pageNotFound) {
      return {
        supported: false,
        palette: false,
        article: false,
        language: false,
        media: false
      };
    }
    const hostname = probe.hostname.toLowerCase();
    const pathname = probe.pathname;
    const isWol = hostname === "wol.jw.org";
    const isStream = hostname === "stream.jw.org";
    const isJw = /(^|\.)jw\.org$/.test(hostname) && !isWol && !isStream;
    const isLibrary = isJwLibraryPath(pathname);
    const decodedSegments = (() => {
      try {
        return decodeURIComponent(pathname).split("/").filter(Boolean);
      } catch {
        return pathname.split("/").filter(Boolean);
      }
    })();
    const isJwArticlePath = isJw && decodedSegments.length >= 3 && !JW_NON_ARTICLE_PATH_RE.test(pathname);
    const palette = Boolean(
      isJw && (isLibrary || JW_SEARCH_PATH_RE.test(pathname)) || isWol && WOL_PATH_RE.test(pathname) || isStream && probe.mediaRootCount > 0
    );
    const article = Boolean(
      probe.articleRootCount > 0 && (isJw && (isLibrary || isJwArticlePath) || isWol && WOL_PATH_RE.test(pathname))
    );
    const language = article && isJw;
    const media = Boolean(
      probe.mediaRootCount > 0 && (isStream || isJw && (isLibrary || isJwArticlePath) || isWol && WOL_PATH_RE.test(pathname))
    );
    return {
      supported: palette || article || media,
      palette,
      article,
      language,
      media
    };
  }
  function currentSupport(root = document) {
    const roots = articleRoots(root);
    const mediaNodes = mediaSurfaceNodes(root);
    const state = detectSupport({
      hostname: location.hostname,
      pathname: location.pathname,
      articleRootCount: roots.length,
      mediaRootCount: mediaNodes.length,
      pageNotFound: !!root.querySelector(".PageNotFound")
    });
    return { ...state, articleRoots: roots, mediaNodes };
  }
  function candidateParagraphRoots(roots) {
    if (!roots.length) return [];
    return [...new Set(roots)];
  }
  function isEligibleParagraphShape(shape) {
    const tagName = String(shape.tagName || "").toUpperCase();
    const tokens = classTokens(shape.className);
    const hasDataVerse = !!shape.hasDataVerse;
    const hasVerseClass = tokens.has("verse");
    if (hasDataVerse || hasVerseClass) return VERSE_TAGS.has(tagName);
    if (shape.hasDataPid) return PARAGRAPH_TAGS.has(tagName);
    return PARAGRAPH_TAGS.has(tagName);
  }
  function paragraphNodes(roots) {
    const sels = [
      "p[data-pid]",
      "[data-verse]",
      ".verse",
      '[class~="verse"]',
      'p[id^="p"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    for (const root of candidateParagraphRoots(roots)) {
      for (const sel of sels) {
        for (const el of qsa(sel, root)) {
          if (seen.has(el)) continue;
          if (!isEligibleParagraphShape({
            tagName: el.tagName,
            className: el.className,
            hasDataPid: el.hasAttribute("data-pid"),
            hasDataVerse: el.hasAttribute("data-verse")
          })) continue;
          const text = normalizeStudyNavText(el.innerText || el.textContent || "");
          if (text.length < 2) continue;
          if (el.closest(".studynav-para-tools, .studynav-palette, [data-studynav-owned], script, style, nav, header")) continue;
          seen.add(el);
        }
      }
    }
    return [...seen];
  }
  function normalizeStudyNavText(text) {
    return text.replace(/\u00a0/g, " ").split("\n").map((line) => line.replace(/[ \t]+/g, " ").trim()).filter(Boolean).join("\n").trim();
  }
  function textForCopy(el) {
    const clone = el.cloneNode(true);
    clone.querySelectorAll([
      "[data-studynav-owned]",
      '[class^="studynav-"]',
      '[class*=" studynav-"]',
      '[id^="studynav-"]',
      ".verseNum",
      ".chapterNum",
      "a.xrefLink",
      "a.footnoteLink",
      'a[href="#xref"]',
      'a[href="#footnote"]'
    ].join(",")).forEach((node) => {
      node.remove();
    });
    return normalizeStudyNavText(clone.innerText || clone.textContent || "");
  }
  function sanitizeAnchorPart(value) {
    return value.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64);
  }
  function buildOwnedAnchorId(dataPid, dataVerse) {
    const pid = sanitizeAnchorPart(dataPid || "");
    if (pid) return `studynav-pid-${pid}`;
    const verse = sanitizeAnchorPart(dataVerse || "");
    if (verse) return `studynav-verse-${verse}`;
    return null;
  }
  function ensureAnchorId(el) {
    if (el.id) return el.id;
    const ancestor = el.parentElement?.closest("[id]");
    if (ancestor && !articleRoots(document).includes(ancestor)) return ancestor.id;
    const base = buildOwnedAnchorId(el.getAttribute("data-pid"), el.getAttribute("data-verse"));
    if (!base) return null;
    let next = base;
    let index = 2;
    while (true) {
      const existing = document.getElementById(next);
      if (!existing || existing === el) break;
      next = `${base}-${index++}`;
    }
    el.id = next;
    el.dataset.snOwnedAnchor = "1";
    return next;
  }
  function deepestLinkFor(el) {
    const id = ensureAnchorId(el);
    if (!id) return location.href;
    const u = new URL(location.href);
    u.hash = id;
    return u.toString();
  }

  // packages/studynav/src/media-progress-runtime.ts
  var MEDIA_PROGRESS_SAVE_INTERVAL_MS = 5e3;
  var RESUME_BUTTON_ID = "studynav-resume-media";
  var enabled = false;
  var trackedVideos = [];
  var listeners = /* @__PURE__ */ new Map();
  var toolbar = null;
  var runtimePageUrl = "";
  var refreshGeneration = 0;
  var storageListening = false;
  var globalListening = false;
  var pruneStarted = false;
  function shouldSaveTimedProgress(lastSavedAt, now) {
    return Number.isFinite(now) && now >= lastSavedAt + MEDIA_PROGRESS_SAVE_INTERVAL_MS;
  }
  function formatMediaTime(seconds) {
    const total = Math.max(0, Math.floor(Number.isFinite(seconds) ? seconds : 0));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor(total % 3600 / 60);
    const remaining = total % 60;
    return hours ? `${hours}:${String(minutes).padStart(2, "0")}:${String(remaining).padStart(2, "0")}` : `${minutes}:${String(remaining).padStart(2, "0")}`;
  }
  function normalizeMediaSourceIdentity(candidates, stableElementId, index, baseUrl) {
    for (const candidate of candidates) {
      const value = candidate.trim();
      if (!value || value.startsWith("blob:") || value.startsWith("data:")) continue;
      try {
        const url = new URL(value, baseUrl);
        if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) continue;
        url.hash = "";
        return url.href;
      } catch {
      }
    }
    const stable = cleanCitationText(stableElementId).slice(0, 256);
    return stable ? `element:${stable}` : `dom-video:${Math.max(0, index)}`;
  }
  function currentPageUrl() {
    const canonical = qs('link[rel="canonical"][href]')?.href || null;
    return canonicalStudyUrl(location.href, canonical);
  }
  function pageTitle() {
    const heading = qs("#article h1, article h1, main h1, h1");
    return cleanCitationText(heading?.innerText || heading?.textContent || document.title || "JW.ORG").slice(0, 512);
  }
  function sourceForVideo(video) {
    const index = Math.max(0, trackedVideos.indexOf(video));
    const childSource = video.querySelector("source[src]");
    const stableId = video.id || video.dataset.videoId || video.dataset.mediaId || video.getAttribute("data-media-id") || "";
    return normalizeMediaSourceIdentity([
      video.getAttribute("src") || "",
      childSource?.getAttribute("src") || "",
      video.src,
      childSource?.src || "",
      video.currentSrc
    ], stableId, index, location.href);
  }
  function progressIdForVideo(video) {
    const pageUrl = currentPageUrl();
    return pageUrl ? createMediaProgressId(pageUrl, sourceForVideo(video)) : null;
  }
  function recordForVideo(video, now) {
    const pageUrl = currentPageUrl();
    if (!pageUrl || video.ended) return null;
    return createMediaProgressRecord(
      pageUrl,
      sourceForVideo(video),
      pageTitle(),
      video.currentTime,
      video.duration,
      now
    );
  }
  function reportStorageFailure(error) {
    console.warn("StudyNav media progress", error);
    toast(error instanceof Error ? error.message : t("video_progress_save_failed"));
  }
  async function persistVideo(video) {
    if (!enabled || !trackedVideos.includes(video)) return;
    const now = Date.now();
    const id = progressIdForVideo(video);
    const record = recordForVideo(video, now);
    try {
      await mutateStudyData((current) => ({
        ...current,
        mediaProgress: record ? upsertMediaProgress(current.mediaProgress, record, now) : pruneMediaProgress(current.mediaProgress, now).filter((item) => item.id !== id)
      }));
    } catch (error) {
      reportStorageFailure(error);
    }
  }
  function persistAllTracked() {
    for (const video of trackedVideos) void persistVideo(video);
  }
  var visibilityHandler = () => {
    if (document.visibilityState === "hidden") persistAllTracked();
  };
  var pageHideHandler = () => persistAllTracked();
  function activeTrackedVideo() {
    return trackedVideos.find((video) => !video.paused && !video.ended) || trackedVideos[0] || null;
  }
  function removeResumeButton() {
    document.getElementById(RESUME_BUTTON_ID)?.remove();
  }
  function seekWithoutAutoplay(video, record) {
    const upperBound = Number.isFinite(video.duration) ? Math.max(0, video.duration - 5) : record.duration - 5;
    const target = Math.max(0, Math.min(record.currentTime, upperBound));
    try {
      video.currentTime = target;
      toast(t("ready_at", formatMediaTime(target)));
    } catch {
      toast(t("resume_wait_loading"));
    }
  }
  async function refreshResumeControl() {
    const generation = ++refreshGeneration;
    if (!enabled || !toolbar?.isConnected) {
      removeResumeButton();
      return;
    }
    const video = activeTrackedVideo();
    const id = video ? progressIdForVideo(video) : null;
    if (!video || !id) {
      removeResumeButton();
      return;
    }
    try {
      const data = await loadStudyData();
      if (!enabled || generation !== refreshGeneration || !toolbar?.isConnected) return;
      const record = pruneMediaProgress(data.mediaProgress, Date.now()).find((item) => item.id === id);
      if (!record) {
        removeResumeButton();
        return;
      }
      let button = document.getElementById(RESUME_BUTTON_ID);
      if (!button) {
        button = document.createElement("button");
        button.id = RESUME_BUTTON_ID;
        button.type = "button";
        toolbar.prepend(button);
      }
      button.textContent = t("resume_at", formatMediaTime(record.currentTime));
      button.title = t("resume_title");
      button.onclick = () => seekWithoutAutoplay(video, record);
    } catch (error) {
      reportStorageFailure(error);
    }
  }
  function removeVideo(video) {
    const entry = listeners.get(video);
    if (!entry) return;
    video.removeEventListener("timeupdate", entry.onTimeUpdate);
    video.removeEventListener("pause", entry.onPause);
    video.removeEventListener("ended", entry.onEnded);
    listeners.delete(video);
  }
  function addVideo(video) {
    if (listeners.has(video)) return;
    const entry = {
      lastTimedSave: 0,
      onTimeUpdate: () => {
        const now = Date.now();
        if (!shouldSaveTimedProgress(entry.lastTimedSave, now)) return;
        entry.lastTimedSave = now;
        void persistVideo(video);
      },
      onPause: () => void persistVideo(video),
      onEnded: () => void persistVideo(video)
    };
    listeners.set(video, entry);
    video.addEventListener("timeupdate", entry.onTimeUpdate);
    video.addEventListener("pause", entry.onPause);
    video.addEventListener("ended", entry.onEnded);
  }
  var storageChangeHandler = (changes, areaName) => {
    if (enabled && studyDataChanged(changes, areaName)) void refreshResumeControl();
  };
  async function pruneStoredProgressOnce() {
    if (pruneStarted) return;
    pruneStarted = true;
    const now = Date.now();
    try {
      await mutateStudyData((current) => ({
        ...current,
        mediaProgress: pruneMediaProgress(current.mediaProgress, now)
      }));
    } catch (error) {
      reportStorageFailure(error);
    }
  }
  function applyContinueWatching(videos, nextToolbar) {
    const nextPageUrl = currentPageUrl() || "";
    if (runtimePageUrl !== nextPageUrl) {
      runtimePageUrl = nextPageUrl;
      for (const entry of listeners.values()) entry.lastTimedSave = 0;
    }
    enabled = true;
    toolbar = nextToolbar;
    const connected = [...new Set(videos.filter((video) => video.isConnected))];
    for (const video of trackedVideos) {
      if (!connected.includes(video)) removeVideo(video);
    }
    trackedVideos = connected;
    for (const video of trackedVideos) addVideo(video);
    if (!globalListening) {
      globalListening = true;
      document.addEventListener("visibilitychange", visibilityHandler, true);
      window.addEventListener("pagehide", pageHideHandler, true);
    }
    if (!storageListening) {
      storageListening = true;
      chrome.storage.onChanged.addListener(storageChangeHandler);
    }
    void pruneStoredProgressOnce();
    void refreshResumeControl();
  }
  function teardownContinueWatching() {
    enabled = false;
    refreshGeneration += 1;
    for (const video of [...listeners.keys()]) removeVideo(video);
    trackedVideos = [];
    toolbar = null;
    runtimePageUrl = "";
    pruneStarted = false;
    removeResumeButton();
    if (globalListening) {
      globalListening = false;
      document.removeEventListener("visibilitychange", visibilityHandler, true);
      window.removeEventListener("pagehide", pageHideHandler, true);
    }
    if (storageListening) {
      storageListening = false;
      chrome.storage.onChanged.removeListener(storageChangeHandler);
    }
  }
  function continueWatchingStatus() {
    const active = activeTrackedVideo();
    return {
      enabled,
      trackedVideoCount: trackedVideos.length,
      listenerCount: listeners.size,
      resumeAvailable: !!document.getElementById(RESUME_BUTTON_ID),
      activeRecordValid: !!active && !!recordForVideo(active, Date.now()),
      activeSnapshot: active ? {
        currentTime: active.currentTime,
        duration: active.duration,
        ended: active.ended,
        source: sourceForVideo(active),
        pageUrl: currentPageUrl()
      } : null
    };
  }

  // packages/studynav/src/study-dom.ts
  var EXCLUDED_TEXT_SELECTOR = [
    "[data-studynav-owned]",
    ".studynav-para-tools",
    "script",
    "style",
    "noscript",
    "template"
  ].join(",");
  function rootReferenceForElement(element) {
    if (element.id) return { id: element.id };
    const dataPid = element.getAttribute("data-pid");
    if (dataPid) return { dataPid };
    const dataVerse = element.getAttribute("data-verse");
    if (dataVerse) return { dataVerse };
    return null;
  }
  function cleanTextSnapshot(element) {
    const root = rootReferenceForElement(element);
    if (!root) return null;
    const segments = [];
    let text = "";
    const walker = element.ownerDocument.createTreeWalker(element, NodeFilter.SHOW_TEXT, {
      acceptNode(node2) {
        const parent = node2.parentElement;
        if (!parent || !node2.nodeValue) return NodeFilter.FILTER_REJECT;
        const excluded = parent.closest(EXCLUDED_TEXT_SELECTOR);
        if (excluded && element.contains(excluded)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let node;
    while (node = walker.nextNode()) {
      const value = node.nodeValue || "";
      if (!value) continue;
      const start = text.length;
      text += value;
      segments.push({ node, start, end: text.length });
    }
    return { element, root, text, segments };
  }
  function boundaryOffset(snapshot, container, offset) {
    if (container.nodeType !== Node.TEXT_NODE) return null;
    const segment = snapshot.segments.find((item) => item.node === container);
    if (!segment || offset < 0 || offset > segment.node.data.length) return null;
    return segment.start + offset;
  }
  function offsetsForRange(snapshot, range) {
    const start = boundaryOffset(snapshot, range.startContainer, range.startOffset);
    const end = boundaryOffset(snapshot, range.endContainer, range.endOffset);
    return start != null && end != null && start < end ? { start, end } : null;
  }
  function pointForOffset(snapshot, offset, preferNext) {
    if (offset < 0 || offset > snapshot.text.length) return null;
    for (let index = 0; index < snapshot.segments.length; index += 1) {
      const segment = snapshot.segments[index];
      if (offset < segment.end || !preferNext && offset === segment.end) {
        return { node: segment.node, offset: offset - segment.start };
      }
      if (preferNext && offset === segment.end && snapshot.segments[index + 1]) {
        return { node: snapshot.segments[index + 1].node, offset: 0 };
      }
    }
    const last = snapshot.segments.at(-1);
    return last && offset === snapshot.text.length ? { node: last.node, offset: last.node.data.length } : null;
  }
  function rangeForOffsets(snapshot, start, end) {
    if (start < 0 || end <= start || end > snapshot.text.length) return null;
    const startPoint = pointForOffset(snapshot, start, true);
    const endPoint = pointForOffset(snapshot, end, false);
    if (!startPoint || !endPoint) return null;
    const range = snapshot.element.ownerDocument.createRange();
    try {
      range.setStart(startPoint.node, startPoint.offset);
      range.setEnd(endPoint.node, endPoint.offset);
      return range;
    } catch {
      range.detach?.();
      return null;
    }
  }
  function selectorForRange(element, range) {
    const snapshot = cleanTextSnapshot(element);
    if (!snapshot) return null;
    const offsets = offsetsForRange(snapshot, range);
    if (!offsets) return null;
    const selector = createTextSelector(snapshot.text, offsets.start, offsets.end);
    return selector ? { root: snapshot.root, selector } : null;
  }
  function selectorForWholeElement(element) {
    const snapshot = cleanTextSnapshot(element);
    if (!snapshot || !snapshot.text.trim()) return null;
    const firstContent = snapshot.text.search(/\S/u);
    const trailing = snapshot.text.match(/\s*$/u)?.[0].length || 0;
    const end = snapshot.text.length - trailing;
    if (firstContent < 0 || end <= firstContent) return null;
    const selector = createTextSelector(snapshot.text, firstContent, end);
    const range = rangeForOffsets(snapshot, firstContent, end);
    return selector && range ? { root: snapshot.root, selector, range } : null;
  }
  function resolveAnnotationInDom(annotation, roots) {
    const snapshots = roots.map(cleanTextSnapshot).filter((value) => !!value);
    const saved = snapshots.find((snapshot2) => rootReferenceKey(snapshot2.root) === rootReferenceKey(annotation.root));
    const resolution = resolveTextSelector(
      annotation.selector,
      annotation.root,
      saved?.text,
      snapshots.map(({ root, text }) => ({ root, text }))
    );
    if (!resolution) return null;
    const snapshot = snapshots.find((candidate) => rootReferenceKey(candidate.root) === rootReferenceKey(resolution.root));
    if (!snapshot) return null;
    const range = rangeForOffsets(snapshot, resolution.start, resolution.end);
    if (!range) return null;
    const selector = createTextSelector(snapshot.text, resolution.start, resolution.end);
    return selector ? { element: snapshot.element, range, resolution, selector } : null;
  }

  // packages/studynav/src/study-runtime.ts
  var SELECTION_TOOLS_ID = "studynav-selection-tools";
  var EDITOR_ID = "studynav-note-editor";
  var PANEL_ID = "studynav-study-panel";
  var NOTE_RAIL_ID = "studynav-note-rail";
  var HIGHLIGHT_PREFIX = "studynav-";
  var enabled2 = false;
  var annotationsEnabled = false;
  var bookmarksEnabled = false;
  var articleRoots2 = [];
  var currentCandidate = null;
  var pendingReattachId = null;
  var selectionTimer = null;
  var renderGeneration = 0;
  var storageListening2 = false;
  var railResizeListening = false;
  var panelScope = "page";
  var panelView = "notes";
  var panelReturnFocus = null;
  var editorReturnFocus = null;
  var unresolvedIds = /* @__PURE__ */ new Set();
  var resolvedElements = /* @__PURE__ */ new Map();
  var lastSelectionError = "";
  function registry() {
    if (typeof CSS === "undefined") return null;
    return CSS.highlights || null;
  }
  function highlightConstructor() {
    return globalThis.Highlight || null;
  }
  function clearHighlightRegistry() {
    const highlights = registry();
    if (!highlights) return;
    for (const color of HIGHLIGHT_COLORS) highlights.delete(`${HIGHLIGHT_PREFIX}${color}`);
  }
  function currentPageUrl2() {
    const canonical = qs('link[rel="canonical"][href]')?.href || null;
    return canonicalStudyUrl(location.href, canonical);
  }
  function currentPageTitle() {
    const heading = qs("#article h1, article h1, main h1, h1");
    return cleanCitationText(heading?.innerText || heading?.textContent || document.title || "JW.ORG").slice(0, 512);
  }
  function bookmarkForCandidate(candidate, now) {
    const id = createBookmarkId(candidate.targetUrl);
    if (!id) return null;
    return createBookmarkRecord({
      id,
      pageUrl: candidate.pageUrl,
      targetUrl: candidate.targetUrl,
      title: candidate.title,
      reference: candidate.reference,
      createdAt: now,
      updatedAt: now
    });
  }
  async function isStudyBookmarkSaved(targetUrl) {
    const normalized = normalizeStudyTargetUrl(targetUrl);
    if (!normalized) return false;
    const data = await loadStudyData();
    return data.bookmarks.some((bookmark) => bookmark.targetUrl === normalized);
  }
  async function toggleStudyBookmark(candidate) {
    if (!enabled2 || !bookmarksEnabled) {
      return { ok: false, message: t("bookmarks_off"), saved: false };
    }
    let saved = false;
    try {
      await mutateStudyData((current) => {
        const normalized = normalizeStudyTargetUrl(candidate.targetUrl);
        if (!normalized) throw new Error(t("not_available_page"));
        const existing = current.bookmarks.find((bookmark) => bookmark.targetUrl === normalized);
        if (existing) {
          saved = false;
          return {
            ...current,
            bookmarks: current.bookmarks.filter((bookmark) => bookmark.id !== existing.id)
          };
        }
        if (current.bookmarks.length >= MAX_BOOKMARKS) throw new Error(t("bookmark_limit"));
        const record = bookmarkForCandidate(candidate, Date.now());
        if (!record) throw new Error(t("not_available_page"));
        saved = true;
        return { ...current, bookmarks: [record, ...current.bookmarks] };
      });
      return {
        ok: true,
        message: t(saved ? "place_saved" : "saved_place_removed"),
        saved
      };
    } catch (error) {
      storageFailure(error);
      return {
        ok: false,
        message: error instanceof Error ? error.message : t("study_data_save_failed"),
        saved: false
      };
    }
  }
  function activeParagraphRoots() {
    articleRoots2 = articleRoots2.filter((root) => root.isConnected);
    return paragraphNodes(articleRoots2);
  }
  function nextId() {
    if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
    return `sn-${Date.now()}-${Math.random().toString(36).slice(2, 14)}`;
  }
  function storageFailure(error) {
    console.warn("StudyNav study data", error);
    toast(error instanceof Error ? error.message : t("study_data_save_failed"));
  }
  function annotationWithTarget(candidate, color, note, tags, existing) {
    const pageUrl = existing?.pageUrl || currentPageUrl2();
    if (!pageUrl) return null;
    const now = Date.now();
    return validateAnnotation({
      id: existing?.id || nextId(),
      pageUrl,
      title: existing ? existing.title : currentPageTitle(),
      root: candidate.root,
      selector: candidate.selector,
      color,
      note,
      tags,
      createdAt: existing?.createdAt || now,
      updatedAt: existing ? Math.max(now, existing.updatedAt + 1) : now
    });
  }
  async function storeAnnotation(record) {
    await mutateStudyData((current) => {
      const index = current.annotations.findIndex((item) => item.id === record.id);
      const annotations = [...current.annotations];
      if (index >= 0) annotations[index] = record;
      else {
        if (annotations.length >= MAX_ANNOTATIONS) throw new Error(t("annotation_limit"));
        annotations.push(record);
      }
      return { ...current, annotations };
    });
  }
  async function saveCandidate(candidate, color, note, tags, existing) {
    const record = annotationWithTarget(candidate, color, note, tags, existing);
    if (!record) {
      toast(t("selection_cannot_save"));
      return false;
    }
    try {
      await storeAnnotation(record);
      pendingReattachId = null;
      window.getSelection()?.removeAllRanges();
      hideSelectionTools();
      toast(existing ? t("note_updated") : t("highlight_saved"));
      return true;
    } catch (error) {
      storageFailure(error);
      return false;
    }
  }
  function selectionRoot(range) {
    return activeParagraphRoots().find((root) => root.contains(range.startContainer) && root.contains(range.endContainer)) || null;
  }
  function candidateFromSelection() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || selection.rangeCount !== 1) return null;
    const range = selection.getRangeAt(0);
    const root = selectionRoot(range);
    if (!root) return null;
    const target = selectorForRange(root, range);
    if (!target || !target.selector.exact.trim()) return null;
    return { ...target, range: range.cloneRange() };
  }
  function selectionError() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || selection.rangeCount !== 1) return "";
    const range = selection.getRangeAt(0);
    const roots = activeParagraphRoots();
    const startRoot = roots.find((root) => root.contains(range.startContainer));
    const endRoot = roots.find((root) => root.contains(range.endContainer));
    if (startRoot && endRoot && startRoot !== endRoot) {
      return t("select_one_paragraph");
    }
    if (startRoot && startRoot === endRoot) {
      return t("select_character_count", MAX_TEXT_LENGTH.toLocaleString());
    }
    return "";
  }
  function hideSelectionTools() {
    document.getElementById(SELECTION_TOOLS_ID)?.remove();
    currentCandidate = null;
  }
  function preserveSelectionOnPointerDown(button) {
    button.addEventListener("pointerdown", (event) => event.preventDefault());
    button.addEventListener("mousedown", (event) => event.preventDefault());
  }
  function colorButton(color, onClick) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "studynav-color-button";
    button.dataset.color = color;
    const localizedColor = t(`color_${color}`);
    button.setAttribute("aria-label", t("highlight_color_aria", localizedColor));
    button.title = t("highlight_color_aria", localizedColor);
    preserveSelectionOnPointerDown(button);
    button.addEventListener("click", onClick);
    return button;
  }
  function positionSelectionTools(tools, range) {
    const rect = range.getBoundingClientRect();
    const fallback = selectionRoot(range)?.getBoundingClientRect();
    const anchor = rect.width || rect.height ? rect : fallback;
    if (!anchor) return;
    const width = tools.offsetWidth || 260;
    const left = Math.max(8, Math.min(window.innerWidth - width - 8, anchor.left + anchor.width / 2 - width / 2));
    const top = Math.max(8, anchor.top - (tools.offsetHeight || 44) - 8);
    tools.style.left = `${left}px`;
    tools.style.top = `${top}px`;
  }
  async function commitPendingReattach(candidate) {
    if (!pendingReattachId) return;
    try {
      const data = await loadStudyData();
      const existing = data.annotations.find((item) => item.id === pendingReattachId);
      if (!existing) {
        pendingReattachId = null;
        toast(t("note_missing"));
        return;
      }
      if (existing.pageUrl !== currentPageUrl2()) {
        pendingReattachId = null;
        hideSelectionTools();
        toast(t("reattach_source_first"));
        return;
      }
      await saveCandidate(candidate, existing.color, existing.note, existing.tags, existing);
    } catch (error) {
      storageFailure(error);
    }
  }
  function showSelectionTools(candidate) {
    hideSelectionTools();
    currentCandidate = candidate;
    const tools = document.createElement("div");
    tools.id = SELECTION_TOOLS_ID;
    tools.className = "studynav-selection-tools";
    tools.setAttribute("data-studynav-owned", "1");
    tools.setAttribute("role", "toolbar");
    tools.setAttribute("aria-label", t(pendingReattachId ? "reattach_note_aria" : "highlight_selection_aria"));
    if (pendingReattachId) {
      const reattach = document.createElement("button");
      reattach.type = "button";
      reattach.textContent = t("reattach_here");
      preserveSelectionOnPointerDown(reattach);
      reattach.addEventListener("click", () => void commitPendingReattach(candidate));
      const cancel = document.createElement("button");
      cancel.type = "button";
      cancel.className = "studynav-secondary-button";
      cancel.textContent = t("cancel");
      preserveSelectionOnPointerDown(cancel);
      cancel.addEventListener("click", () => {
        pendingReattachId = null;
        hideSelectionTools();
        toast(t("reattach_cancelled"));
      });
      tools.append(reattach, cancel);
    } else {
      for (const color of HIGHLIGHT_COLORS) {
        tools.appendChild(colorButton(color, () => void saveCandidate(candidate, color, "", [])));
      }
      const note = document.createElement("button");
      note.type = "button";
      note.textContent = t("add_note");
      preserveSelectionOnPointerDown(note);
      note.addEventListener("click", () => openAnnotationEditor(candidate));
      tools.appendChild(note);
    }
    document.documentElement.appendChild(tools);
    positionSelectionTools(tools, candidate.range);
  }
  function updateSelectionTools() {
    if (!enabled2 || !annotationsEnabled || document.getElementById(EDITOR_ID)) return;
    const candidate = candidateFromSelection();
    if (!candidate) {
      hideSelectionTools();
      const message = selectionError();
      if (message && message !== lastSelectionError) toast(message);
      lastSelectionError = message;
      return;
    }
    lastSelectionError = "";
    showSelectionTools(candidate);
  }
  var selectionChangeHandler = () => {
    if (selectionTimer != null) window.clearTimeout(selectionTimer);
    selectionTimer = window.setTimeout(() => {
      selectionTimer = null;
      updateSelectionTools();
    }, 0);
  };
  function closeEditor() {
    document.getElementById(EDITOR_ID)?.remove();
    window.removeEventListener("keydown", editorEscapeHandler, true);
    if (editorReturnFocus?.isConnected) editorReturnFocus.focus();
    editorReturnFocus = null;
  }
  function editorEscapeHandler(event) {
    if (event.key === "Escape" && document.getElementById(EDITOR_ID)) {
      event.preventDefault();
      closeEditor();
    }
  }
  function openAnnotationEditor(candidate, existing) {
    if (!candidate && !existing) return;
    closeEditor();
    hideSelectionTools();
    editorReturnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const overlay = document.createElement("div");
    overlay.id = EDITOR_ID;
    overlay.className = "studynav-overlay";
    overlay.setAttribute("data-studynav-owned", "1");
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-labelledby", "studynav-editor-title");
    const form = document.createElement("form");
    form.className = "studynav-overlay-panel studynav-editor-panel";
    const head = document.createElement("div");
    head.className = "studynav-panel-head";
    const title = document.createElement("strong");
    title.id = "studynav-editor-title";
    title.textContent = t(existing ? "edit_highlight" : "new_highlight");
    const close = document.createElement("button");
    close.type = "button";
    close.className = "studynav-icon-button";
    close.textContent = t("close");
    close.setAttribute("aria-label", t("close_highlight_editor_aria"));
    close.addEventListener("click", closeEditor);
    head.append(title, close);
    const colors = document.createElement("fieldset");
    colors.className = "studynav-color-fieldset";
    const legend = document.createElement("legend");
    legend.textContent = t("highlight_color");
    colors.appendChild(legend);
    for (const color of HIGHLIGHT_COLORS) {
      const label = document.createElement("label");
      label.className = "studynav-color-choice";
      const input = document.createElement("input");
      input.type = "radio";
      input.name = "color";
      input.value = color;
      input.checked = color === (existing?.color || "yellow");
      const swatch = document.createElement("span");
      swatch.dataset.color = color;
      const text = document.createElement("span");
      text.textContent = t(`color_${color}`);
      label.append(input, swatch, text);
      colors.appendChild(label);
    }
    const noteLabel = document.createElement("label");
    noteLabel.className = "studynav-field";
    noteLabel.textContent = t("note");
    const note = document.createElement("textarea");
    note.id = "studynav-note-text";
    note.rows = 5;
    note.maxLength = 2e4;
    note.placeholder = t("write_private_note");
    note.value = existing?.note || "";
    noteLabel.appendChild(note);
    const tagsLabel = document.createElement("label");
    tagsLabel.className = "studynav-field";
    tagsLabel.textContent = t("tags");
    const tags = document.createElement("input");
    tags.id = "studynav-note-tags";
    tags.type = "text";
    tags.placeholder = t("tags_placeholder");
    tags.value = existing?.tags.join(", ") || "";
    tagsLabel.appendChild(tags);
    const error = document.createElement("p");
    error.className = "studynav-form-error";
    error.setAttribute("aria-live", "polite");
    const actions = document.createElement("div");
    actions.className = "studynav-panel-actions";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "studynav-secondary-button";
    cancel.textContent = t("cancel");
    cancel.addEventListener("click", closeEditor);
    const save = document.createElement("button");
    save.type = "submit";
    save.textContent = t("save_locally");
    actions.append(cancel, save);
    form.append(head, colors, noteLabel, tagsLabel, error, actions);
    overlay.appendChild(form);
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) closeEditor();
    });
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const normalizedTags = normalizeTags(tags.value);
      const color = new FormData(form).get("color");
      if (!normalizedTags || !HIGHLIGHT_COLORS.includes(color)) {
        error.textContent = t("tags_error");
        return;
      }
      const activeTarget = candidate || (existing ? {
        root: existing.root,
        selector: existing.selector,
        range: document.createRange()
      } : null);
      if (!activeTarget) return;
      save.disabled = true;
      const saved = await saveCandidate(activeTarget, color, note.value, normalizedTags, existing);
      save.disabled = false;
      if (saved) {
        closeEditor();
        void renderStudyState();
      }
    });
    document.documentElement.appendChild(overlay);
    window.addEventListener("keydown", editorEscapeHandler, true);
    note.focus();
  }
  function openAnnotationEditorForElement(element) {
    if (!enabled2 || !annotationsEnabled) return false;
    const target = selectorForWholeElement(element);
    if (!target) {
      toast(t("paragraph_mark_unreliable"));
      return false;
    }
    openAnnotationEditor({ root: target.root, selector: target.selector, range: target.range });
    return true;
  }
  async function persistRecoveredTargets(recovered) {
    if (!recovered.length) return;
    await mutateStudyData((current) => {
      const byId = new Map(recovered.map((record) => [record.id, record]));
      return {
        ...current,
        annotations: current.annotations.map((record) => {
          const candidate = byId.get(record.id);
          return candidate && candidate.updatedAt > record.updatedAt ? candidate : record;
        })
      };
    });
  }
  async function renderStudyState(dataValue) {
    const generation = ++renderGeneration;
    if (!enabled2) return;
    try {
      const data = dataValue || await loadStudyData();
      if (!enabled2 || generation !== renderGeneration) return;
      const pageUrl = currentPageUrl2();
      const roots = activeParagraphRoots();
      const rangesByColor = new Map(HIGHLIGHT_COLORS.map((color) => [color, []]));
      const nextUnresolved = /* @__PURE__ */ new Set();
      const nextElements = /* @__PURE__ */ new Map();
      const recovered = [];
      for (const annotation of annotationsEnabled ? data.annotations.filter((item) => item.pageUrl === pageUrl) : []) {
        const dom = resolveAnnotationInDom(annotation, roots);
        if (!dom) {
          nextUnresolved.add(annotation.id);
          continue;
        }
        rangesByColor.get(annotation.color)?.push(dom.range);
        nextElements.set(annotation.id, dom.element);
        if (dom.resolution.recovered) {
          recovered.push({
            ...annotation,
            root: dom.resolution.root,
            selector: dom.selector,
            updatedAt: Math.max(Date.now(), annotation.updatedAt + 1)
          });
        }
      }
      clearHighlightRegistry();
      const highlights = registry();
      const HighlightCtor = highlightConstructor();
      if (highlights && HighlightCtor) {
        for (const color of HIGHLIGHT_COLORS) {
          const ranges = rangesByColor.get(color) || [];
          if (ranges.length) highlights.set(`${HIGHLIGHT_PREFIX}${color}`, new HighlightCtor(...ranges));
        }
      }
      unresolvedIds = nextUnresolved;
      resolvedElements = nextElements;
      renderPageNoteRail(data);
      if (document.getElementById(PANEL_ID)) await renderStudyPanel(data);
      if (recovered.length) await persistRecoveredTargets(recovered);
    } catch (error) {
      storageFailure(error);
    }
  }
  function positionPageNoteRail() {
    const rail = document.getElementById(NOTE_RAIL_ID);
    if (!rail) return;
    const rightEdge = Math.max(0, ...activeParagraphRoots().map((root) => root.getBoundingClientRect().right));
    const fitsWithoutTextOverlap = window.innerWidth >= 980 && window.innerWidth - rightEdge >= 356;
    rail.dataset.mode = fitsWithoutTextOverlap ? "rail" : "button";
  }
  function renderPageNoteRail(data) {
    const pageUrl = currentPageUrl2();
    const notes = annotationsEnabled ? data.annotations.filter((annotation) => annotation.pageUrl === pageUrl && !!annotation.note.trim()).sort((a, b) => b.updatedAt - a.updatedAt) : [];
    if (!notes.length) {
      document.getElementById(NOTE_RAIL_ID)?.remove();
      return;
    }
    let rail = document.getElementById(NOTE_RAIL_ID);
    if (!rail) {
      rail = document.createElement("aside");
      rail.id = NOTE_RAIL_ID;
      rail.className = "studynav-note-rail";
      rail.setAttribute("data-studynav-owned", "1");
      rail.setAttribute("aria-label", t("page_notes"));
      document.documentElement.appendChild(rail);
    }
    rail.replaceChildren();
    const open = panelButton(t("page_notes"), () => {
      void openStudyPanel();
    });
    open.className = "studynav-note-rail-open";
    const count = document.createElement("span");
    count.textContent = String(notes.length);
    open.appendChild(count);
    rail.appendChild(open);
    const list = document.createElement("div");
    list.className = "studynav-note-rail-list";
    for (const annotation of notes.slice(0, 12)) {
      const item = document.createElement("button");
      item.type = "button";
      item.className = "studynav-note-rail-item";
      item.addEventListener("click", () => openAnnotationSource(annotation));
      const swatch = document.createElement("span");
      swatch.className = "studynav-note-swatch";
      swatch.dataset.color = annotation.color;
      const copy2 = document.createElement("span");
      const quote = document.createElement("strong");
      quote.textContent = annotation.selector.exact;
      const note = document.createElement("span");
      note.textContent = annotation.note;
      copy2.append(quote, note);
      item.append(swatch, copy2);
      list.appendChild(item);
    }
    rail.appendChild(list);
    positionPageNoteRail();
  }
  function closeStudyPanel() {
    document.getElementById(PANEL_ID)?.remove();
    window.removeEventListener("keydown", panelEscapeHandler, true);
    if (panelReturnFocus?.isConnected) panelReturnFocus.focus();
    panelReturnFocus = null;
  }
  function panelEscapeHandler(event) {
    if (event.key === "Escape" && document.getElementById(PANEL_ID)) {
      event.preventDefault();
      closeStudyPanel();
    }
  }
  function panelButton(label, action, className = "") {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = label;
    button.className = className;
    button.addEventListener("click", () => void action());
    return button;
  }
  function beginReattach(annotation) {
    if (annotation.pageUrl !== currentPageUrl2()) return;
    pendingReattachId = annotation.id;
    closeStudyPanel();
    toast(t("reattach_instruction"));
  }
  async function deleteAnnotation(annotation) {
    if (!window.confirm(t("delete_highlight_confirm"))) return;
    try {
      await mutateStudyData((current) => ({
        ...current,
        annotations: current.annotations.filter((item) => item.id !== annotation.id)
      }));
      toast(t("highlight_deleted"));
    } catch (error) {
      storageFailure(error);
    }
  }
  function openAnnotationSource(annotation) {
    const localElement = resolvedElements.get(annotation.id);
    if (annotation.pageUrl === currentPageUrl2() && localElement) {
      localElement.scrollIntoView({ behavior: "smooth", block: "center" });
      localElement.classList.add("studynav-locate-pulse");
      window.setTimeout(() => localElement.classList.remove("studynav-locate-pulse"), 1400);
      return;
    }
    const target = new URL(annotation.pageUrl);
    if (annotation.root.id) target.hash = annotation.root.id;
    const opened = window.open(target.toString(), "_blank", "noopener,noreferrer");
    if (opened) opened.opener = null;
  }
  function annotationCard(annotation) {
    const card = document.createElement("article");
    card.className = "studynav-note-card";
    card.dataset.annotationId = annotation.id;
    const head = document.createElement("div");
    head.className = "studynav-note-card-head";
    const swatch = document.createElement("span");
    swatch.className = "studynav-note-swatch";
    swatch.dataset.color = annotation.color;
    const title = document.createElement("strong");
    title.textContent = annotation.title || "JW.ORG";
    head.append(swatch, title);
    if (unresolvedIds.has(annotation.id) && annotation.pageUrl === currentPageUrl2()) {
      const orphan = document.createElement("span");
      orphan.className = "studynav-orphan-badge";
      orphan.textContent = t("needs_attention");
      head.appendChild(orphan);
    }
    const quote = document.createElement("blockquote");
    quote.textContent = annotation.selector.exact;
    card.append(head, quote);
    if (annotation.note) {
      const note = document.createElement("p");
      note.className = "studynav-note-body";
      note.textContent = annotation.note;
      card.appendChild(note);
    }
    if (annotation.tags.length) {
      const tags = document.createElement("div");
      tags.className = "studynav-note-tags";
      for (const value of annotation.tags) {
        const tag = document.createElement("span");
        tag.textContent = value;
        tags.appendChild(tag);
      }
      card.appendChild(tags);
    }
    const actions = document.createElement("div");
    actions.className = "studynav-note-actions";
    actions.append(
      panelButton(annotation.pageUrl === currentPageUrl2() ? t("locate") : t("open_page"), () => openAnnotationSource(annotation)),
      panelButton(t("edit"), () => openAnnotationEditor(null, annotation)),
      panelButton(t("delete"), () => deleteAnnotation(annotation), "studynav-danger-button")
    );
    if (unresolvedIds.has(annotation.id) && annotation.pageUrl === currentPageUrl2()) {
      actions.appendChild(panelButton(t("reattach"), () => beginReattach(annotation)));
    }
    card.appendChild(actions);
    return card;
  }
  function openBookmarkSource(bookmark) {
    const opened = window.open(bookmark.targetUrl, "_blank", "noopener,noreferrer");
    if (opened) opened.opener = null;
  }
  async function deleteBookmark(bookmark) {
    if (!window.confirm(t("remove_saved_place_confirm"))) return;
    try {
      await mutateStudyData((current) => ({
        ...current,
        bookmarks: current.bookmarks.filter((item) => item.id !== bookmark.id)
      }));
      toast(t("saved_place_removed"));
    } catch (error) {
      storageFailure(error);
    }
  }
  function bookmarkCard(bookmark) {
    const card = document.createElement("article");
    card.className = "studynav-note-card studynav-bookmark-card";
    card.dataset.bookmarkId = bookmark.id;
    const head = document.createElement("div");
    head.className = "studynav-note-card-head";
    const title = document.createElement("strong");
    title.textContent = bookmark.title || "JW.ORG";
    head.appendChild(title);
    card.appendChild(head);
    if (bookmark.reference) {
      const reference = document.createElement("p");
      reference.className = "studynav-bookmark-reference";
      reference.textContent = bookmark.reference;
      card.appendChild(reference);
    }
    const target = document.createElement("p");
    target.className = "studynav-bookmark-url";
    target.textContent = bookmark.targetUrl;
    card.appendChild(target);
    const actions = document.createElement("div");
    actions.className = "studynav-note-actions";
    actions.append(
      panelButton(t("open_saved_place"), () => openBookmarkSource(bookmark)),
      panelButton(t("remove_saved_place_action"), () => deleteBookmark(bookmark), "studynav-danger-button")
    );
    card.appendChild(actions);
    return card;
  }
  function panelElements() {
    const panel = document.getElementById(PANEL_ID);
    return panel ? {
      panel,
      search: panel.querySelector("#studynav-note-search"),
      tag: panel.querySelector("#studynav-note-tag"),
      count: panel.querySelector("#studynav-note-count"),
      list: panel.querySelector("#studynav-note-list"),
      notesView: panel.querySelector('[data-view="notes"]'),
      bookmarksView: panel.querySelector('[data-view="bookmarks"]'),
      pageScope: panel.querySelector('[data-scope="page"]'),
      allScope: panel.querySelector('[data-scope="all"]')
    } : null;
  }
  async function renderStudyPanel(dataValue) {
    const elements = panelElements();
    if (!elements) return;
    try {
      const data = dataValue || await loadStudyData();
      const pageUrl = currentPageUrl2();
      if (!annotationsEnabled && bookmarksEnabled) panelView = "bookmarks";
      if (!bookmarksEnabled) panelView = "notes";
      elements.notesView.hidden = !annotationsEnabled;
      elements.bookmarksView.hidden = !bookmarksEnabled;
      elements.notesView.setAttribute("aria-pressed", String(panelView === "notes"));
      elements.bookmarksView.setAttribute("aria-pressed", String(panelView === "bookmarks"));
      elements.pageScope.textContent = t("this_page");
      elements.allScope.textContent = t(panelView === "notes" ? "all_notes" : "all_pages");
      elements.search.placeholder = t(panelView === "notes" ? "search_notes_placeholder" : "search_saved_places");
      elements.search.setAttribute("aria-label", t(panelView === "notes" ? "search_notes" : "search_saved_places"));
      elements.tag.hidden = panelView !== "notes";
      elements.panel.querySelector(".studynav-study-filters").dataset.view = panelView;
      elements.list.replaceChildren();
      const query = cleanCitationText(elements.search.value).toLowerCase();
      if (panelView === "bookmarks") {
        const records = data.bookmarks.filter((bookmark) => {
          if (panelScope === "page" && bookmark.pageUrl !== pageUrl) return false;
          if (!query) return true;
          return [bookmark.title, bookmark.reference, bookmark.targetUrl].join(" ").toLowerCase().includes(query);
        });
        for (const bookmark of records) elements.list.appendChild(bookmarkCard(bookmark));
        if (!records.length) {
          const empty = document.createElement("p");
          empty.className = "studynav-empty-state";
          empty.textContent = data.bookmarks.length ? t("no_saved_places_filtered") : t("no_saved_places_yet");
          elements.list.appendChild(empty);
        }
        elements.count.textContent = t(
          records.length === 1 ? "saved_places_count_one" : "saved_places_count_many",
          String(records.length)
        );
      } else {
        const allTags = [...new Set(data.annotations.flatMap((annotation) => annotation.tags))].sort();
        const selectedTag = elements.tag.value;
        elements.tag.replaceChildren(new Option(t("all_tags"), ""));
        for (const tag2 of allTags) elements.tag.appendChild(new Option(tag2, tag2));
        elements.tag.value = allTags.includes(selectedTag) ? selectedTag : "";
        const tag = elements.tag.value;
        const records = data.annotations.filter((annotation) => {
          if (panelScope === "page" && annotation.pageUrl !== pageUrl) return false;
          if (tag && !annotation.tags.includes(tag)) return false;
          if (!query) return true;
          return [annotation.title, annotation.selector.exact, annotation.note, annotation.tags.join(" ")].join(" ").toLowerCase().includes(query);
        });
        for (const annotation of records) elements.list.appendChild(annotationCard(annotation));
        if (!records.length) {
          const empty = document.createElement("p");
          empty.className = "studynav-empty-state";
          empty.textContent = data.annotations.length ? t("no_notes_filtered") : t("no_notes_yet");
          elements.list.appendChild(empty);
        }
        elements.count.textContent = t(records.length === 1 ? "notes_count_one" : "notes_count_many", String(records.length));
      }
      elements.panel.querySelectorAll("[data-scope]").forEach((button) => {
        button.setAttribute("aria-pressed", String(button.dataset.scope === panelScope));
      });
    } catch (error) {
      storageFailure(error);
    }
  }
  async function exportStudyData() {
    try {
      const data = await loadStudyData();
      const json = serializeStudyData(data);
      if (!json) throw new Error(t("study_export_failed"));
      const url = URL.createObjectURL(new Blob([json], { type: "application/json" }));
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `studynav-study-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
      toast(t("study_backup_downloaded"));
    } catch (error) {
      storageFailure(error);
    }
  }
  async function importStudyData(file) {
    try {
      if (file.size > MAX_BACKUP_JSON_BYTES) {
        toast(t("backup_too_large"));
        return;
      }
      const parsed = parseStudyDataBackup(await file.text());
      if (!parsed.data) {
        toast(parsed.error === "too-large" ? t("backup_too_large") : t("backup_invalid"));
        return;
      }
      let stats = { accepted: 0, updated: 0, ignored: 0, rejected: 0 };
      await mutateStudyData((current) => {
        const merged = mergeStudyData(current, parsed.data);
        stats = merged.stats;
        return merged.data;
      });
      toast(t("import_summary", [
        String(stats.accepted),
        String(stats.updated),
        String(stats.ignored),
        String(stats.rejected)
      ]));
    } catch (error) {
      storageFailure(error);
    }
  }
  function mountStudyPanel() {
    closeStudyPanel();
    panelReturnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const panel = document.createElement("aside");
    panel.id = PANEL_ID;
    panel.className = "studynav-study-panel";
    panel.setAttribute("data-studynav-owned", "1");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "false");
    panel.setAttribute("aria-labelledby", "studynav-study-title");
    const head = document.createElement("div");
    head.className = "studynav-study-head";
    const headingWrap = document.createElement("div");
    const title = document.createElement("strong");
    title.id = "studynav-study-title";
    title.textContent = t("study_library");
    const count = document.createElement("span");
    count.id = "studynav-note-count";
    count.textContent = t("notes_count_many", "0");
    headingWrap.append(title, count);
    const close = panelButton(t("close"), closeStudyPanel, "studynav-icon-button");
    close.setAttribute("aria-label", t("close_study_library_aria"));
    head.append(headingWrap, close);
    if (!annotationsEnabled && bookmarksEnabled) panelView = "bookmarks";
    if (!bookmarksEnabled) panelView = "notes";
    const view = document.createElement("div");
    view.className = "studynav-view-switch";
    for (const [value, label] of [["notes", t("notes_tab")], ["bookmarks", t("saved_places_tab")]]) {
      const button = panelButton(label, () => {
        panelView = value;
        panelScope = "page";
        search.value = "";
        tag.value = "";
        void renderStudyPanel();
      });
      button.dataset.view = value;
      button.hidden = value === "notes" ? !annotationsEnabled : !bookmarksEnabled;
      button.setAttribute("aria-pressed", String(panelView === value));
      view.appendChild(button);
    }
    const scope = document.createElement("div");
    scope.className = "studynav-scope-switch";
    for (const [value, label] of [["page", t("this_page")], ["all", t("all_notes")]]) {
      const button = panelButton(label, () => {
        panelScope = value;
        void renderStudyPanel();
      });
      button.dataset.scope = value;
      button.setAttribute("aria-pressed", String(panelScope === value));
      scope.appendChild(button);
    }
    const filters = document.createElement("div");
    filters.className = "studynav-study-filters";
    const search = document.createElement("input");
    search.id = "studynav-note-search";
    search.type = "search";
    search.placeholder = t("search_notes_placeholder");
    search.setAttribute("aria-label", t("search_notes"));
    const tag = document.createElement("select");
    tag.id = "studynav-note-tag";
    tag.setAttribute("aria-label", t("filter_notes_tag"));
    tag.appendChild(new Option(t("all_tags"), ""));
    search.addEventListener("input", () => void renderStudyPanel());
    tag.addEventListener("change", () => void renderStudyPanel());
    filters.append(search, tag);
    const list = document.createElement("div");
    list.id = "studynav-note-list";
    list.className = "studynav-note-list";
    const footer = document.createElement("div");
    footer.className = "studynav-study-footer";
    const exportButton = panelButton(t("export_json"), exportStudyData);
    const importLabel = document.createElement("label");
    importLabel.className = "studynav-import-label";
    importLabel.textContent = t("import_json");
    importLabel.tabIndex = 0;
    const file = document.createElement("input");
    file.type = "file";
    file.accept = "application/json,.json";
    file.addEventListener("change", () => {
      const selected = file.files?.[0];
      if (selected) void importStudyData(selected);
      file.value = "";
    });
    importLabel.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        file.click();
      }
    });
    importLabel.appendChild(file);
    footer.append(exportButton, importLabel);
    panel.append(head, view, scope, filters, list, footer);
    document.documentElement.appendChild(panel);
    window.addEventListener("keydown", panelEscapeHandler, true);
    search.focus();
  }
  async function openStudyPanel() {
    if (!enabled2) return { ok: false, message: t("study_tools_off") };
    mountStudyPanel();
    await renderStudyState();
    return { ok: true, message: t("study_library_opened") };
  }
  var localStorageChangeHandler = (changes, areaName) => {
    if (enabled2 && studyDataChanged(changes, areaName)) void renderStudyState();
  };
  function applyStudyRuntime(nextArticleRoots, options = { annotations: true, bookmarks: false }) {
    articleRoots2 = [...nextArticleRoots];
    const annotationStateChanged = annotationsEnabled !== options.annotations;
    annotationsEnabled = options.annotations;
    bookmarksEnabled = options.bookmarks;
    if (!enabled2) {
      enabled2 = true;
    }
    if (annotationsEnabled) {
      document.addEventListener("selectionchange", selectionChangeHandler, true);
    } else if (annotationStateChanged) {
      document.removeEventListener("selectionchange", selectionChangeHandler, true);
      pendingReattachId = null;
      hideSelectionTools();
      closeEditor();
      clearHighlightRegistry();
      unresolvedIds = /* @__PURE__ */ new Set();
      resolvedElements = /* @__PURE__ */ new Map();
    }
    if (!storageListening2) {
      storageListening2 = true;
      chrome.storage.onChanged.addListener(localStorageChangeHandler);
    }
    if (!railResizeListening) {
      railResizeListening = true;
      window.addEventListener("resize", positionPageNoteRail);
    }
    void renderStudyState();
  }
  function teardownStudyRuntime() {
    enabled2 = false;
    annotationsEnabled = false;
    bookmarksEnabled = false;
    articleRoots2 = [];
    pendingReattachId = null;
    lastSelectionError = "";
    renderGeneration += 1;
    if (selectionTimer != null) window.clearTimeout(selectionTimer);
    selectionTimer = null;
    document.removeEventListener("selectionchange", selectionChangeHandler, true);
    if (storageListening2) {
      storageListening2 = false;
      chrome.storage.onChanged.removeListener(localStorageChangeHandler);
    }
    if (railResizeListening) {
      railResizeListening = false;
      window.removeEventListener("resize", positionPageNoteRail);
    }
    hideSelectionTools();
    closeEditor();
    closeStudyPanel();
    document.getElementById(NOTE_RAIL_ID)?.remove();
    clearHighlightRegistry();
    unresolvedIds = /* @__PURE__ */ new Set();
    resolvedElements = /* @__PURE__ */ new Map();
  }

  // packages/studynav/src/verse-audio.ts
  var MEDIA_API_HOST = "b.jw-cdn.org";
  var MEDIA_API_PATH = "/apis/pub-media/getpubmedialinks";
  var MAX_CHAPTER_AUDIO_BYTES = 64 * 1024 * 1024;
  var MAX_WAV_BYTES = 24 * 1024 * 1024;
  var MAX_MEDIA_CLIP_SECONDS = 120;
  var MAX_MEDIA_VIDEO_CLIP_SECONDS = 60;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function finiteNumber2(value) {
    const number = typeof value === "number" ? value : Number(value);
    return Number.isFinite(number) ? number : null;
  }
  function parseBibleVerseId(value) {
    const match = /^v([1-9]\d?)(\d{3})(\d{3})$/.exec(value);
    if (!match) return null;
    const verse = {
      book: Number(match[1]),
      chapter: Number(match[2]),
      verse: Number(match[3])
    };
    if (verse.book < 1 || verse.book > 66 || verse.chapter < 1 || verse.chapter > 150 || verse.verse < 1 || verse.verse > 200) return null;
    return verse;
  }
  function isJwCdnUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (url.hostname === "jw-cdn.org" || url.hostname.endsWith(".jw-cdn.org"));
    } catch {
      return false;
    }
  }
  function mediaApiShell(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.hostname !== MEDIA_API_HOST || url.pathname.toLowerCase() !== MEDIA_API_PATH || url.username || url.password) return null;
      if (url.searchParams.get("output")?.toLowerCase() !== "json") return null;
      if (url.searchParams.get("fileformat")?.toUpperCase() !== "MP3") return null;
      return url;
    } catch {
      return null;
    }
  }
  function normalizeMediaApiUrl(value, verse) {
    const url = mediaApiShell(value);
    if (!url) return null;
    const langwritten = url.searchParams.get("langwritten");
    const txtCMSLang = url.searchParams.get("txtCMSLang");
    if (!langwritten || !txtCMSLang || langwritten !== txtCMSLang) return null;
    const pub = url.searchParams.get("pub");
    if (pub === "nwtsty" || pub === "nwt") url.searchParams.set("pub", "nwt");
    else if (!pub) return null;
    if (!url.searchParams.has("booknum")) url.searchParams.set("booknum", String(verse.book));
    if (!url.searchParams.has("track")) url.searchParams.set("track", String(verse.chapter));
    if (!url.searchParams.has("alllangs")) url.searchParams.set("alllangs", "0");
    return validateMediaApiUrl(url.href, verse);
  }
  function validateMediaApiUrl(value, verse) {
    const url = mediaApiShell(value);
    if (!url) return null;
    if (Number(url.searchParams.get("booknum")) !== verse.book) return null;
    if (Number(url.searchParams.get("track")) !== verse.chapter) return null;
    if (!url.searchParams.get("langwritten") || !url.searchParams.get("txtCMSLang")) return null;
    const pub = url.searchParams.get("pub");
    if (pub !== "nwt") return null;
    return url.href;
  }
  function parseUserMediaTime(value) {
    const parts = String(value || "").trim().split(":");
    if (!parts.length || parts.length > 3 || parts.some((part) => !/^\d+(?:\.\d{1,3})?$/.test(part))) return null;
    const numbers = parts.map(Number);
    if (numbers.some((part) => !Number.isFinite(part))) return null;
    if (parts.length === 1) return numbers[0] <= 36e3 ? numbers[0] : null;
    const seconds = numbers.at(-1);
    const minutes = numbers.at(-2);
    if (seconds >= 60 || minutes >= 60) return null;
    const hours = parts.length === 3 ? numbers[0] : 0;
    if (hours > 10) return null;
    return hours * 3600 + minutes * 60 + seconds;
  }
  function validateMediaVideoClipRequest(value, senderUrl) {
    if (!isRecord(value) || value.type !== "DOWNLOAD_MEDIA_VIDEO_CLIP") return null;
    if (typeof value.mediaUrl !== "string" || typeof value.label !== "string") return null;
    const startSeconds = finiteNumber2(value.startSeconds);
    const endSeconds = finiteNumber2(value.endSeconds);
    if (startSeconds === null || endSeconds === null || startSeconds < 0 || endSeconds <= startSeconds || endSeconds - startSeconds > MAX_MEDIA_VIDEO_CLIP_SECONDS || endSeconds > 36e3 || !isJwCdnUrl(value.mediaUrl)) return null;
    try {
      const sender = new URL(senderUrl);
      const allowedHost = sender.hostname === "jw.org" || sender.hostname.endsWith(".jw.org");
      if (sender.protocol !== "https:" || !allowedHost || sender.username || sender.password) return null;
    } catch {
      return null;
    }
    const label = safeFilenamePart(value.label);
    const startLabel = Math.floor(startSeconds).toString().padStart(4, "0");
    const endLabel = Math.floor(endSeconds).toString().padStart(4, "0");
    return {
      type: "DOWNLOAD_MEDIA_VIDEO_CLIP",
      mediaUrl: value.mediaUrl,
      startSeconds,
      endSeconds,
      label,
      filename: `${label}_${startLabel}-${endLabel}.webm`
    };
  }
  function apiUrlFromAudioUrl(audioUrl, verse) {
    if (!isJwCdnUrl(audioUrl)) return null;
    try {
      const name = decodeURIComponent(new URL(audioUrl).pathname.split("/").pop() || "");
      const match = /^([a-z0-9]+)_(\d{2})_[^_]+_([a-z0-9-]+)_(\d{2,3})\.mp3$/i.exec(name);
      if (!match || Number(match[2]) !== verse.book || Number(match[4]) !== verse.chapter) return null;
      const url = new URL(`https://${MEDIA_API_HOST}/apis/pub-media/GETPUBMEDIALINKS`);
      url.search = new URLSearchParams({
        booknum: String(verse.book),
        output: "json",
        pub: match[1] === "nwtsty" ? "nwt" : match[1],
        fileformat: "MP3",
        alllangs: "0",
        track: String(verse.chapter),
        langwritten: match[3],
        txtCMSLang: match[3]
      }).toString();
      return validateMediaApiUrl(url.href, verse);
    } catch {
      return null;
    }
  }
  function findBibleAudioApiUrl(resourceUrls, verseId, chapterAudioUrl2 = "") {
    const verse = parseBibleVerseId(verseId);
    if (!verse) return null;
    for (let index = resourceUrls.length - 1; index >= 0; index--) {
      const normalized = normalizeMediaApiUrl(resourceUrls[index], verse);
      if (normalized) return normalized;
      const valid = validateMediaApiUrl(resourceUrls[index], verse);
      if (valid) return valid;
    }
    return apiUrlFromAudioUrl(chapterAudioUrl2, verse);
  }
  function safeFilenamePart(value) {
    return value.normalize("NFKC").replace(/[\u0000-\u001f\u007f/\\?%*:|"<>]+/g, " ").replace(/\s+/g, " ").trim().replace(/[. ]+$/g, "").slice(0, 80) || "Bible";
  }
  function base64ToBytes(value) {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
    return bytes;
  }

  // packages/studynav/src/feature-impl.ts
  var STYLE_ID = "studynav-dynamic-style";
  var ARTICLE_MARKER = "data-studynav-article";
  var QR_OVERLAY_ID = "studynav-qr-overlay";
  var verseAudioJobs = /* @__PURE__ */ new Set();
  var verseSelectionListening = false;
  var selectedVerseIds = [];
  var verseRangePickAnchorId = null;
  var verseToolbarFrame = null;
  var qrReturnFocus = null;
  function positionSelectedVerseToolbar() {
    verseToolbarFrame = null;
    const anchorId = selectedVerseIds.at(-1);
    if (!anchorId) return;
    const verse = document.getElementById(anchorId);
    const toolbar2 = verse?.querySelector(":scope > .studynav-para-tools");
    if (!verse || !toolbar2 || getComputedStyle(toolbar2).display === "none") return;
    toolbar2.dataset.snVerseFloating = "1";
    toolbar2.style.position = "fixed";
    toolbar2.style.right = "auto";
    toolbar2.style.zIndex = "2147483641";
    toolbar2.style.left = "8px";
    toolbar2.style.top = "8px";
    const verseRect = verse.getBoundingClientRect();
    const toolbarRect = toolbar2.getBoundingClientRect();
    const gap = 6;
    const edge = 8;
    const maxLeft = Math.max(edge, window.innerWidth - toolbarRect.width - edge);
    const leftDock = verseRect.left - toolbarRect.width - gap;
    const rightDock = verseRect.right + gap;
    const above = verseRect.top - toolbarRect.height - gap;
    const below = verseRect.bottom + gap;
    const maxTop = Math.max(edge, window.innerHeight - toolbarRect.height - edge);
    let left;
    let top;
    if (leftDock >= edge) {
      left = leftDock;
      top = Math.min(Math.max(verseRect.top, edge), maxTop);
    } else if (rightDock + toolbarRect.width <= window.innerWidth - edge) {
      left = rightDock;
      top = Math.min(Math.max(verseRect.top, edge), maxTop);
    } else {
      left = Math.min(Math.max(verseRect.left, edge), maxLeft);
      top = above >= edge ? above : Math.min(Math.max(below, edge), maxTop);
    }
    toolbar2.style.left = `${Math.round(left)}px`;
    toolbar2.style.top = `${Math.round(top)}px`;
  }
  function scheduleVerseToolbarPosition() {
    if (verseToolbarFrame != null) return;
    verseToolbarFrame = window.requestAnimationFrame(positionSelectedVerseToolbar);
  }
  function stopVerseToolbarPositioning() {
    if (verseToolbarFrame != null) window.cancelAnimationFrame(verseToolbarFrame);
    verseToolbarFrame = null;
    window.removeEventListener("resize", scheduleVerseToolbarPosition);
    window.removeEventListener("scroll", scheduleVerseToolbarPosition, true);
  }
  function ensureStyle(css) {
    let el = document.getElementById(STYLE_ID);
    if (!el) {
      el = document.createElement("style");
      el.id = STYLE_ID;
      document.documentElement.appendChild(el);
    }
    el.textContent = css;
  }
  function removeStyle() {
    document.getElementById(STYLE_ID)?.remove();
  }
  function cssFor(flags2, hostname) {
    const bits = [];
    const isWol = hostname.toLowerCase() === "wol.jw.org";
    if (flags2.actionBar && !isWol) {
      bits.push(`
      #regionHeader {
        position: sticky !important; top: 0 !important; z-index: 9990 !important;
        backdrop-filter: saturate(1.2) blur(6px);
      }
    `);
    }
    if (flags2.expandWidth && !isWol) {
      bits.push(`
      [${ARTICLE_MARKER}="1"] {
        max-width: min(1100px, 96vw) !important;
        width: 100% !important;
        box-sizing: border-box !important;
        margin-left: auto !important; margin-right: auto !important;
      }
      @media (min-width: 900px) {
        #content.readingPane:has([${ARTICLE_MARKER}="1"]) {
          width: 68% !important;
        }
        #content.readingPane:has([${ARTICLE_MARKER}="1"]) ~ .studyPane {
          width: 32% !important;
        }
      }
    `);
    }
    if (flags2.cstblView && !isWol) {
      bits.push(`
      [${ARTICLE_MARKER}="1"] table {
        border-collapse: collapse !important; width: 100% !important;
      }
      [${ARTICLE_MARKER}="1"] table th,
      [${ARTICLE_MARKER}="1"] table td {
        border: 1px solid #8aa !important; padding: 6px 8px !important;
      }
      [${ARTICLE_MARKER}="1"] table tr:nth-child(even) td {
        background: rgba(67,102,159,.08) !important;
      }
    `);
    }
    if (flags2.mediaPlayerUI) {
      bits.push(`
      .video-js .vjs-control-bar,
      .video-js:hover .vjs-control-bar,
      .video-js.vjs-user-active .vjs-control-bar {
        opacity: 1 !important;
        background: transparent !important;
        background-image: none !important;
        box-shadow: none !important;
      }
    `);
    }
    if (flags2.customSub) {
      bits.push(`
      .vjs-text-track-cue > div, .vjs-text-track-display .vjs-text-track-cue div,
      ::cue {
        font-size: 1.25em !important;
        background: rgba(0,0,0,.65) !important;
        color: #fff !important;
      }
    `);
    }
    if (flags2.altText) {
      bits.push(`
      .studynav-alt {
        display:block; margin-top:4px; padding:6px 8px;
        border:1px solid rgba(67,102,159,.38); border-radius:6px;
        background: rgba(67,102,159,.1); color: inherit; font-size: 0.92em;
      }
    `);
    }
    return bits.join("\n");
  }
  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }
  function removeOwnedNodes(selector) {
    qsa(selector).forEach((node) => node.remove());
  }
  function clearOwnedAnchors() {
    qsa('[data-sn-owned-anchor="1"]').forEach((el) => {
      el.removeAttribute("id");
      delete el.dataset.snOwnedAnchor;
    });
  }
  function teardownAltText() {
    removeOwnedNodes(".studynav-alt");
    qsa("[data-sn-alt]").forEach((img) => delete img.dataset.snAlt);
  }
  function teardownCopyAndLinks() {
    stopVerseToolbarPositioning();
    if (verseSelectionListening) {
      window.removeEventListener("click", verseSelectionHandler, true);
      verseSelectionListening = false;
    }
    selectedVerseIds = [];
    verseRangePickAnchorId = null;
    removeOwnedNodes(".studynav-para-tools");
    qsa("[data-sn-tools], .studynav-para").forEach((el) => {
      delete el.dataset.snTools;
      el.classList.remove("studynav-para");
    });
    qsa(".studynav-verse-selected").forEach((el) => {
      el.classList.remove("studynav-verse-selected");
      el.classList.remove("studynav-verse-toolbar-anchor");
    });
    clearOwnedAnchors();
  }
  function teardownImgGet() {
    removeOwnedNodes(".studynav-imgdl");
    qsa("[data-sn-dl]").forEach((img) => delete img.dataset.snDl);
  }
  function teardownPalette() {
    document.getElementById("studynav-palette")?.remove();
    window.removeEventListener("keydown", paletteHotkeyHandler, true);
  }
  function teardownLanguageBadge() {
    document.getElementById("studynav-langcount")?.remove();
  }
  function teardownMediaToolbar() {
    document.getElementById("studynav-media-bar")?.remove();
    document.getElementById("studynav-clip-panel")?.remove();
  }
  function teardownTranscript() {
    document.getElementById("studynav-transcript")?.remove();
  }
  function teardownToast() {
    document.getElementById("studynav-toast")?.remove();
  }
  var qrEscapeHandler = (event) => {
    if (event.key === "Escape") teardownQrOverlay();
  };
  function teardownQrOverlay() {
    document.getElementById(QR_OVERLAY_ID)?.remove();
    window.removeEventListener("keydown", qrEscapeHandler, true);
    if (qrReturnFocus?.isConnected) qrReturnFocus.focus();
    qrReturnFocus = null;
  }
  function clearArticleMarkers() {
    qsa(`[${ARTICLE_MARKER}]`).forEach((root) => root.removeAttribute(ARTICLE_MARKER));
  }
  function markArticleRoots(articleRoots3) {
    clearArticleMarkers();
    articleRoots3.forEach((root) => root.setAttribute(ARTICLE_MARKER, "1"));
  }
  function teardownMediaCtrl() {
    window.removeEventListener("keydown", mediaKeyHandler, true);
  }
  function deriveFeaturePlan(flags2, support) {
    if (flags2.masterEnabled === false) {
      return {
        state: "off",
        teardownAll: true,
        teardown: {
          transcript: true,
          altText: true,
          copyAndLinks: true,
          imgGet: true,
          palette: true,
          mediaCtrl: true,
          languageBadge: true,
          mediaToolbar: true,
          annotations: true,
          continueWatching: true
        },
        styleFlags: { ...flags2 }
      };
    }
    if (!support.supported) {
      return {
        state: "unsupported",
        teardownAll: true,
        teardown: {
          transcript: true,
          altText: true,
          copyAndLinks: true,
          imgGet: true,
          palette: true,
          mediaCtrl: true,
          languageBadge: true,
          mediaToolbar: true,
          annotations: true,
          continueWatching: true
        },
        styleFlags: { ...flags2 }
      };
    }
    return {
      state: "active",
      teardownAll: false,
      teardown: {
        transcript: !flags2.transcCreate || !support.media,
        altText: !flags2.altText || !support.article,
        copyAndLinks: !flags2.copyText && !flags2.parLink && !flags2.verseAudio && !flags2.annotations || !support.article,
        imgGet: !flags2.imgGet || !support.article,
        palette: !flags2.advSearch || !support.palette,
        mediaCtrl: !flags2.mediaCtrl || !support.media,
        languageBadge: !flags2.langCount || !support.language,
        mediaToolbar: !support.media || !(flags2.mediaTS || flags2.mediaClip || flags2.sndDisp || flags2.transcCreate || flags2.continueWatching),
        annotations: !flags2.annotations && !flags2.bookmarks,
        continueWatching: !flags2.continueWatching || !support.media
      },
      styleFlags: {
        ...flags2,
        actionBar: support.article ? flags2.actionBar : false,
        expandWidth: support.article ? flags2.expandWidth : false,
        cstblView: support.article ? flags2.cstblView : false,
        mediaPlayerUI: support.media ? flags2.mediaPlayerUI : false,
        customSub: support.media ? flags2.customSub : false,
        altText: support.article ? flags2.altText : false
      }
    };
  }
  function teardownFeatures() {
    teardownPalette();
    teardownAltText();
    teardownCopyAndLinks();
    teardownImgGet();
    teardownLanguageBadge();
    teardownMediaToolbar();
    teardownTranscript();
    teardownToast();
    teardownQrOverlay();
    teardownMediaCtrl();
    teardownContinueWatching();
    teardownStudyRuntime();
    clearArticleMarkers();
    removeStyle();
    document.documentElement.classList.remove("studynav-on");
    delete document.documentElement.dataset.studynav;
  }
  function canonicalCurrentPageUrl() {
    const canonical = qs('link[rel="canonical"][href]')?.href || null;
    return canonicalStudyUrl(location.href, canonical);
  }
  function selectionElement(selection, articleRoots3) {
    if (selection.rangeCount !== 1 || selection.isCollapsed) return null;
    const range = selection.getRangeAt(0);
    return paragraphNodes(articleRoots3).find((element) => element.contains(range.startContainer) && element.contains(range.endContainer)) || null;
  }
  function elementFragment(element) {
    if (!element) return null;
    const url = new URL(deepestLinkFor(element));
    if (!url.hash) return null;
    try {
      return decodeURIComponent(url.hash.slice(1));
    } catch {
      return null;
    }
  }
  function referenceForElement(element) {
    if (!element) return "";
    const verse = parseBibleVerseId(element.id);
    if (verse) return `${bibleReferenceLabel()} ${verse.chapter}:${verse.verse}`;
    const pid = element.getAttribute("data-pid");
    return pid ? `Paragraph ${pid}` : "Paragraph";
  }
  function verseElementsInDocumentOrder() {
    return qsa('.verse[id^="v"]').filter((element) => !!parseBibleVerseId(element.id));
  }
  function verseElementsForIds(ids) {
    const wanted = new Set(ids);
    return verseElementsInDocumentOrder().filter((element) => wanted.has(element.id));
  }
  function verseElementsFromHash() {
    let hash;
    try {
      hash = decodeURIComponent(location.hash.slice(1));
    } catch {
      return [];
    }
    const match = /^(v[1-9]\d?\d{6})(?:-(v[1-9]\d?\d{6}))?$/.exec(hash);
    if (!match) return [];
    const start = parseBibleVerseId(match[1]);
    const end = parseBibleVerseId(match[2] || match[1]);
    if (!start || !end || start.book !== end.book || start.chapter !== end.chapter || end.verse < start.verse) return [];
    return verseElementsInDocumentOrder().filter((element) => {
      const verse = parseBibleVerseId(element.id);
      return !!verse && verse.book === start.book && verse.chapter === start.chapter && verse.verse >= start.verse && verse.verse <= end.verse;
    });
  }
  function currentSelectedVerseElements() {
    const explicit = verseElementsForIds(selectedVerseIds);
    return explicit.length ? explicit : verseElementsFromHash();
  }
  function verseRangeFragment(elements) {
    const first = elements[0];
    const last = elements.at(-1);
    if (!first || !last || !parseBibleVerseId(first.id) || !parseBibleVerseId(last.id)) return null;
    return first.id === last.id ? first.id : `${first.id}-${last.id}`;
  }
  function verseRangeFinderToken(elements) {
    const fragment = verseRangeFragment(elements);
    return fragment ? fragment.replaceAll("v", "") : null;
  }
  function verseRangeReference(elements) {
    const first = elements[0] ? parseBibleVerseId(elements[0].id) : null;
    const last = elements.at(-1) ? parseBibleVerseId(elements.at(-1).id) : null;
    if (!first || !last) return "";
    const verses = first.verse === last.verse ? `${first.verse}` : `${first.verse}\u2013${last.verse}`;
    return `${bibleReferenceLabel()} ${first.chapter}:${verses}`;
  }
  function verseRangeText(elements) {
    return elements.map((element) => textForCopy(element)).filter(Boolean).join("\n");
  }
  function preciseLinkForVerseRange(elements) {
    const base = canonicalCurrentPageUrl();
    const fragment = verseRangeFragment(elements);
    return base && fragment ? preciseStudyUrl(base, fragment) : null;
  }
  function currentCitationTarget() {
    const support = currentSupport();
    const selection = window.getSelection();
    const selectedElement = selection ? selectionElement(selection, support.articleRoots) : null;
    if (selection && selectedElement) {
      return {
        element: selectedElement,
        quote: selection.toString(),
        reference: referenceForElement(selectedElement),
        fragment: elementFragment(selectedElement)
      };
    }
    const selectedVerses = currentSelectedVerseElements();
    const selectedVerse = selectedVerses[0];
    if (selectedVerse) {
      return {
        element: selectedVerse,
        quote: verseRangeText(selectedVerses),
        reference: verseRangeReference(selectedVerses),
        fragment: verseRangeFragment(selectedVerses)
      };
    }
    return { element: null, quote: "", reference: "", fragment: null };
  }
  function pageDocumentTitle() {
    const heading = qs("#article h1, article h1, main h1, h1");
    return (heading?.innerText || heading?.textContent || document.title || "JW.ORG").trim();
  }
  function pageFinderMetadata() {
    const data = qs(
      ".jsGlobalShareData .link[data-wtlocale], [data-wtlocale][data-bible], [data-wtlocale][data-docid], [data-wtlocale][data-pub]"
    );
    const article = qs("#article, article");
    const classes = `${document.body?.className || ""} ${article?.className || ""}`;
    const classDocId = /(?:^|\s)docId-(\d{6,16})(?:\s|$)/.exec(classes)?.[1] || null;
    const classLocale = /(?:^|\s)ml-([A-Za-z][A-Za-z0-9-]{0,7})(?:\s|$)/.exec(classes)?.[1] || null;
    const book = article?.getAttribute("data-booknum");
    const chapter = article?.getAttribute("data-chapter");
    const computedBible = /^\d{1,2}$/.test(book || "") && /^\d{1,3}$/.test(chapter || "") ? String(Number(book) * 1e6 + Number(chapter) * 1e3) : null;
    const selectedBible = verseRangeFinderToken(currentSelectedVerseElements());
    return {
      pub: data?.getAttribute("data-pub") || article?.getAttribute("data-bible-pub"),
      bible: selectedBible || data?.getAttribute("data-bible") || computedBible,
      docId: data?.getAttribute("data-docid") || classDocId,
      wtLocale: data?.getAttribute("data-wtlocale") || classLocale
    };
  }
  function currentOfficialFinderUrl() {
    return buildOfficialFinderUrl(pageFinderMetadata());
  }
  function currentPreciseStudyUrl() {
    const base = canonicalCurrentPageUrl();
    if (!base) return null;
    return preciseStudyUrl(base, currentCitationTarget().fragment);
  }
  function currentStudyBookmarkCandidate() {
    const support = currentSupport();
    const pageUrl = canonicalCurrentPageUrl();
    const targetUrl = currentPreciseStudyUrl();
    if (!support.supported || !pageUrl || !targetUrl) return null;
    const target = currentCitationTarget();
    const title = pageDocumentTitle();
    return {
      pageUrl,
      targetUrl,
      title,
      reference: target.reference || title
    };
  }
  async function currentStudyBookmarkSaved() {
    const candidate = currentStudyBookmarkCandidate();
    return candidate ? isStudyBookmarkSaved(candidate.targetUrl) : false;
  }
  async function toggleCurrentStudyBookmark() {
    const candidate = currentStudyBookmarkCandidate();
    if (!candidate) return { ok: false, message: t("not_available_page"), saved: false };
    return toggleStudyBookmark(candidate);
  }
  async function copyCurrentCitation() {
    const support = currentSupport();
    if (!support.supported) return { ok: false, message: t("unavailable_here") };
    const target = currentCitationTarget();
    const url = currentPreciseStudyUrl();
    const citation = url ? formatOnlineCitation({
      quote: target.quote,
      reference: target.reference,
      title: pageDocumentTitle(),
      url
    }) : null;
    if (!citation) return { ok: false, message: t("citation_unavailable") };
    const copied = await copy(citation, t("citation_copied"));
    return {
      ok: copied,
      message: copied ? t("citation_copied") : t("copy_failed"),
      ...copied ? { copiedText: citation } : {}
    };
  }
  function showCurrentQr() {
    const url = currentPreciseStudyUrl();
    const svg = url ? qrSvgForStudyUrl(url) : null;
    if (!url || !svg) return { ok: false, message: t("qr_unavailable") };
    teardownQrOverlay();
    qrReturnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const overlay = document.createElement("div");
    overlay.id = QR_OVERLAY_ID;
    overlay.className = "studynav-overlay";
    overlay.setAttribute("data-studynav-owned", "1");
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-labelledby", "studynav-qr-title");
    const panel = document.createElement("div");
    panel.className = "studynav-overlay-panel studynav-qr-panel";
    const head = document.createElement("div");
    head.className = "studynav-panel-head";
    const title = document.createElement("strong");
    title.id = "studynav-qr-title";
    title.textContent = t("qr_title");
    const close = document.createElement("button");
    close.type = "button";
    close.className = "studynav-icon-button";
    close.setAttribute("aria-label", t("close_qr_aria"));
    close.textContent = t("close");
    close.addEventListener("click", teardownQrOverlay);
    head.append(title, close);
    const image = document.createElement("div");
    image.className = "studynav-qr-image";
    image.innerHTML = svg;
    image.querySelector("svg")?.setAttribute("aria-label", t("qr_image_aria"));
    const target = document.createElement("p");
    target.className = "studynav-target-url";
    target.textContent = url;
    const actions = document.createElement("div");
    actions.className = "studynav-panel-actions";
    const copyButton = document.createElement("button");
    copyButton.type = "button";
    copyButton.textContent = t("copy_link");
    copyButton.addEventListener("click", () => void copy(url, t("link_copied")));
    actions.append(copyButton);
    panel.append(head, image, target, actions);
    overlay.append(panel);
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) teardownQrOverlay();
    });
    document.documentElement.appendChild(overlay);
    window.addEventListener("keydown", qrEscapeHandler, true);
    close.focus();
    return { ok: true, message: t("qr_opened") };
  }
  function openOfficialJwLink() {
    const url = currentOfficialFinderUrl();
    if (!url) return { ok: false, message: t("not_available_page") };
    const opened = window.open(url, "_blank", "noopener,noreferrer");
    if (opened) opened.opener = null;
    return { ok: true, message: t("official_link_opened") };
  }
  function mountPalette() {
    if (document.getElementById("studynav-palette")) return;
    const wrap = document.createElement("div");
    wrap.id = "studynav-palette";
    wrap.className = "studynav-palette hidden";
    wrap.setAttribute("data-studynav-owned", "1");
    wrap.innerHTML = `
    <div class="studynav-palette-panel">
      <input id="studynav-palette-input" aria-label="${escapeHtml(t("palette_title"))}" placeholder="${escapeHtml(t("palette_placeholder"))}" />
      <ul id="studynav-palette-results"></ul>
      <div class="studynav-palette-hint">${escapeHtml(t("palette_hint"))}</div>
    </div>`;
    document.documentElement.appendChild(wrap);
    const input = wrap.querySelector("input");
    const list = wrap.querySelector("ul");
    const render = () => {
      const items = resolveQuery(input.value);
      list.innerHTML = items.map((it, i) => `<li data-i="${i}"><strong>${escapeHtml(it.label)}</strong><span>${escapeHtml(it.url)}</span></li>`).join("");
      list._items = items;
    };
    input.addEventListener("input", render);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closePalette();
      if (e.key === "Enter") {
        const items = list._items || resolveQuery(input.value);
        if (items[0]) location.href = items[0].url;
      }
    });
    list.addEventListener("click", (e) => {
      const li = e.target.closest("li");
      if (!li) return;
      const items = list._items || [];
      const it = items[Number(li.getAttribute("data-i"))];
      if (it) location.href = it.url;
    });
    wrap.addEventListener("click", (e) => {
      if (e.target === wrap) closePalette();
    });
  }
  var paletteHotkeyHandler = (e) => {
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === "k") {
      e.preventDefault();
      openPalette();
    }
  };
  function openPalette() {
    const support = currentSupport();
    if (!support.palette) return false;
    mountPalette();
    const wrap = document.getElementById("studynav-palette");
    const input = document.getElementById("studynav-palette-input");
    if (!wrap || !input) return false;
    wrap.classList.remove("hidden");
    input.value = "";
    input.focus();
    input.dispatchEvent(new Event("input"));
    return true;
  }
  function closePalette() {
    document.getElementById("studynav-palette")?.classList.add("hidden");
  }
  function runAltText(articleRoots3) {
    const images = queryWithinRoots(["img", "figure img"], articleRoots3);
    images.forEach((img) => {
      if (img.dataset.snAlt) return;
      const alt = img.getAttribute("alt") || "";
      const cap = img.closest("figure")?.querySelector("figcaption")?.textContent?.trim() || "";
      const text = [alt, cap].filter(Boolean).join(" - ");
      if (!text) return;
      img.dataset.snAlt = "1";
      const div = document.createElement("div");
      div.className = "studynav-alt";
      div.textContent = text;
      div.setAttribute("data-studynav-owned", "1");
      img.insertAdjacentElement("afterend", div);
    });
  }
  function bibleReferenceLabel() {
    const heading = qs("h1");
    const text = (heading?.innerText || heading?.textContent || document.title || "Bible").replace(/\s+\d+:\d+.*$/u, "").trim();
    return text || "Bible";
  }
  function chapterAudioUrl() {
    const media = qsa("audio[src], audio source[src]");
    for (const node of media) {
      const value = node instanceof HTMLAudioElement ? node.currentSrc || node.src : node.getAttribute("src") || "";
      if (/^https:\/\/[^/]*\.?jw-cdn\.org\//i.test(value)) return value;
    }
    return "";
  }
  function embeddedBibleAudioApiUrls() {
    const urls = qsa("[data-bible_audio_data_api], [data-jsonurl]").flatMap((node) => [
      node.getAttribute("data-bible_audio_data_api"),
      node.getAttribute("data-jsonurl")
    ]).filter((value) => !!value);
    return [...new Set(urls)];
  }
  function syncVerseSelectionPresentation() {
    const selected = new Set(selectedVerseIds);
    const anchor = selectedVerseIds.at(-1) || null;
    const firstSelected = selectedVerseIds[0] ? parseBibleVerseId(selectedVerseIds[0]) : null;
    const lastSelected = anchor ? parseBibleVerseId(anchor) : null;
    qsa('.verse[id^="v"]').forEach((element) => {
      const isSelected = selected.has(element.id);
      element.classList.toggle("studynav-verse-selected", isSelected);
      element.classList.toggle("studynav-verse-toolbar-anchor", isSelected && element.id === anchor);
      const toolbar2 = element.querySelector(":scope > .studynav-para-tools");
      if (toolbar2 && element.id !== anchor) {
        delete toolbar2.dataset.snVerseFloating;
        toolbar2.removeAttribute("style");
      }
      toolbar2?.querySelectorAll('[data-single-verse-only="1"]').forEach((control) => {
        control.hidden = selectedVerseIds.length > 1;
      });
      const audioButton = toolbar2?.querySelector(".studynav-verse-audio");
      if (audioButton) {
        const isRangeAnchor = selectedVerseIds.length > 1 && element.id === anchor && firstSelected && lastSelected;
        audioButton.textContent = isRangeAnchor ? t("download_range_audio", [String(firstSelected.verse), String(lastSelected.verse)]) : t("download_audio");
        audioButton.title = isRangeAnchor ? t("download_range_audio_title", [String(firstSelected.verse), String(lastSelected.verse)]) : t("download_audio_title");
      }
      const rangeButton = toolbar2?.querySelector(".studynav-verse-range-control");
      if (rangeButton) {
        const isPicking = verseRangePickAnchorId === element.id;
        rangeButton.textContent = selectedVerseIds.length > 1 ? t("clear_verse_selection") : isPicking ? t("cancel_range_selection") : t("select_several_verses");
        rangeButton.title = selectedVerseIds.length > 1 ? t("clear_verse_selection_title") : isPicking ? t("cancel_range_selection_title") : t("select_several_verses_title");
        rangeButton.setAttribute("aria-pressed", String(isPicking));
      }
    });
    if (selectedVerseIds.length) scheduleVerseToolbarPosition();
    else stopVerseToolbarPositioning();
  }
  var verseSelectionHandler = (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const number = target.closest(".verse .jsHighlightOnly, .verse .verseNum a, .verse .chapterNum a");
    const verse = number?.closest('.verse[id^="v"]');
    const clicked = verse ? parseBibleVerseId(verse.id) : null;
    if (!verse || !clicked) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const rangeAnchorId = verseRangePickAnchorId || selectedVerseIds[0] || null;
    const anchorElement = rangeAnchorId ? document.getElementById(rangeAnchorId) : null;
    const anchor = anchorElement ? parseBibleVerseId(anchorElement.id) : null;
    if ((event.shiftKey || verseRangePickAnchorId) && anchor && anchor.book === clicked.book && anchor.chapter === clicked.chapter) {
      const low = Math.min(anchor.verse, clicked.verse);
      const high = Math.max(anchor.verse, clicked.verse);
      selectedVerseIds = verseElementsInDocumentOrder().filter((candidate) => {
        const current = parseBibleVerseId(candidate.id);
        return !!current && current.book === clicked.book && current.chapter === clicked.chapter && current.verse >= low && current.verse <= high;
      }).map((candidate) => candidate.id);
      verseRangePickAnchorId = null;
      toast(t("verse_range_selected", [String(low), String(high)]));
    } else if (selectedVerseIds.length === 1 && selectedVerseIds[0] === verse.id) {
      selectedVerseIds = [];
      verseRangePickAnchorId = null;
    } else {
      selectedVerseIds = [verse.id];
      verseRangePickAnchorId = null;
    }
    syncVerseSelectionPresentation();
  };
  function syncVerseSelectionListener(enabled3) {
    if (enabled3 === verseSelectionListening) return;
    verseSelectionListening = enabled3;
    if (enabled3) {
      window.addEventListener("click", verseSelectionHandler, true);
      window.addEventListener("resize", scheduleVerseToolbarPosition);
      window.addEventListener("scroll", scheduleVerseToolbarPosition, true);
    } else {
      window.removeEventListener("click", verseSelectionHandler, true);
      stopVerseToolbarPositioning();
      selectedVerseIds = [];
      verseRangePickAnchorId = null;
      qsa(".studynav-verse-selected").forEach((el) => {
        el.classList.remove("studynav-verse-selected");
        el.classList.remove("studynav-verse-toolbar-anchor");
      });
    }
  }
  async function downloadVerseAudio(verseElements, button) {
    const verses = verseElements.map((element) => ({ element, verse: parseBibleVerseId(element.id) })).filter((item) => !!item.verse);
    const first = verses[0];
    const last = verses.at(-1);
    if (!first || !last) return;
    const verseIds = verses.map(({ element }) => element.id);
    const jobId = verseIds.join(":");
    if (verseAudioJobs.has(jobId)) return;
    const resources = [
      ...performance.getEntriesByType("resource").map((entry) => entry.name),
      ...embeddedBibleAudioApiUrls()
    ];
    const apiUrl = findBibleAudioApiUrl(resources, first.element.id, chapterAudioUrl());
    if (!apiUrl) {
      toast(t("chapter_audio_not_ready"));
      return;
    }
    verseAudioJobs.add(jobId);
    button.disabled = true;
    button.dataset.state = "preparing";
    button.dataset.preparingLabel = t("preparing");
    button.setAttribute("aria-busy", "true");
    try {
      const request = {
        type: "DOWNLOAD_VERSE_AUDIO",
        verseIds,
        apiUrl,
        label: bibleReferenceLabel()
      };
      const response = await chrome.runtime.sendMessage(request);
      if (!response || typeof response !== "object" || !("ok" in response) || response.ok !== true || !("base64" in response) || typeof response.base64 !== "string" || !("filename" in response) || typeof response.filename !== "string" || response.base64.length > 34 * 1024 * 1024) {
        const error = response && typeof response === "object" && "error" in response && typeof response.error === "string" ? response.error : t("verse_audio_prepare_failed");
        throw new Error(error);
      }
      const bytes = base64ToBytes(response.base64);
      const wavBuffer = new ArrayBuffer(bytes.byteLength);
      new Uint8Array(wavBuffer).set(bytes);
      const url = URL.createObjectURL(new Blob([wavBuffer], { type: "audio/wav" }));
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = response.filename;
      anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
      const verseLabel = first.verse.verse === last.verse.verse ? String(first.verse.verse) : `${first.verse.verse}\u2013${last.verse.verse}`;
      toast(t("verse_audio_downloaded", [String(first.verse.chapter), verseLabel]));
    } catch (error) {
      toast(error instanceof Error ? error.message : t("verse_audio_download_failed"));
    } finally {
      verseAudioJobs.delete(jobId);
      if (button.isConnected) {
        button.disabled = false;
        delete button.dataset.state;
        delete button.dataset.preparingLabel;
        button.removeAttribute("aria-busy");
      }
    }
  }
  function runCopyAndLinks(articleRoots3, flags2) {
    const hasBibleVerses = articleRoots3.some((root) => !!root.querySelector('.verse[id^="v"]'));
    syncVerseSelectionListener(hasBibleVerses && !!(flags2.verseAudio || flags2.copyText || flags2.parLink || flags2.annotations));
    paragraphNodes(articleRoots3).forEach((el) => {
      const existing = el.querySelector(":scope > .studynav-para-tools");
      if (existing) existing.remove();
      el.dataset.snTools = "1";
      el.classList.add("studynav-para");
      const bar = document.createElement("span");
      bar.className = "studynav-para-tools";
      bar.setAttribute("data-studynav-owned", "1");
      bar.setAttribute("aria-label", t("study_tools_aria"));
      if (flags2.verseAudio && parseBibleVerseId(el.id)) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "studynav-verse-audio";
        button.textContent = t("download_audio");
        button.title = t("download_audio_title");
        button.dataset.verseAudio = el.id;
        button.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          const selected = currentSelectedVerseElements();
          void downloadVerseAudio(selected.length > 1 && selected.includes(el) ? selected : [el], button);
        });
        bar.appendChild(button);
      }
      if ((flags2.verseAudio || flags2.copyText || flags2.parLink) && parseBibleVerseId(el.id)) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "studynav-verse-range-control";
        button.textContent = t("select_several_verses");
        button.title = t("select_several_verses_title");
        button.setAttribute("aria-pressed", "false");
        button.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (selectedVerseIds.length > 1) {
            selectedVerseIds = [];
            verseRangePickAnchorId = null;
            toast(t("verse_selection_cleared"));
          } else if (verseRangePickAnchorId === el.id) {
            verseRangePickAnchorId = null;
            toast(t("range_selection_cancelled"));
          } else {
            selectedVerseIds = [el.id];
            verseRangePickAnchorId = el.id;
            toast(t("select_range_last_verse"));
          }
          syncVerseSelectionPresentation();
        });
        bar.appendChild(button);
      }
      if (flags2.annotations) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = t("mark");
        button.title = t("mark_title");
        if (parseBibleVerseId(el.id)) button.dataset.singleVerseOnly = "1";
        button.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          openAnnotationEditorForElement(el);
        });
        bar.appendChild(button);
      }
      if (flags2.copyText) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = t("copy");
        button.title = t("copy_text_title");
        button.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          const selected = currentSelectedVerseElements();
          copy(selected.length > 1 && selected.includes(el) ? verseRangeText(selected) : textForCopy(el));
        });
        bar.appendChild(button);
      }
      if (flags2.parLink) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = t("link");
        button.title = t("copy_paragraph_link_title");
        button.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          const selected = currentSelectedVerseElements();
          const rangeLink = selected.length > 1 && selected.includes(el) ? preciseLinkForVerseRange(selected) : null;
          copy(rangeLink || deepestLinkFor(el), t("link_copied"));
        });
        bar.appendChild(button);
      }
      if (bar.childElementCount) el.appendChild(bar);
      else bar.remove();
    });
    syncVerseSelectionPresentation();
  }
  function runLangCount(articleRoots3) {
    teardownLanguageBadge();
    const knownSelectCounts = qsa(
      "select#otherAvailLangsChooser, #otherAvailLangs select"
    ).map((select) => select.options.length);
    let count = Math.max(0, ...knownSelectCounts);
    if (!count) {
      const fallbackSelectCounts = qsa(
        'select[name*="lang" i], select[id*="lang" i]'
      ).map((select) => select.options.length);
      count = Math.max(0, ...fallbackSelectCounts);
    }
    const containers = articleRoots3.length ? uniqueElementsForLang([
      ...articleRoots3,
      ...articleRoots3.map((root) => root.closest("main, #content")).filter((root) => !!root)
    ]) : queryWithinRoots(ARTICLE_ROOT_SELECTORS, [document]);
    for (const root of containers) {
      if (count) break;
      const langSelect = qs('select[name*="lang" i], select[id*="lang" i]', root);
      if (langSelect?.options.length) {
        count = langSelect.options.length;
        break;
      }
      const items = qsa('[class*="language"] li, [class*="LanguageList"] li, .mosaicLanguageList li, .languagePicker li', root);
      if (items.length) {
        count = items.length;
        break;
      }
      const candidates = qsa('a[href*="/languages/"], [data-language], [class*="language"] option, .languagePicker option', root);
      if (candidates.length > 5) {
        count = candidates.length;
        break;
      }
      const bodyText = root.innerText || "";
      const match = bodyText.match(/available in\s+(\d+)\s+languages/i);
      if (match) {
        count = Number(match[1]);
        break;
      }
    }
    if (!count) return;
    const badge = document.createElement("div");
    badge.id = "studynav-langcount";
    badge.className = "studynav-langcount";
    badge.textContent = t("languages_count", String(count));
    badge.setAttribute("data-studynav-owned", "1");
    document.documentElement.appendChild(badge);
  }
  function uniqueElementsForLang(nodes) {
    const seen = /* @__PURE__ */ new Set();
    for (const node of nodes) seen.add(node);
    return [...seen];
  }
  function runImgGet(articleRoots3) {
    const images = queryWithinRoots(["img", "figure img"], articleRoots3);
    images.forEach((img) => {
      const next = img.nextElementSibling;
      if (next?.classList.contains("studynav-imgdl")) next.remove();
      img.dataset.snDl = "1";
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "studynav-imgdl";
      btn.innerHTML = `
      <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M12 3v12m0 0 4-4m-4 4-4-4M5 20h14" />
      </svg><span>${escapeHtml(t("download_image"))}</span>`;
      btn.setAttribute("aria-label", t("download_image"));
      btn.title = t("download_image");
      btn.setAttribute("data-studynav-owned", "1");
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        e.stopPropagation();
        const src = img.currentSrc || img.src;
        if (!src) return;
        try {
          const res = await fetch(src);
          if (!res.ok) throw new Error(`Image request failed with ${res.status}`);
          const blob = await res.blob();
          const a = document.createElement("a");
          a.href = URL.createObjectURL(blob);
          a.download = (src.split("/").pop() || "image.jpg").split("?")[0];
          a.click();
          URL.revokeObjectURL(a.href);
          toast(t("image_download_started"));
        } catch {
          const opened = window.open(src, "_blank", "noopener,noreferrer");
          if (opened) opened.opener = null;
        }
      });
      img.insertAdjacentElement("afterend", btn);
    });
  }
  function activeVideo() {
    const vids = qsa("video").filter((video) => !video.closest("[data-studynav-owned]"));
    return vids.find((v) => !v.paused) || vids[0] || null;
  }
  function activePlayableMedia() {
    const media = qsa("video, audio").filter((item) => !item.closest("[data-studynav-owned]"));
    const focused = document.activeElement;
    if (focused instanceof HTMLMediaElement && media.includes(focused)) return focused;
    return media.find((item) => !item.paused) || media.find((item) => item instanceof HTMLVideoElement) || media[0] || null;
  }
  var mediaKeyHandler = (e) => {
    const t2 = e.target;
    if (t2 && (t2.tagName === "INPUT" || t2.tagName === "TEXTAREA" || t2.tagName === "SELECT" || t2.isContentEditable)) return;
    if (e.altKey || e.ctrlKey || e.metaKey) return;
    const v = activePlayableMedia();
    if (!v) return;
    const k = e.key.toLowerCase();
    const handled = k === " " || e.code === "Space" || ["k", "j", "l", "m", "f"].includes(k);
    if (!handled || e.repeat && (k === " " || e.code === "Space" || k === "k")) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    if (k === " " || k === "k") {
      if (v.paused) {
        void v.play().catch(() => {
        });
      } else {
        v.pause();
      }
    } else if (k === "j") {
      v.currentTime = Math.max(0, v.currentTime - 10);
    } else if (k === "l") {
      v.currentTime = Math.min(v.duration || 1e9, v.currentTime + 10);
    } else if (k === "m") {
      v.muted = !v.muted;
    } else if (k === "f") {
      if (document.fullscreenElement) {
        void document.exitFullscreen().catch(() => {
        });
      } else {
        void v.requestFullscreen?.().catch(() => {
        });
      }
    }
  };
  function transcriptDomText() {
    return qsa('[class*="transcript"], [id*="transcript"], [class*="subtitle"]').filter((node) => !node.closest("[data-studynav-owned]")).map((node) => (node.innerText || "").trim()).filter((line) => line.length > 40).join("\n\n");
  }
  function transcriptSourceAvailable() {
    if (transcriptDomText()) return true;
    const video = activeVideo();
    return !!video && (video.textTracks.length > 0 || !!video.querySelector("track[src]"));
  }
  function mediaSource(media) {
    const source = media?.currentSrc || media?.src || "";
    return source && isJwCdnUrl(source) ? source : null;
  }
  function openSecondDisplay() {
    const sourceMedia = activePlayableMedia();
    const source = mediaSource(sourceMedia);
    if (!sourceMedia || !source) {
      toast(t("clip_source_unavailable"));
      return;
    }
    const popup = window.open("about:blank", "studynav-second", "popup=yes,width=960,height=540");
    if (!popup) return;
    popup.opener = null;
    const doc = popup.document;
    doc.title = pageDocumentTitle();
    doc.documentElement.lang = document.documentElement.lang || "en";
    const style = doc.createElement("style");
    style.textContent = `
    :root { color-scheme: dark; background: #080b10; }
    * { box-sizing: border-box; }
    body { min-height: 100vh; margin: 0; display: grid; place-items: center; background: #080b10; }
    video { width: 100vw; height: 100vh; object-fit: contain; background: #000; }
    audio { width: min(760px, calc(100vw - 40px)); }
  `;
    const player = doc.createElement(sourceMedia instanceof HTMLAudioElement ? "audio" : "video");
    player.controls = true;
    player.autoplay = false;
    player.preload = "metadata";
    player.src = source;
    const startTime = sourceMedia.currentTime;
    player.addEventListener("loadedmetadata", () => {
      if (Number.isFinite(startTime)) player.currentTime = Math.min(startTime, player.duration || startTime);
    }, { once: true });
    doc.head.appendChild(style);
    doc.body.replaceChildren(player);
    player.focus();
  }
  function formatClipInput(seconds) {
    const whole = Math.max(0, Math.floor(seconds));
    const hours = Math.floor(whole / 3600);
    const minutes = Math.floor(whole % 3600 / 60);
    const rest = whole % 60;
    return hours ? `${hours}:${String(minutes).padStart(2, "0")}:${String(rest).padStart(2, "0")}` : `${minutes}:${String(rest).padStart(2, "0")}`;
  }
  function waitForClipMediaEvent(media, eventName, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timer = window.setTimeout(() => {
        cleanup();
        reject(new Error(t("clip_video_load_failed")));
      }, timeoutMs);
      const onReady = () => {
        cleanup();
        resolve();
      };
      const onError = () => {
        cleanup();
        reject(new Error(t("clip_video_load_failed")));
      };
      const cleanup = () => {
        clearTimeout(timer);
        media.removeEventListener(eventName, onReady);
        media.removeEventListener("error", onError);
      };
      media.addEventListener(eventName, onReady, { once: true });
      media.addEventListener("error", onError, { once: true });
    });
  }
  async function recordVideoClip(request) {
    if (!("MediaRecorder" in window) || !("captureStream" in HTMLMediaElement.prototype)) {
      throw new Error(t("clip_video_unsupported"));
    }
    const probe = await fetch(request.mediaUrl, {
      cache: "no-store",
      credentials: "omit",
      headers: { Range: "bytes=0-0" }
    });
    if (!probe.ok) throw new Error(t("clip_source_download_failed"));
    if (!isJwCdnUrl(probe.url)) throw new Error(t("chapter_audio_redirected"));
    await probe.body?.cancel();
    const video = document.createElement("video");
    video.crossOrigin = "anonymous";
    video.preload = "metadata";
    video.playsInline = true;
    video.muted = false;
    video.src = request.mediaUrl;
    video.setAttribute("data-studynav-owned", "1");
    Object.assign(video.style, {
      position: "fixed",
      left: "0",
      bottom: "0",
      width: "2px",
      height: "2px",
      opacity: "0.01",
      pointerEvents: "none",
      zIndex: "-1"
    });
    document.documentElement.appendChild(video);
    let audioContext = null;
    let stream = null;
    try {
      if (video.readyState < HTMLMediaElement.HAVE_METADATA) await waitForClipMediaEvent(video, "loadedmetadata", 45e3);
      if (!Number.isFinite(video.duration) || request.endSeconds > video.duration + 0.25) {
        throw new Error(t("clip_outside_media"));
      }
      video.currentTime = request.startSeconds;
      if (video.seeking || Math.abs(video.currentTime - request.startSeconds) > 0.1) {
        await waitForClipMediaEvent(video, "seeked", 3e4);
      }
      if (video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) {
        await waitForClipMediaEvent(video, "loadeddata", 3e4);
      }
      audioContext = new AudioContext();
      const sourceNode = audioContext.createMediaElementSource(video);
      const audioDestination = audioContext.createMediaStreamDestination();
      const silentOutput = audioContext.createGain();
      silentOutput.gain.value = 0;
      sourceNode.connect(audioDestination);
      sourceNode.connect(silentOutput);
      silentOutput.connect(audioContext.destination);
      await audioContext.resume();
      const captured = video.captureStream();
      const videoTrack = captured.getVideoTracks()[0];
      if (!videoTrack) throw new Error(t("clip_video_unsupported"));
      stream = new MediaStream([videoTrack, ...audioDestination.stream.getAudioTracks()]);
      const mimeType = [
        "video/webm;codecs=vp9,opus",
        "video/webm;codecs=vp8,opus",
        "video/webm"
      ].find((candidate) => MediaRecorder.isTypeSupported(candidate));
      if (!mimeType) throw new Error(t("clip_video_unsupported"));
      const recorder = new MediaRecorder(stream, {
        mimeType,
        videoBitsPerSecond: 16e5,
        audioBitsPerSecond: 128e3
      });
      const chunks = [];
      const stopped = new Promise((resolve, reject) => {
        recorder.addEventListener("dataavailable", (event) => {
          if (event.data.size) chunks.push(event.data);
        });
        recorder.addEventListener("stop", () => resolve(), { once: true });
        recorder.addEventListener("error", () => reject(new Error(t("clip_video_recorder_failed"))), { once: true });
      });
      recorder.start(250);
      await video.play();
      await new Promise((resolve, reject) => {
        const deadline = window.setTimeout(() => {
          clearInterval(poll);
          reject(new Error(t("clip_video_timeout")));
        }, Math.ceil((request.endSeconds - request.startSeconds) * 1e3) + 1e4);
        const check = () => {
          if (video.currentTime >= request.endSeconds - 0.03 || video.ended) {
            clearTimeout(deadline);
            clearInterval(poll);
            resolve();
          }
        };
        const poll = window.setInterval(check, 50);
        check();
      });
      video.pause();
      recorder.stop();
      await stopped;
      const blob = new Blob(chunks, { type: mimeType });
      if (blob.size <= 0 || blob.size > 24 * 1024 * 1024) throw new Error(t("clip_video_too_large"));
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = request.filename;
      anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 2e3);
    } finally {
      video.pause();
      video.removeAttribute("src");
      video.load();
      video.remove();
      stream?.getTracks().forEach((track) => track.stop());
      if (audioContext) await audioContext.close();
    }
  }
  function downloadMediaResponse(response, fallbackMessage) {
    if (!response || typeof response !== "object" || !("ok" in response) || response.ok !== true || !("base64" in response) || typeof response.base64 !== "string" || !("filename" in response) || typeof response.filename !== "string" || response.base64.length > 34 * 1024 * 1024) {
      const error = response && typeof response === "object" && "error" in response && typeof response.error === "string" ? response.error : fallbackMessage;
      throw new Error(error);
    }
    const mime = "mime" in response && (response.mime === "audio/wav" || response.mime === "video/webm") ? response.mime : "audio/wav";
    const bytes = base64ToBytes(response.base64);
    const buffer = new ArrayBuffer(bytes.byteLength);
    new Uint8Array(buffer).set(bytes);
    const url = URL.createObjectURL(new Blob([buffer], { type: mime }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = response.filename;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
    return true;
  }
  function openMediaClipPanel() {
    document.getElementById("studynav-clip-panel")?.remove();
    const media = activePlayableMedia();
    if (!media || !mediaSource(media)) {
      toast(t("clip_source_unavailable"));
      return;
    }
    const startAt = Number.isFinite(media.currentTime) ? media.currentTime : 0;
    const duration = Number.isFinite(media.duration) ? media.duration : startAt + 30;
    const endAt = Math.min(duration, startAt + 30);
    const panel = document.createElement("form");
    panel.id = "studynav-clip-panel";
    panel.className = "studynav-clip-panel";
    panel.setAttribute("data-studynav-owned", "1");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", t("media_clip_title"));
    const title = document.createElement("strong");
    title.textContent = t("media_clip_title");
    const fields = document.createElement("div");
    fields.className = "studynav-clip-fields";
    const formatLabel = document.createElement("label");
    formatLabel.textContent = t("clip_format");
    const format = document.createElement("select");
    const audioOption = document.createElement("option");
    audioOption.value = "audio";
    audioOption.textContent = t("clip_format_audio");
    format.appendChild(audioOption);
    if (media instanceof HTMLVideoElement) {
      const videoOption = document.createElement("option");
      videoOption.value = "video";
      videoOption.textContent = t("clip_format_video");
      format.appendChild(videoOption);
    }
    formatLabel.appendChild(format);
    fields.appendChild(formatLabel);
    const createField = (labelText, value) => {
      const label = document.createElement("label");
      label.textContent = labelText;
      const input = document.createElement("input");
      input.type = "text";
      input.inputMode = "decimal";
      input.value = value;
      label.appendChild(input);
      fields.appendChild(label);
      return input;
    };
    const start = createField(t("clip_start"), formatClipInput(startAt));
    const end = createField(t("clip_end"), formatClipInput(endAt));
    const error = document.createElement("p");
    error.className = "studynav-clip-error";
    error.setAttribute("aria-live", "polite");
    const actions = document.createElement("div");
    actions.className = "studynav-clip-actions";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.textContent = t("clip_cancel");
    cancel.addEventListener("click", () => panel.remove());
    const download = document.createElement("button");
    download.type = "submit";
    const updateDownloadLabel = () => {
      download.textContent = format.value === "video" ? t("clip_download_video") : t("clip_download_audio");
    };
    format.addEventListener("change", updateDownloadLabel);
    updateDownloadLabel();
    actions.append(cancel, download);
    panel.append(title, fields, error, actions);
    panel.addEventListener("submit", async (event) => {
      event.preventDefault();
      const startSeconds = parseUserMediaTime(start.value);
      const endSeconds = parseUserMediaTime(end.value);
      if (startSeconds === null || endSeconds === null || endSeconds <= startSeconds) {
        error.textContent = t("clip_invalid_time");
        return;
      }
      const isVideoClip = format.value === "video";
      const maxSeconds = isVideoClip ? MAX_MEDIA_VIDEO_CLIP_SECONDS : MAX_MEDIA_CLIP_SECONDS;
      if (endSeconds - startSeconds > maxSeconds) {
        error.textContent = isVideoClip ? t("clip_video_too_long") : t("clip_too_long");
        return;
      }
      const source = mediaSource(media);
      if (!source) {
        error.textContent = t("clip_source_unavailable");
        return;
      }
      const request = isVideoClip ? {
        type: "DOWNLOAD_MEDIA_VIDEO_CLIP",
        mediaUrl: source,
        startSeconds,
        endSeconds,
        label: pageDocumentTitle()
      } : {
        type: "DOWNLOAD_MEDIA_AUDIO_CLIP",
        mediaUrl: source,
        startSeconds,
        endSeconds,
        label: pageDocumentTitle()
      };
      download.disabled = true;
      cancel.disabled = true;
      panel.setAttribute("aria-busy", "true");
      download.textContent = isVideoClip ? t("clip_recording") : t("clip_preparing");
      try {
        if (request.type === "DOWNLOAD_MEDIA_VIDEO_CLIP") {
          const validated = validateMediaVideoClipRequest(request, window.location.href);
          if (!validated) throw new Error(t("clip_request_rejected"));
          await recordVideoClip(validated);
        } else {
          const response = await chrome.runtime.sendMessage(request);
          downloadMediaResponse(response, t("clip_failed"));
        }
        toast(t("clip_downloaded"));
        panel.remove();
      } catch (caught) {
        error.textContent = caught instanceof Error ? caught.message : t("clip_failed");
      } finally {
        if (download.isConnected) {
          download.disabled = false;
          cancel.disabled = false;
          panel.removeAttribute("aria-busy");
          updateDownloadLabel();
        }
      }
    });
    document.documentElement.appendChild(panel);
    start.focus();
    start.select();
  }
  function syncToolbarButton(bar, id, enabled3, label, action) {
    let button = document.getElementById(id);
    if (!enabled3) {
      button?.remove();
      return;
    }
    if (!button) {
      button = document.createElement("button");
      button.id = id;
      button.type = "button";
    }
    button.textContent = label;
    button.onclick = action;
    bar.appendChild(button);
  }
  function mountMediaToolbar(flags2, mediaSupported) {
    const anyEnabled = flags2.mediaTS || flags2.mediaClip || flags2.sndDisp || flags2.transcCreate || flags2.continueWatching;
    if (!mediaSupported || !anyEnabled) {
      teardownMediaToolbar();
      return null;
    }
    let bar = document.getElementById("studynav-media-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "studynav-media-bar";
      bar.className = "studynav-media-bar";
      bar.setAttribute("data-studynav-owned", "1");
      document.documentElement.appendChild(bar);
    }
    syncToolbarButton(bar, "studynav-copy-page-time", !!flags2.mediaTS, t("copy_page_time"), () => {
      const media = activePlayableMedia();
      const url = canonicalCurrentPageUrl();
      const value = url ? formatPageAndTime(url, media?.currentTime || 0) : null;
      if (value) void copy(value, t("page_time_copied"));
    });
    syncToolbarButton(bar, "studynav-media-clip", !!flags2.mediaClip, t("media_clip"), openMediaClipPanel);
    syncToolbarButton(bar, "studynav-second-display", !!flags2.sndDisp, t("second_display"), openSecondDisplay);
    syncToolbarButton(
      bar,
      "studynav-transcript-button",
      !!flags2.transcCreate && transcriptSourceAvailable(),
      t("transcript"),
      () => void openTranscript()
    );
    return bar;
  }
  async function readTranscriptFromTracks(video) {
    if (!video) return "";
    const tracks = Array.from(video.textTracks || []);
    for (const track of tracks) {
      const priorMode = track.mode;
      try {
        track.mode = "hidden";
        const cues = track.cues;
        if (!cues || !cues.length) continue;
        const lines = [];
        for (let i = 0; i < cues.length; i++) {
          const cue = cues[i];
          lines.push(String(cue.text ?? ""));
        }
        const text = lines.join("\n").trim();
        if (text) return text;
      } catch {
      } finally {
        try {
          track.mode = priorMode;
        } catch {
        }
      }
    }
    return "";
  }
  async function openTranscript() {
    let panel = document.getElementById("studynav-transcript");
    if (!panel) {
      panel = document.createElement("div");
      panel.id = "studynav-transcript";
      panel.className = "studynav-transcript";
      panel.setAttribute("data-studynav-owned", "1");
      panel.innerHTML = `
      <div class="head"><strong>${escapeHtml(t("transcript"))}</strong>
        <input id="studynav-tr-q" aria-label="${escapeHtml(t("transcript_search"))}" placeholder="${escapeHtml(t("transcript_search"))}" />
        <button type="button" id="studynav-tr-dl">${escapeHtml(t("transcript_download"))}</button>
        <button type="button" id="studynav-tr-x" aria-label="${escapeHtml(t("close_transcript_aria"))}">\u2715</button>
      </div>
      <pre id="studynav-tr-body">${escapeHtml(t("loading"))}</pre>`;
      document.documentElement.appendChild(panel);
      panel.querySelector("#studynav-tr-x").addEventListener("click", () => panel.classList.add("hidden"));
      panel.querySelector("#studynav-tr-dl").addEventListener("click", () => {
        const text2 = panel.querySelector("#studynav-tr-body").innerText;
        const blob = new Blob([text2], { type: "text/plain" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "transcript.txt";
        a.click();
        URL.revokeObjectURL(a.href);
      });
      panel.querySelector("#studynav-tr-q").addEventListener("input", (e) => {
        const q = e.target.value.toLowerCase();
        const body2 = panel.querySelector("#studynav-tr-body");
        const full = body2.dataset.full || body2.innerText;
        if (!q) {
          body2.textContent = full;
          return;
        }
        body2.textContent = full.split(/\n/).filter((line) => line.toLowerCase().includes(q)).join("\n") || t("no_matches");
      });
    }
    panel.classList.remove("hidden");
    const body = panel.querySelector("#studynav-tr-body");
    let text = transcriptDomText();
    for (let attempt = 0; !text && attempt < 4; attempt += 1) {
      text = await readTranscriptFromTracks(activeVideo());
      if (!text && attempt < 3) await new Promise((resolve) => window.setTimeout(resolve, 300));
    }
    if (!text) text = t("no_transcript_detected");
    body.dataset.full = text;
    body.textContent = text;
  }
  function applyFeatures(flags2) {
    try {
      const support = currentSupport();
      const plan = deriveFeaturePlan(flags2, support);
      if (plan.teardownAll) {
        teardownFeatures();
        document.documentElement.dataset.studynav = plan.state === "off" ? "off" : "unsupported";
        return;
      }
      if (!flags2.qrShare) teardownQrOverlay();
      if (plan.teardown.languageBadge) teardownLanguageBadge();
      if (plan.teardown.mediaToolbar) teardownMediaToolbar();
      if (plan.teardown.transcript) teardownTranscript();
      if (plan.teardown.altText) teardownAltText();
      if (plan.teardown.copyAndLinks) teardownCopyAndLinks();
      if (plan.teardown.imgGet) teardownImgGet();
      if (plan.teardown.palette) teardownPalette();
      if (plan.teardown.mediaCtrl) teardownMediaCtrl();
      if (plan.teardown.annotations) teardownStudyRuntime();
      if (plan.teardown.continueWatching) teardownContinueWatching();
      markArticleRoots(support.article ? support.articleRoots : []);
      const css = cssFor(plan.styleFlags, location.hostname);
      if (css) ensureStyle(css);
      else removeStyle();
      document.documentElement.classList.add("studynav-on");
      document.documentElement.dataset.studynav = "1";
      if (flags2.annotations || flags2.bookmarks) {
        applyStudyRuntime(support.article ? support.articleRoots : [], {
          annotations: flags2.annotations,
          bookmarks: flags2.bookmarks
        });
      }
      if (flags2.advSearch && support.palette) {
        mountPalette();
        window.addEventListener("keydown", paletteHotkeyHandler, true);
      }
      if (flags2.altText && support.article) runAltText(support.articleRoots);
      if (!flags2.parLink) clearOwnedAnchors();
      if ((flags2.copyText || flags2.parLink || flags2.verseAudio || flags2.annotations) && support.article) {
        runCopyAndLinks(support.articleRoots, flags2);
      }
      if (flags2.langCount && support.language) runLangCount(support.articleRoots);
      if (flags2.imgGet && support.article) runImgGet(support.articleRoots);
      if (flags2.mediaCtrl && support.media) window.addEventListener("keydown", mediaKeyHandler, true);
      const mediaToolbar = mountMediaToolbar(flags2, support.media);
      if (flags2.continueWatching && support.media) {
        applyContinueWatching(
          qsa("video").filter((video) => !video.closest("[data-studynav-owned]")),
          mediaToolbar
        );
      }
    } catch (e) {
      console.warn("StudyNav feature error", e);
    }
  }

  // packages/studynav/src/content.ts
  async function flags() {
    try {
      const f = await chrome.runtime.sendMessage({ type: "GET_FLAGS" });
      if (f && typeof f === "object") return { ...DEFAULT_FLAGS, ...f };
    } catch {
    }
    try {
      const s = await chrome.storage.sync.get({ flags: DEFAULT_FLAGS });
      return { ...DEFAULT_FLAGS, ...s.flags };
    } catch {
      return { ...DEFAULT_FLAGS };
    }
  }
  var latest = DEFAULT_FLAGS;
  var observer = null;
  var navListening = false;
  var routeTimer = null;
  var lastUrl = location.href;
  var reconnectObserver = () => {
    if (!observer) return;
    try {
      observer.observe(document.documentElement, { childList: true, subtree: true });
    } catch {
    }
  };
  var coordinator = createApplyCoordinator({
    clearTimer(id) {
      clearTimeout(id);
    },
    disconnectObserver() {
      observer?.disconnect();
    },
    reconnectObserver,
    runApply() {
      try {
        applyFeatures(latest);
      } catch (e) {
        console.warn("StudyNav applyFeatures", e);
      }
    },
    setTimer(fn, delayMs) {
      return window.setTimeout(fn, delayMs);
    }
  });
  function ensureObservers() {
    if (!observer) {
      observer = new MutationObserver(() => coordinator.schedule());
      reconnectObserver();
    }
    if (!navListening) {
      navListening = true;
      window.addEventListener("popstate", coordinator.schedule);
      window.addEventListener("hashchange", coordinator.schedule);
    }
    if (routeTimer == null) {
      lastUrl = location.href;
      routeTimer = window.setInterval(() => {
        if (location.href === lastUrl) return;
        lastUrl = location.href;
        coordinator.schedule();
      }, 500);
    }
  }
  function stopObservers() {
    coordinator.cancel();
    observer?.disconnect();
    observer = null;
    if (navListening) {
      navListening = false;
      window.removeEventListener("popstate", coordinator.schedule);
      window.removeEventListener("hashchange", coordinator.schedule);
    }
    if (routeTimer != null) {
      clearInterval(routeTimer);
      routeTimer = null;
    }
  }
  async function boot() {
    try {
      latest = await flags();
      if (latest.masterEnabled === false) {
        stopObservers();
        teardownFeatures();
        document.documentElement.dataset.studynav = "off";
        return;
      }
      ensureObservers();
      document.documentElement.dataset.studynav = "1";
      coordinator.flush();
    } catch (e) {
      console.warn("StudyNav boot", e);
      document.documentElement.dataset.studynav = "error";
    }
  }
  boot();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes.flags) boot();
  });
  async function currentPageStatus() {
    const support = currentSupport();
    const verseNodes = Array.from(document.querySelectorAll('.verse[id^="v"]')).filter((node) => !!parseBibleVerseId(node.id));
    const selected = currentSelectedVerseElements().map((node) => parseBibleVerseId(node.id)).filter((verse) => !!verse);
    const kind = verseNodes.length ? "bible" : support.media ? "media" : support.article ? "article" : support.palette ? "search" : "unsupported";
    const bookmarkCandidate = currentStudyBookmarkCandidate();
    return {
      active: latest.masterEnabled !== false && support.supported,
      enabledCount: Object.entries(latest).filter(([key, value]) => key !== "masterEnabled" && value === true).length,
      kind,
      masterEnabled: latest.masterEnabled !== false,
      selectedVerse: selected.length === 1 ? selected[0] : null,
      selectedVerseRange: selected.length > 1 ? {
        chapter: selected[0].chapter,
        startVerse: selected[0].verse,
        endVerse: selected.at(-1).verse
      } : null,
      officialOpenAvailable: !!currentOfficialFinderUrl(),
      bookmarkAvailable: latest.bookmarks && !!bookmarkCandidate,
      bookmarkSaved: latest.bookmarks && bookmarkCandidate ? await currentStudyBookmarkSaved() : false,
      continueWatching: continueWatchingStatus(),
      supported: support.supported,
      verseCount: verseNodes.length
    };
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "GET_STUDYNAV_STATUS") {
      currentPageStatus().then(sendResponse).catch(() => sendResponse({ active: false, supported: false }));
      return true;
    }
    if (msg?.type === "OPEN_PALETTE") {
      if (latest.masterEnabled === false || !latest.advSearch) return;
      try {
        openPalette();
      } catch (e) {
        console.warn("StudyNav palette", e);
      }
      return;
    }
    if (![
      "OPEN_STUDY_PANEL",
      "TOGGLE_STUDY_BOOKMARK",
      "COPY_STUDY_CITATION",
      "SHOW_STUDY_QR",
      "OPEN_OFFICIAL_JW_LINK"
    ].includes(msg?.type)) return;
    (async () => {
      if (latest.masterEnabled === false) return { ok: false, message: t("study_tools_off") };
      if (msg.type === "OPEN_STUDY_PANEL") {
        return latest.annotations || latest.bookmarks ? openStudyPanel() : { ok: false, message: t("study_tools_off") };
      }
      if (msg.type === "TOGGLE_STUDY_BOOKMARK") {
        return latest.bookmarks ? toggleCurrentStudyBookmark() : { ok: false, message: t("bookmarks_off") };
      }
      if (msg.type === "COPY_STUDY_CITATION") {
        return latest.citations ? copyCurrentCitation() : { ok: false, message: t("citations_off") };
      }
      if (msg.type === "SHOW_STUDY_QR") {
        return latest.qrShare ? showCurrentQr() : { ok: false, message: t("qr_sharing_off") };
      }
      return latest.officialOpen ? openOfficialJwLink() : { ok: false, message: t("official_links_off") };
    })().then(sendResponse).catch((error) => {
      console.warn("StudyNav page action", error);
      sendResponse({ ok: false, message: t("action_failed") });
    });
    return true;
  });
})();
/*! Bundled license information:

qr/index.js:
  (*!
  Copyright (c) 2023 Paul Miller (paulmillr.com)
  The library paulmillr-qr is dual-licensed under the Apache 2.0 OR MIT license.
  You can select a license of your choice.
  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at
  
      http://www.apache.org/licenses/LICENSE-2.0
  
  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
  *)
*/
//# sourceMappingURL=content.js.map
