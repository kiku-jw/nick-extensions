"use strict";
(() => {
  // packages/studynav/src/i18n.ts
  var EN_MESSAGES = {
    extension_name: "StudyNav \u2014 Unofficial Study Tools",
    extension_short_name: "StudyNav",
    extension_description: "Unofficial local study helpers for public JW.org pages. No telemetry or uploads; not affiliated with Jehovah\u2019s Witnesses.",
    command_adv_search: "Open the StudyNav command palette",
    popup_header_title: "StudyNav",
    popup_header_subtitle: "Unofficial \xB7 local processing \xB7 supported pages only",
    tools: "Tools",
    tools_title: "Enable or disable all StudyNav tools",
    tools_aria: "Enable all StudyNav tools",
    checking_page: "Checking this page\u2026",
    open_supported_page: "Open a supported JW.org page to use study tools.",
    page_tools: "Page tools",
    study_library: "Study library",
    save_place: "Save place",
    remove_saved_place: "Remove saved place",
    copy_citation: "Copy citation",
    show_qr: "Show QR",
    open_official_link: "Open clean publication link",
    image_search: "Search JW images with Google",
    image_search_placeholder: "What picture do you need?",
    image_search_external: "Opens an external Google search",
    reset_defaults: "Reset recommended defaults",
    defaults_restored: "Recommended defaults restored",
    what_it_gives_you: "What it gives you",
    guide_bible_label: "Bible:",
    guide_bible_text: "select one verse, or choose Select several and then the last verse. Download audio saves the selection as one WAV file.",
    guide_study_label: "Study:",
    guide_study_text: "select text to highlight it, add a note, or save an exact place.",
    guide_articles_label: "Articles:",
    guide_articles_text: "hover or focus text for Copy, Link, and Mark actions.",
    guide_media_label: "Media:",
    guide_media_text: "use the floating controls for playback, media segments, resume, and available captions.",
    feature_settings: "Feature settings",
    filter_features: "Filter features",
    find_setting: "Find a setting\u2026",
    footer_quick_search: "Quick search: Ctrl/Cmd+Shift+K",
    footer_privacy: "No telemetry \xB7 no uploads",
    group_study: "Study & sharing",
    group_core: "Bible & articles",
    group_layout: "Reading layout",
    group_media: "Video & audio",
    enabled_count: "$1 on",
    status_tools_off_title: "Study tools are off",
    status_tools_off_hint: "Turn on Tools above to restore helpers on supported pages.",
    status_unavailable_title: "No tools on this page",
    status_unavailable_hint: "Open a JW.org Bible chapter, library article, or media page.",
    status_bible_title: "Ready on this Bible chapter",
    status_bible_selected: "Verse $1:$2 is selected. Choose Select several to include the verses that follow.",
    status_bible_range: "Verses $1:$2\u2013$3 are selected. Copy, Link, and Download audio use the whole range.",
    status_bible_hint: "Select a verse number for text, a direct link, or audio. Select several consecutive verses when needed.",
    status_media_title: "Ready on this media page",
    status_media_hint: "Use the floating controls for playback, media segments, and captions when present.",
    status_article_title: "Ready on this article",
    status_article_hint: "Hover or focus article text for Copy and Link. Optional image downloads are in Feature settings.",
    status_palette_title: "Quick search is ready",
    status_palette_hint: "Press Ctrl/Cmd+Shift+K to find a publication or DOCID.",
    working: "Working\u2026",
    preparing: "Preparing\u2026",
    done: "Done",
    unavailable_here: "Unavailable here",
    no_active_tab: "No active tab",
    place_saved: "Place saved",
    saved_place_removed: "Saved place removed",
    bookmark_limit: "The local saved-place limit has been reached.",
    remove_saved_place_confirm: "Remove this saved place?",
    feature_annotations_name: "Highlights, notes & tags",
    feature_annotations_blurb: "Keep six-color highlights and searchable notes locally",
    feature_bookmarks_name: "Save a place to return to",
    feature_bookmarks_blurb: "Keep an exact page, paragraph, verse, or verse range in the Study library",
    feature_citations_name: "Copy a quote with its source",
    feature_citations_blurb: "Copy selected words with the publication title, reference, and direct JW link",
    feature_qrShare_name: "Show QR for this page",
    feature_qrShare_blurb: "Create a local QR code for the precise official page link",
    feature_officialOpen_name: "Clean publication link",
    feature_officialOpen_blurb: "Open the same publication through JW.org without extra address parameters",
    feature_verseAudio_name: "Download audio for selected verses",
    feature_verseAudio_blurb: "Save one verse or several consecutive verses as one WAV file",
    feature_copyText_name: "Copy clean text",
    feature_copyText_blurb: "Copy without verse numbers, reference letters, or StudyNav controls",
    feature_parLink_name: "Copy precise link",
    feature_parLink_blurb: "Copy a direct link to a paragraph, verse, or verse range",
    feature_advSearch_name: "Search by publication code",
    feature_advSearch_blurb: "Open the existing JW search for a publication code or document number",
    feature_altText_name: "Image descriptions",
    feature_altText_blurb: "Show alt text and captions below article images",
    feature_imgGet_name: "Download article images",
    feature_imgGet_blurb: "Add a compact download button beside article images",
    feature_langCount_name: "Available languages",
    feature_langCount_blurb: "Show the number of languages for an article",
    feature_actionBar_name: "Keep page header visible",
    feature_actionBar_blurb: "Keep the JW.org header in view while scrolling",
    feature_expandWidth_name: "Wider reading column",
    feature_expandWidth_blurb: "Use more of the window for article text",
    feature_cstblView_name: "Clearer tables",
    feature_cstblView_blurb: "Add spacing and row separation to article tables",
    feature_mediaPlayerUI_name: "Remove video shading",
    feature_mediaPlayerUI_blurb: "Keep the picture clear when the player controls appear",
    feature_customSub_name: "Larger subtitles",
    feature_customSub_blurb: "Increase subtitle size and background contrast",
    feature_mediaCtrl_name: "Media keyboard shortcuts",
    feature_mediaCtrl_blurb: "Use Space/K/J/L/F/M while watching media",
    feature_mediaTS_name: "Copy page and time",
    feature_mediaTS_blurb: "Copy the page link together with the current playback time",
    feature_mediaClip_name: "Download an audio or video segment",
    feature_mediaClip_blurb: "Enter start and end times, then save audio as WAV or video as WebM",
    feature_continueWatching_name: "Continue watching",
    feature_continueWatching_blurb: "Keep video progress locally and resume only when asked",
    feature_sndDisp_name: "Open second display",
    feature_sndDisp_blurb: "Open the current media in a popup window",
    feature_transcCreate_name: "Search available captions",
    feature_transcCreate_blurb: "Open a searchable panel only when text is present",
    copied: "Copied",
    copy_failed: "Copy failed",
    study_tools_off: "Study tools are off",
    annotations_off: "Highlights and notes are off",
    bookmarks_off: "Saved places are off",
    citations_off: "Citations are off",
    qr_sharing_off: "QR sharing is off",
    official_links_off: "Publication links are off",
    action_failed: "Action failed",
    citation_unavailable: "Citation unavailable",
    citation_copied: "Citation copied",
    qr_unavailable: "QR unavailable",
    qr_title: "QR for this page",
    close: "Close",
    close_qr_aria: "Close QR",
    qr_image_aria: "QR code for the displayed JW link",
    copy_link: "Copy link",
    link_copied: "Link copied",
    qr_opened: "QR opened",
    not_available_page: "Not available on this page",
    official_link_opened: "Clean publication link opened",
    palette_title: "Search by publication code",
    palette_placeholder: "Mnemonic / DOCID (for example w25.03, lff, wp24.01, mwb25.01)",
    palette_hint: "Enter to open \xB7 Esc to close \xB7 Unofficial StudyNav",
    study_tools_aria: "Study tools",
    download_audio: "Download audio",
    download_audio_title: "Download only this verse as audio",
    download_range_audio: "Download audio $1\u2013$2",
    download_range_audio_title: "Download verses $1\u2013$2 as one audio file",
    select_several_verses: "Select several",
    select_several_verses_title: "Choose the last verse in a consecutive range",
    cancel_range_selection: "Cancel range",
    cancel_range_selection_title: "Stop choosing a verse range",
    clear_verse_selection: "Clear selection",
    clear_verse_selection_title: "Clear the selected verse range",
    select_range_last_verse: "Now select the last verse.",
    verse_range_selected: "Verses $1\u2013$2 selected.",
    range_selection_cancelled: "Range selection cancelled",
    verse_selection_cleared: "Verse selection cleared",
    chapter_audio_not_ready: "Chapter audio is not ready. Open Play Audio once, then try again.",
    verse_audio_prepare_failed: "Verse audio could not be prepared.",
    verse_audio_downloaded: "Downloaded $1:$2 audio",
    verse_audio_download_failed: "Verse audio download failed.",
    mark: "Mark",
    mark_title: "Highlight this paragraph or verse and optionally add a private note",
    copy: "Copy",
    copy_text_title: "Copy without verse numbers, reference letters, or StudyNav controls",
    link: "Link",
    copy_paragraph_link_title: "Copy a link to this paragraph, verse, or selected verse range",
    languages_count: "$1 languages",
    download_image: "Download image",
    image_download_started: "Image download started",
    copy_page_time: "Copy page + time",
    page_time_copied: "Page link and time copied",
    media_clip: "Media segment",
    media_clip_title: "Download an audio or video segment",
    clip_format: "Format",
    clip_format_audio: "Audio (.wav) \xB7 up to 2 minutes",
    clip_format_video: "Video (.webm) \xB7 up to 1 minute",
    clip_start: "Start",
    clip_end: "End",
    clip_download_audio: "Download WAV",
    clip_download_video: "Record WebM",
    clip_cancel: "Cancel",
    clip_invalid_time: "Enter times as M:SS or H:MM:SS. The end must be after the start.",
    clip_too_long: "Choose a segment no longer than 2 minutes.",
    clip_video_too_long: "Choose a video segment no longer than 1 minute.",
    clip_preparing: "Preparing audio segment\u2026",
    clip_recording: "Recording video segment in real time\u2026",
    clip_downloaded: "Media segment downloaded",
    clip_failed: "The requested media segment could not be created.",
    clip_video_failed: "The video segment could not be created.",
    clip_video_recorder_failed: "The browser recorder failed while creating the video segment.",
    clip_video_timeout: "The video did not advance while the segment was being recorded.",
    clip_video_load_failed: "The official video could not be loaded for recording.",
    clip_video_unsupported: "This browser cannot record a video segment from this player.",
    clip_video_too_large: "The recorded video segment is too large to download safely.",
    clip_source_unavailable: "Play the media once so its source is available, then try again.",
    clip_request_rejected: "This media-segment request was rejected.",
    clip_source_download_failed: "The official media file could not be downloaded.",
    clip_source_too_large: "This media file is too large to process safely.",
    clip_outside_media: "The selected times are outside this media file.",
    second_display: "Second display",
    transcript: "Transcript",
    transcript_search: "Search\u2026",
    transcript_download: "Download .txt",
    close_transcript_aria: "Close transcript",
    loading: "Loading\u2026",
    no_matches: "(no matches)",
    no_transcript_detected: "No transcript text was detected on this page. If captions load later, reopen this panel.",
    annotation_limit: "The local annotation limit has been reached.",
    selection_cannot_save: "This selection cannot be saved.",
    note_updated: "Note updated",
    highlight_saved: "Highlight saved locally",
    select_one_paragraph: "Select text within one paragraph or verse.",
    select_character_count: "Select between 1 and $1 characters.",
    highlight_color_aria: "$1 highlight",
    reattach_note_aria: "Reattach note",
    highlight_selection_aria: "Highlight selected text",
    reattach_here: "Reattach here",
    note_missing: "That note no longer exists.",
    reattach_source_first: "Return to the note\u2019s source page before reattaching it.",
    reattach_cancelled: "Reattach cancelled",
    reattach_instruction: "Select the replacement text, then choose Reattach here.",
    cancel: "Cancel",
    add_note: "Add note",
    edit_highlight: "Edit highlight",
    new_highlight: "New highlight",
    close_highlight_editor_aria: "Close highlight editor",
    highlight_color: "Highlight color",
    color_yellow: "Yellow",
    color_green: "Green",
    color_blue: "Blue",
    color_pink: "Pink",
    color_purple: "Purple",
    color_orange: "Orange",
    page_notes: "Notes on this page",
    open_all_notes: "Open all notes",
    note: "Note",
    write_private_note: "Write a private note\u2026",
    tags: "Tags",
    tags_placeholder: "study, family, review",
    save_locally: "Save locally",
    tags_error: "Use at most 20 short, comma-separated tags.",
    paragraph_mark_unreliable: "This paragraph cannot be marked reliably.",
    needs_attention: "Needs attention",
    delete_highlight_confirm: "Delete this local highlight and note?",
    highlight_deleted: "Highlight deleted",
    locate: "Locate",
    open_page: "Open page",
    edit: "Edit",
    delete: "Delete",
    reattach: "Reattach",
    no_notes_filtered: "No notes match these filters.",
    no_notes_yet: "Select text on an article or verse to create your first highlight.",
    notes_count_one: "$1 note",
    notes_count_many: "$1 notes",
    study_export_failed: "Study data could not be exported.",
    study_backup_downloaded: "Study backup downloaded",
    backup_too_large: "Backup is larger than 5 MB.",
    backup_invalid: "That is not a valid StudyNav backup.",
    import_summary: "Import: $1 added, $2 updated, $3 ignored, $4 rejected",
    notes_tab: "Notes",
    saved_places_tab: "Saved places",
    this_page: "This page",
    all_notes: "All notes",
    all_pages: "All pages",
    search_notes: "Search study notes",
    search_notes_placeholder: "Search quote, note, or tag\u2026",
    search_saved_places: "Search saved places",
    filter_notes_tag: "Filter study notes by tag",
    all_tags: "All tags",
    export_json: "Export JSON",
    import_json: "Import JSON",
    study_library_opened: "Study library opened",
    close_study_library_aria: "Close study library",
    saved_places_count_one: "$1 saved place",
    saved_places_count_many: "$1 saved places",
    no_saved_places_filtered: "No saved places match these filters.",
    no_saved_places_yet: "Save a page, paragraph, or verse to return to it quickly.",
    open_saved_place: "Open",
    remove_saved_place_action: "Remove",
    local_study_data_invalid: "Local study data is invalid and was left unchanged.",
    study_data_validation_failed: "Study data update failed validation.",
    study_data_save_failed: "Study data could not be saved.",
    migration_save_failed: "Migrated study data could not be saved.",
    video_progress_save_failed: "Video progress could not be saved.",
    resume_at: "Resume at $1",
    resume_title: "Seek to saved local progress without starting playback",
    ready_at: "Ready at $1. Press play when you want.",
    resume_wait_loading: "The video must finish loading before it can resume.",
    verse_request_rejected: "This verse audio request was rejected.",
    verse_job_busy: "Another media clip is already being prepared.",
    verse_processing_failed: "Verse audio processing failed.",
    verse_page_unverified: "The Bible page could not be verified.",
    verse_request_invalid: "The selected verse audio request is not valid.",
    verse_timing_unavailable: "The official verse timing data is unavailable.",
    verse_timing_redirected: "The official verse timing request was redirected unexpectedly.",
    verse_timing_missing: "No official audio timing was found for this verse.",
    chapter_audio_download_failed: "The official chapter audio could not be downloaded.",
    chapter_audio_redirected: "The official chapter audio was redirected unexpectedly.",
    decoded_audio_invalid: "Decoded chapter audio is invalid.",
    verse_outside_audio: "The selected verse is outside the chapter audio.",
    verse_audio_too_large: "The selected verse audio is too large to download safely.",
    chapter_audio_too_large: "The chapter audio is too large to process safely.",
    chapter_audio_size_mismatch: "The chapter audio size does not match its official metadata."
  };
  function fallbackFormat(message, substitutions) {
    const values = substitutions === void 0 ? [] : Array.isArray(substitutions) ? substitutions : [substitutions];
    return values.reduce((result, value, index) => result.replaceAll(`$${index + 1}`, value), message);
  }
  function t(key, substitutions) {
    try {
      if (typeof chrome !== "undefined" && chrome.i18n?.getMessage) {
        const translated = chrome.i18n.getMessage(key, substitutions);
        if (translated) return translated;
      }
    } catch {
    }
    return fallbackFormat(EN_MESSAGES[key], substitutions);
  }

  // packages/studynav/src/page-origin.ts
  var STUDYNAV_PAGE_HOSTS = ["jw.org", "www.jw.org", "wol.jw.org"];
  var allowedHosts = new Set(STUDYNAV_PAGE_HOSTS);
  function isAllowedStudyNavHostname(hostname) {
    return allowedHosts.has(String(hostname || "").toLowerCase());
  }
  function isAllowedStudyNavPageUrl(value) {
    try {
      const url = typeof value === "string" ? new URL(value) : value;
      return url.protocol === "https:" && !url.username && !url.password && !url.port && isAllowedStudyNavHostname(url.hostname);
    } catch {
      return false;
    }
  }

  // packages/studynav/src/verse-audio.ts
  var MEDIA_API_HOST = "b.jw-cdn.org";
  var MEDIA_API_PATH = "/apis/pub-media/getpubmedialinks";
  var MAX_CHAPTER_AUDIO_BYTES = 64 * 1024 * 1024;
  var MAX_VERSE_SECONDS = 120;
  var MAX_VERSES_PER_CLIP = 200;
  var MAX_WAV_BYTES = 24 * 1024 * 1024;
  var MAX_MEDIA_CLIP_SECONDS = 120;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function finiteNumber(value) {
    const number = typeof value === "number" ? value : Number(value);
    return Number.isFinite(number) ? number : null;
  }
  function parseBibleVerseId(value) {
    const match = /^v([1-9]\d?)(\d{3})(\d{3})$/.exec(value);
    if (!match) return null;
    const verse = {
      book: Number(match[1]),
      chapter: Number(match[2]),
      verse: Number(match[3])
    };
    if (verse.book < 1 || verse.book > 66 || verse.chapter < 1 || verse.chapter > 150 || verse.verse < 1 || verse.verse > 200) return null;
    return verse;
  }
  function isJwCdnUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (url.hostname === "jw-cdn.org" || url.hostname.endsWith(".jw-cdn.org"));
    } catch {
      return false;
    }
  }
  var BIBLE_CHAPTER_PATH_RES = [
    /^\/[a-z]{2}(?:-[a-z]+)?\/library\/bible\/[^/]+\/books\/[^/]+\/(\d+)\/?$/i,
    /^\/[a-z]{2}(?:-[a-z]+)?\/(?:biblioteka|biblioteca|bibliothek|bibliotheque|bibliotek)\/[^/]+\/[^/]+\/(?:books|knigi|libros|livres|buecher|libri)\/[^/]+\/(\d+)\/?$/i,
    /^\/ru\/библиотека\/библия\/(?:nwt\/(?:содержание|книги)|учебная-библия\/книги)\/[^/]+\/(\d+)\/?$/iu,
    /^\/uk\/бібліотека\/біблія\/(?:nwt|навчальне-видання-біблії)\/книги\/[^/]+\/(\d+)\/?$/iu
  ];
  function parseBibleChapterFromPath(pathname) {
    let decodedPath;
    try {
      decodedPath = decodeURIComponent(pathname).normalize("NFC");
    } catch {
      return null;
    }
    for (const pattern of BIBLE_CHAPTER_PATH_RES) {
      const match = pattern.exec(decodedPath);
      if (match) return Number(match[1]);
    }
    return null;
  }
  function mediaApiShell(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.hostname !== MEDIA_API_HOST || url.pathname.toLowerCase() !== MEDIA_API_PATH || url.username || url.password) return null;
      if (url.searchParams.get("output")?.toLowerCase() !== "json") return null;
      if (url.searchParams.get("fileformat")?.toUpperCase() !== "MP3") return null;
      return url;
    } catch {
      return null;
    }
  }
  function validateMediaApiUrl(value, verse) {
    const url = mediaApiShell(value);
    if (!url) return null;
    if (Number(url.searchParams.get("booknum")) !== verse.book) return null;
    if (Number(url.searchParams.get("track")) !== verse.chapter) return null;
    if (!url.searchParams.get("langwritten") || !url.searchParams.get("txtCMSLang")) return null;
    const pub = url.searchParams.get("pub");
    if (pub !== "nwt") return null;
    return url.href;
  }
  function validateVerseAudioRequest(value, senderUrl) {
    if (!isRecord(value) || value.type !== "DOWNLOAD_VERSE_AUDIO") return null;
    if (!Array.isArray(value.verseIds) || typeof value.apiUrl !== "string" || typeof value.label !== "string") return null;
    if (value.verseIds.length < 1 || value.verseIds.length > MAX_VERSES_PER_CLIP || value.verseIds.some((verseId) => typeof verseId !== "string")) return null;
    const parsed = value.verseIds.map((verseId) => parseBibleVerseId(verseId));
    if (parsed.some((verse) => verse === null)) return null;
    const verses = parsed.sort((left, right) => left.verse - right.verse);
    const first = verses[0];
    if (!first) return null;
    if (verses.some(
      (verse, index) => verse.book !== first.book || verse.chapter !== first.chapter || verse.verse !== first.verse + index
    )) return null;
    const verseIds = verses.map((verse) => `v${verse.book}${String(verse.chapter).padStart(3, "0")}${String(verse.verse).padStart(3, "0")}`);
    try {
      const page = new URL(senderUrl);
      const chapter = parseBibleChapterFromPath(page.pathname);
      if (!isAllowedStudyNavPageUrl(page) || chapter === null) return null;
      if (chapter !== first.chapter) return null;
    } catch {
      return null;
    }
    const apiUrl = validateMediaApiUrl(value.apiUrl, first);
    if (!apiUrl) return null;
    return {
      verses,
      verseIds,
      apiUrl,
      label: value.label.slice(0, 120)
    };
  }
  function validateMediaAudioClipRequest(value, senderUrl) {
    if (!isRecord(value) || value.type !== "DOWNLOAD_MEDIA_AUDIO_CLIP") return null;
    if (typeof value.mediaUrl !== "string" || typeof value.label !== "string") return null;
    const startSeconds = finiteNumber(value.startSeconds);
    const endSeconds = finiteNumber(value.endSeconds);
    if (startSeconds === null || endSeconds === null || startSeconds < 0 || endSeconds <= startSeconds || endSeconds - startSeconds > MAX_MEDIA_CLIP_SECONDS || endSeconds > 36e3 || !isJwCdnUrl(value.mediaUrl)) return null;
    try {
      const sender = new URL(senderUrl);
      if (!isAllowedStudyNavPageUrl(sender)) return null;
    } catch {
      return null;
    }
    const label = safeFilenamePart(value.label);
    const startLabel = Math.floor(startSeconds).toString().padStart(4, "0");
    const endLabel = Math.floor(endSeconds).toString().padStart(4, "0");
    return {
      type: "DOWNLOAD_MEDIA_AUDIO_CLIP",
      mediaUrl: value.mediaUrl,
      startSeconds,
      endSeconds,
      label,
      filename: `${label}_${startLabel}-${endLabel}.wav`
    };
  }
  function parseMediaClock(value) {
    if (typeof value !== "string") return null;
    const match = /^(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?$/.exec(value);
    if (!match) return null;
    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    const seconds = Number(match[3]);
    if (minutes > 59 || seconds > 59) return null;
    const milliseconds = Number((match[4] || "").padEnd(3, "0"));
    return hours * 3600 + minutes * 60 + seconds + milliseconds / 1e3;
  }
  function safeFilenamePart(value) {
    return value.normalize("NFKC").replace(/[\u0000-\u001f\u007f/\\?%*:|"<>]+/g, " ").replace(/\s+/g, " ").trim().replace(/[. ]+$/g, "").slice(0, 80) || "Bible";
  }
  function selectVerseClipSource(payload, verses, label) {
    if (!isRecord(payload) || !isRecord(payload.files) || !verses.length) return null;
    const orderedVerses = [...verses].sort((left, right) => left.verse - right.verse);
    const firstVerse = orderedVerses[0];
    const lastVerse = orderedVerses.at(-1);
    if (!firstVerse || !lastVerse || orderedVerses.length > MAX_VERSES_PER_CLIP || orderedVerses.some(
      (verse, index) => verse.book !== firstVerse.book || verse.chapter !== firstVerse.chapter || verse.verse !== firstVerse.verse + index
    )) return null;
    for (const languageFiles of Object.values(payload.files)) {
      if (!isRecord(languageFiles) || !Array.isArray(languageFiles.MP3)) continue;
      for (const item of languageFiles.MP3) {
        if (!isRecord(item) || !isRecord(item.file) || !isRecord(item.markers)) continue;
        if (Number(item.markers.bibleBookNumber) !== firstVerse.book || Number(item.markers.bibleBookChapter) !== firstVerse.chapter || !Array.isArray(item.markers.markers)) continue;
        if (typeof item.file.url !== "string" || !isJwCdnUrl(item.file.url)) continue;
        const markerList = item.markers.markers;
        const trackDuration = finiteNumber(item.duration);
        const expectedBytes = finiteNumber(item.filesize);
        if (expectedBytes !== null && (expectedBytes <= 0 || expectedBytes > MAX_CHAPTER_AUDIO_BYTES)) continue;
        const selectedMarkers = orderedVerses.map((verse) => {
          const matches = markerList.filter((candidate) => isRecord(candidate) && Number(candidate.verseNumber) === verse.verse);
          if (matches.length !== 1 || !isRecord(matches[0])) return null;
          const startSeconds2 = parseMediaClock(matches[0].startTime);
          const durationSeconds2 = parseMediaClock(matches[0].duration);
          if (startSeconds2 === null || durationSeconds2 === null || startSeconds2 < 0 || durationSeconds2 <= 0 || durationSeconds2 > MAX_VERSE_SECONDS || trackDuration !== null && startSeconds2 + durationSeconds2 > trackDuration + 1) return null;
          return { startSeconds: startSeconds2, durationSeconds: durationSeconds2 };
        });
        if (selectedMarkers.some((marker) => marker === null)) continue;
        const markers = selectedMarkers;
        if (markers.some((marker, index) => index > 0 && marker.startSeconds <= markers[index - 1].startSeconds)) {
          continue;
        }
        const startSeconds = markers[0].startSeconds;
        const endSeconds = markers.at(-1).startSeconds + markers.at(-1).durationSeconds;
        const durationSeconds = markers.length === 1 ? markers[0].durationSeconds : endSeconds - startSeconds;
        if (durationSeconds <= 0 || durationSeconds > MAX_MEDIA_CLIP_SECONDS) continue;
        const verseSuffix = firstVerse.verse === lastVerse.verse ? String(firstVerse.verse) : `${firstVerse.verse}-${lastVerse.verse}`;
        return {
          audioUrl: item.file.url,
          startSeconds,
          durationSeconds,
          filename: `${safeFilenamePart(label)}_${firstVerse.chapter}_${verseSuffix}.wav`,
          expectedBytes
        };
      }
    }
    return null;
  }
  function writeAscii(view, offset, value) {
    for (let index = 0; index < value.length; index++) {
      view.setUint8(offset + index, value.charCodeAt(index));
    }
  }
  function encodeWavClip(buffer, startSeconds, durationSeconds) {
    if (!Number.isFinite(buffer.sampleRate) || buffer.sampleRate < 8e3 || buffer.sampleRate > 192e3 || !Number.isInteger(buffer.length) || buffer.length <= 0 || !Number.isInteger(buffer.numberOfChannels) || buffer.numberOfChannels <= 0) throw new Error(t("decoded_audio_invalid"));
    const channelCount = Math.min(2, buffer.numberOfChannels);
    const startFrame = Math.max(0, Math.floor(startSeconds * buffer.sampleRate));
    const requestedFrames = Math.ceil(durationSeconds * buffer.sampleRate);
    const frameCount = Math.min(requestedFrames, buffer.length - startFrame);
    if (frameCount <= 0) throw new Error(t("verse_outside_audio"));
    const dataBytes = frameCount * channelCount * 2;
    const totalBytes = 44 + dataBytes;
    if (totalBytes > MAX_WAV_BYTES) throw new Error(t("verse_audio_too_large"));
    const output = new Uint8Array(totalBytes);
    const view = new DataView(output.buffer);
    writeAscii(view, 0, "RIFF");
    view.setUint32(4, totalBytes - 8, true);
    writeAscii(view, 8, "WAVE");
    writeAscii(view, 12, "fmt ");
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, channelCount, true);
    view.setUint32(24, buffer.sampleRate, true);
    view.setUint32(28, buffer.sampleRate * channelCount * 2, true);
    view.setUint16(32, channelCount * 2, true);
    view.setUint16(34, 16, true);
    writeAscii(view, 36, "data");
    view.setUint32(40, dataBytes, true);
    const channels = Array.from({ length: channelCount }, (_, channel) => buffer.getChannelData(channel));
    let offset = 44;
    for (let frame = 0; frame < frameCount; frame++) {
      for (let channel = 0; channel < channelCount; channel++) {
        const sample = Math.max(-1, Math.min(1, channels[channel][startFrame + frame] || 0));
        view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true);
        offset += 2;
      }
    }
    return output;
  }
  function bytesToBase64(bytes) {
    let binary = "";
    const chunkSize = 32768;
    for (let offset = 0; offset < bytes.length; offset += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
    }
    return btoa(binary);
  }
  function assertChapterAudioSize(actualBytes, expectedBytes) {
    if (actualBytes <= 0 || actualBytes > MAX_CHAPTER_AUDIO_BYTES) {
      throw new Error(t("chapter_audio_too_large"));
    }
    if (expectedBytes !== null && actualBytes > Math.max(expectedBytes * 1.05, expectedBytes + 4096)) {
      throw new Error(t("chapter_audio_size_mismatch"));
    }
  }
  function assertMediaClipSourceSize(actualBytes) {
    if (!Number.isFinite(actualBytes) || actualBytes <= 0 || actualBytes > MAX_CHAPTER_AUDIO_BYTES) {
      throw new Error(t("clip_source_too_large"));
    }
  }

  // packages/studynav/src/offscreen.ts
  var busy = false;
  async function fetchWithTimeout(url, timeoutMs) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, {
        cache: "no-store",
        credentials: "omit",
        signal: controller.signal
      });
    } finally {
      clearTimeout(timer);
    }
  }
  async function processMediaAudioClip(message) {
    if (typeof message.senderUrl !== "string") throw new Error(t("verse_page_unverified"));
    const request = validateMediaAudioClipRequest(message.request, message.senderUrl);
    if (!request) throw new Error(t("clip_request_rejected"));
    const response = await fetchWithTimeout(request.mediaUrl, 45e3);
    if (!response.ok) throw new Error(t("clip_source_download_failed"));
    if (!isJwCdnUrl(response.url)) throw new Error(t("chapter_audio_redirected"));
    const declaredLength = Number(response.headers.get("content-length"));
    if (Number.isFinite(declaredLength) && declaredLength > 0) assertMediaClipSourceSize(declaredLength);
    const bytes = await response.arrayBuffer();
    assertMediaClipSourceSize(bytes.byteLength);
    const audioContext = new AudioContext();
    try {
      const decoded = await audioContext.decodeAudioData(bytes);
      if (!Number.isFinite(decoded.duration) || request.endSeconds > decoded.duration + 0.25) {
        throw new Error(t("clip_outside_media"));
      }
      const wav = encodeWavClip(decoded, request.startSeconds, request.endSeconds - request.startSeconds);
      return {
        ok: true,
        base64: bytesToBase64(wav),
        bytes: wav.byteLength,
        durationSeconds: request.endSeconds - request.startSeconds,
        filename: request.filename,
        mime: "audio/wav"
      };
    } finally {
      await audioContext.close();
    }
  }
  async function processVerseAudio(message) {
    if (typeof message.senderUrl !== "string") throw new Error(t("verse_page_unverified"));
    const request = validateVerseAudioRequest(message.request, message.senderUrl);
    if (!request) throw new Error(t("verse_request_invalid"));
    const metadataResponse = await fetchWithTimeout(request.apiUrl, 15e3);
    if (!metadataResponse.ok) throw new Error(t("verse_timing_unavailable"));
    if (!validateMediaApiUrl(metadataResponse.url, request.verses[0])) {
      throw new Error(t("verse_timing_redirected"));
    }
    const metadata = await metadataResponse.json();
    const source = selectVerseClipSource(metadata, request.verses, request.label);
    if (!source) throw new Error(t("verse_timing_missing"));
    const audioResponse = await fetchWithTimeout(source.audioUrl, 45e3);
    if (!audioResponse.ok) throw new Error(t("chapter_audio_download_failed"));
    if (!isJwCdnUrl(audioResponse.url)) throw new Error(t("chapter_audio_redirected"));
    const declaredLength = Number(audioResponse.headers.get("content-length"));
    if (Number.isFinite(declaredLength) && declaredLength > 0) {
      assertChapterAudioSize(declaredLength, source.expectedBytes);
    }
    const chapterBytes = await audioResponse.arrayBuffer();
    assertChapterAudioSize(chapterBytes.byteLength, source.expectedBytes);
    const audioContext = new AudioContext();
    try {
      const decoded = await audioContext.decodeAudioData(chapterBytes);
      const wav = encodeWavClip(decoded, source.startSeconds, source.durationSeconds);
      return {
        ok: true,
        base64: bytesToBase64(wav),
        bytes: wav.byteLength,
        durationSeconds: source.durationSeconds,
        filename: source.filename,
        mime: "audio/wav"
      };
    } finally {
      await audioContext.close();
    }
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.target !== "studynav-offscreen" || message.type !== "PROCESS_VERSE_AUDIO" && message.type !== "PROCESS_MEDIA_AUDIO_CLIP") return;
    if (busy) {
      sendResponse({ ok: false, error: t("verse_job_busy") });
      return;
    }
    busy = true;
    const process = message.type === "PROCESS_MEDIA_AUDIO_CLIP" ? processMediaAudioClip : processVerseAudio;
    process(message).then(sendResponse).catch((error) => {
      const text = error instanceof Error ? error.message : t("verse_processing_failed");
      sendResponse({ ok: false, error: text });
    }).finally(() => {
      busy = false;
    });
    return true;
  });
})();
//# sourceMappingURL=offscreen.js.map
